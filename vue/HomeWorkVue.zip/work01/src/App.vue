<!-- <template>
  <div>
    <h1>简易记事本</h1>
    <div>
      <input type="text" v-model="newNote" v-on:keyup.enter="addNote">
      <button v-on:click="addNote">添加</button>
    </div>
    <ul>
      <li v-for="(note, index) in notes" :key="index">
        {{ note }}
        <button v-on:click="removeNote(index)">删除</button>
      </li>
    </ul>
    <div v-if="notes.length > 0">
      共有 {{ notes.length }} 条记事
      <button v-on:click="clearNotes">清除所有记录</button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      notes: [],
      newNote: '',
    };
  },
  methods: {
    addNote() {
      if (this.newNote !== '') {
        this.notes.push(this.newNote);
        this.newNote = '';
      }
    },
    removeNote(index) {
      this.notes.splice(index, 1);
    },
    clearNotes() {
      this.notes = [];
    },
  },
};
</script>
<style>
  /* Style for the container */
  .container {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    font-family: Arial, sans-serif;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
  }

  /* Style for the title */
  h1 {
    font-size: 36px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333;
  }

  /* Style for the input box */
  input[type="text"] {
    width: 80%;
    padding: 10px;
    border: 2px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    outline: none;
  }

  /* Style for the Add button */
  button {
    padding: 10px 20px;
    border-radius: 5px;
    border: none;
    background-color: #4286f4;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
  }

  /* Style for the notes list */
  ul {
    list-style: none;
    margin: 20px 0;
    padding: 0;
  }

  li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f2f2f2;
    border-radius: 5px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
  }

  li button {
    padding: 5px 10px;
    border-radius: 5px;
    border: none;
    background-color: #e74c3c;
    color: #fff;
    font-size: 14px;
    cursor: pointer;
  }

  /* Style for the notes count and clear all button */
  .notes-count {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 20px;
  }

  .notes-count button {
    padding: 10px 20px;
    border-radius: 5px;
    border: none;
    background-color: #e74c3c;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
  }
</style> -->




<template>
  <div id="app">
    <div v-if = "books.length">
      <table border="1" align="center" width="500">
        <caption><h2>购物车</h2></caption>
        <thead>
          <tr>
            <th></th>
            <th>名称</th>
            <th>图片</th>
            <th>价格</th>
            <th>数量</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item,index) in books" :key="index" align="center">
            <td>{{ item.id }}</td>
            <td>{{ item.name }}</td>
            <td><img :src="require(`@/assets/${item.img}`)" /></td>
            <!-- <td></td> -->
            <td>{{ filter(item.price) }}</td>
            <td>
              <button @click="decrement(index)" v-bind:disabled="item.count<=0">
                -
              </button>
              {{ item.count }}
              <button @click="increment(index)">
                +
              </button>
            </td>
            <td>
                <button @click="removeHandle(index)">移除</button>
            </td>
          </tr>
          <tr align="center">
            <td colspan="2">总价格</td>
            <td colspan="3">{{ filter(computedName) }}</td>
          </tr>
          <tr align="center">
            <td colspan="5">
              <button @click=" clearAll()">清楚全部</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <h2 v-else >
      购物车为空
    </h2>
  </div>
</template>

<script>
import {reactive,toRefs,computed, onMounted} from 'vue'

export default{
  setup (){
    const state = reactive({
      books:[
        // {
        //   id:1,
        //   name:'华为mate30',
        //   price:3465,
        //   count:2
        // },
        // {
        //   id:2,
        //   name:'华为mate40',
        //   price:4166,
        //   count:3
        // },
        // {
        //   id:3,
        //   name:'苹果12',
        //   price:7500,
        //   count:2
        // },
        // {
        //   id:4,
        //   name:'OPPO',
        //   price:2180,
        //   count:4
        // }
      ]
    })
    onMounted(()=>{
      fetch('/test.json')
      .then(res =>res.json())
      .then(res=>{
        // console.log(res.list);
        // console.log(res.books[1]);
        state.books = res.books
        // console.log(res.books);
      })
    }
    )
    const decrement = (index)=>{
      state.books[index].count--
      if(state.books[index].count ===0){
        removeHandle(index)
      }
    }
    const increment = (index)=>{
      state.books[index].count++
    }
    const removeHandle = (index)=>{
      state.books.splice(index,1)
      for(let i =0;i<state.books.length;i++){
        state.books[i].id=i+1
      }
      
    }
    const filter = (price) =>{
      return '￥'+price.toFixed(2)
    }
    // const clearAll = ()=>{
    //   for(let i = state.books.length;i>=0;i--){
        
    //     while(state.books[i].count>0){
    //       decrement(i);
    //       state.books[i].count--;
    //     }
    //   }
    // }
    const clearAll = () =>{
      state.books = [];
    }
    const computedName = computed(()=>{
      let totalPrice = 0;
      for(let i=0;i<state.books.length;i++){
        totalPrice+=state.books[i].price*state.books[i].count
      }
      return totalPrice
    }

    )

    return {
      ...toRefs(state),
      computedName,
      decrement,
      increment,
      removeHandle,
      filter,
      clearAll
    }

  }
}
</script>


<style lang="scss" scoped>

</style>
