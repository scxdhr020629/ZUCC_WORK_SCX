<template>
  <div class="echarts-box">
    <!-- 放一个读入文件 -->
    <input type="file" ref="upload" accept=".xls,.xlsx" class="outputlist_upload">

    <div id="myEcharts" :style="{ width: '100%', height: '700px' }"></div>
  </div>
</template>

<script>
import * as echarts from "echarts";
import { update } from "lodash";
import { onUnmounted, onMounted } from 'vue'
import { ref } from 'vue'
import { read, utils } from 'xlsx'

//通过this.$echarts来使用
export default {
  name: "echartsBox",

  // data() {
  //   return {
  //     outputs: []
  //   }
  // },


  //  readExcel(e) {
  //     var that = this;
  //     const files = e.target.files;
  //     // 如果没有文件名
  //     if (files.length <= 0) {
  //       return false;
  //     } else if (!/\.(xls|xlsx)$/.test(files[0].name.toLowerCase())) {
  //       this.$Message.error('上传格式不正确，请上传xls或者xlsx格式');
  //       return false;
  //     }

  //     const fileReader = new FileReader();
  //     fileReader.onload = (ev) => {
  //       try {
  //         const data = ev.target.result;
  //         // 切换为新的调用方式
  //         const workbook = read(data, {
  //           type: 'binary'
  //         });
  //         // 取第一张表
  //         const wsname = workbook.SheetNames[0];
  //         // 切换为新的调用方式 生成json表格内容
  //         const ws = utils.sheet_to_json(workbook.Sheets[wsname]);
  //         console.log(ws);
  //         // 后续为自己对ws数据的处理
  //       } catch (e) {
  //         return false;
  //       }
  //     };
  //     fileReader.readAsBinaryString(files[0]);
  //   }




  mounted() {



    this.$refs.upload.addEventListener('change', e => {//绑定监听表格导入事件


      var that = this;
      const files = e.target.files;
      // 如果没有文件名
      if (files.length <= 0) {
        return false;
      } else if (!/\.(xls|xlsx)$/.test(files[0].name.toLowerCase())) {
        this.$Message.error('上传格式不正确，请上传xls或者xlsx格式');
        return false;
      }

      const fileReader = new FileReader();
      fileReader.onload = (ev) => {
        try {
          const data = ev.target.result;
          // 切换为新的调用方式
          const workbook = read(data, {
            type: 'binary'
          });
          // 取第一张表
          const wsname = workbook.SheetNames[0];
          // 切换为新的调用方式 生成json表格内容
          const ws = utils.sheet_to_json(workbook.Sheets[wsname]);
          // console.log(ws);
          // console.log(ws[0]);
          // // console.log(ws[0]['线缆']);
          // console.log(ws[0].x);
          this.outputs = ws;
          // 后续为自己对ws数据的处理
          console.log("  log   ");
          console.log(this.outputs);
          this.initChart();
        } catch (e) {
          return false;
        }
      };
      fileReader.readAsBinaryString(files[0]);

    })

  },





  setup() {


    const outputs = ref([])

    // 在这里可以使用 outputs 数据，并对其进行修改



    let echart = echarts;
    onMounted(() => {
      initChart();
    });

    onUnmounted(() => {
      echart.dispose;
    });




    // 基础配置一下Echarts
    function initChart() {
      let chart = echart.init(document.getElementById("myEcharts"), "dark");

      console.log("initChart");
      console.log(outputs._rawValue);

      // 获取第一列的数据
      let xTest = [];
      for (let i = 0; i < outputs._rawValue.length; i++) {
        xTest.push(outputs._rawValue[i].x);
      }
      console.log(xTest);

      let yTest = [];
      for(let i=0;i<outputs._rawValue.length;i++){
        yTest.push(outputs._rawValue[i].y);
      }
      console.log(yTest);

      let newData = [];
      for(let i=0;i<10;i++){
        var tempObj = {};
        tempObj.value=yTest[i];
        tempObj.name=xTest[i];
        newData.push(tempObj)
      }
      




      // 把配置和数据放这里
      chart.setOption({
        legend: {
          top: 'bottom'
        },
        toolbox: {
          show: true,
          feature: {
            mark: { show: true },
            dataView: { show: true, readOnly: false },
            restore: { show: true },
            saveAsImage: { show: true }
          }
        },
        series: [
          {
            name: 'Nightingale Chart',
            type: 'pie',
            radius: [50, 250],
            center: ['50%', '50%'],
            roseType: 'area',
            itemStyle: {
              borderRadius: 8
            },
            data:newData
          }
        ]
      });
      window.onresize = function () {
        //自适应大小
        chart.resize();
      };


    }

    return { initChart, outputs };
  }
};
</script>