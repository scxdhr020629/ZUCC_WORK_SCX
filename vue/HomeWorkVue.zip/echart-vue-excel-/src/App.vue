<template>
  <div class="menu">
    <nav class="nav" id="topnav">
      <h1 class="logo"><a href="/">֪按图索极</a></h1>
      <ul style="float: left;margin-left: 60px;padding: 10px;">
        <template v-for="nav in navList">
          <li @mouseover="selectStyle(nav)">
            <a :href="nav.linkUrl">{{ nav.title }}</a>
            <ul class="sub-nav" v-if="nav.childrens" v-show="nav.active" @mouseout="outStyle(nav)">
              <li v-for="children in nav.childrens">
                <a :href="children.linkUrl">{{ children.title }}</a>
              </li>
            </ul>
          </li>
        </template>
      </ul>
    </nav>
  </div>




  <div class="echarts-box" style="background-color: #100c2a;height: 1300px;width: 100%;">
    <!-- 放一个读入文件 -->
    <input type="file" ref="upload" accept=".xls,.xlsx" class="outputlist_upload">


    <!-- <div style="background-color: aqua; display: flex; flex-direction: row; justify-content: space-between;"> -->
    <div>
      <div id="myEchart1" :style="{ width: '50%', height: '500px', display: 'inline-block' }"></div>
      <div id="myEchart3" :style="{ width: '50%', height: '500px', display: 'inline-block' }"></div>
    </div>

    <div id="myEchart2" :style="{ width: '100%', height: '700px' }"></div>
  </div>
</template>
<style>


.outputlist_upload {
  border: none;
  background-color: #1d1b41;
  color: #fff;
  padding: 10px;
  font-size: 16px;
  font-weight: bold;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.2s ease-in-out;
}

.outputlist_upload:hover {
  background-color: #3b386e;
}

.outputlist_upload:active {
  background-color: #5a577e;
}



#topnav_current {
  color: #00a7eb;
}

.menu {
  height: 76px;
  width: 100%;
  background-color: #000;
}

.nav {
  height: 80px;
  width: 100%;
  margin: 0 auto;
}

.nav li {
  float: left;
  position: relative;
}

.nav li a {
  color: #bdbdbd;
  padding: 0 10px;
  display: inline-block;
  text-decoration: none;
}

.nav li a:hover {
  color: #fff;
}

.nav li .sub-nav {
  position: absolute;
  top: 30px;
  width: 120px;
  background: #fff;
  left: -20px;
  /* display: none;  */
  z-index: 9999;
}

.nav li .sub-nav li {
  clear: left;
  height: 20px;
  line-height: 35px;
  position: relative;
  width: 200px;
  padding: 5px 20px;
}

.nav li .sub-nav li a {
  font-size: 15px;
  font-weight: 400;
  color: #404040;
  line-height: 28px;
}

.nav li .sub-nav li a:hover {
  color: #000;
  border-left: 2px solid #000;
}

.a_active {
  color: #00a7eb !important;
}

.logo {
  float: left;
  margin-left: 70px;
  font-size: 24px;
}

.logo a {
  color: #00a7eb;
  text-decoration: none;
}

.hometitle {
  font-size: 18px;
  color: #282828;
  font-weight: 600;
  margin: 0;
  text-transform: uppercase;
  padding-bottom: 15px;
  margin-bottom: 25px;
  position: relative;
}

.hometitle:after {
  content: "";
  background-color: #282828;
  left: 0;
  width: 50px;
  height: 2px;
  bottom: 0;
  position: absolute;
  -webkit-transition: 0.5s;
  -moz-transition: 0.5s;
  -ms-transition: 0.5s;
  -o-transition: 0.5s;
  transition: 0.5s;
}
</style>
<script>
import * as echarts from "echarts";
import { update } from "lodash";
import { onUnmounted, onMounted } from 'vue'
import { ref } from 'vue'
import { read, utils } from 'xlsx'

//通过this.$echarts来使用
export default {
  name: "echartsBox",
  props: {
    data: Object
  },
  data() {
    return {
      navList: [
        {
          title: "首页",
          icon: "glyphicon glyphicon-cog",
          linkUrl: "",
          active: false,
          childrens: []
        },
        {
          title: "模型体系",
          icon: "glyphicon glyphicon-cog",
          linkUrl: "",
          active: false,
          childrens: []
        },
        {
          title: "关于我们",
          icon: "glyphicon glyphicon-th-list",
          linkUrl: "javascript:void(0);",
          active: false,
          childrens: [
            {
              title: "团队博客",
              icon: "",
              linkUrl: "",
              active: false,
              childrens: []
            },
            {
              title: "团队成员",
              icon: "",
              linkUrl: "",
              active: false,
              childrens: []
            }
          ]
        },
        {
          title: "数据全景",
          icon: "glyphicon glyphicon-cog",
          linkUrl: "",
          active: false,
          childrens: []
        }
      ]
    };
  },

  mounted() {



    this.$refs.upload.addEventListener('change', e => {//绑定监听表格导入事件


      var that = this;
      const files = e.target.files;
      // 如果没有文件名
      if (files.length <= 0) {
        return false;
      } else if (!/\.(xls|xlsx)$/.test(files[0].name.toLowerCase())) {
        this.$Message.error('上传格式不正确，请上传xls或者xlsx格式');
        return false;
      }

      const fileReader = new FileReader();
      fileReader.onload = (ev) => {
        try {
          const data = ev.target.result;
          // 切换为新的调用方式
          const workbook = read(data, {
            type: 'binary'
          });
          // 取第一张表
          const wsname = workbook.SheetNames[0];
          // 切换为新的调用方式 生成json表格内容
          const ws = utils.sheet_to_json(workbook.Sheets[wsname]);
          // console.log(ws);
          // console.log(ws[0]);
          // // console.log(ws[0]['线缆']);
          // console.log(ws[0].x);
          this.outputs = ws;
          // 后续为自己对ws数据的处理
          console.log("  log   ");
          console.log(this.outputs);
          this.initChart1();
          this.initChart2();
          this.initChart3();
        } catch (e) {
          return false;
        }
      };
      fileReader.readAsBinaryString(files[0]);

    })

  },
  components: {},
  methods: {
    selectStyle(nav) {
      var _this = this;
      this.$nextTick(function() {
        _this.navList.forEach(function(item) {
          item.active = false;
        });
        nav.active = true;
      });
    },
    outStyle(nav) {
      nav.active = false;
    },
    changeIcon() {
      this.isOpen = !this.isOpen;
    },
    searchActive() {
      this.search_active = !this.search_active;
    },
    clickNav(nav) {
      nav.active = !nav.active;
    }
  },


  setup() {
    /// 声明定义一下echart
    // let echart = echarts;

    // // prettier-ignore
    // let dataAxis = ['点', '击', '柱', '子', '或', '者', '两', '指', '在', '触', '屏', '上', '滑', '动', '能', '够', '自', '动', '缩', '放'];
    // // prettier-ignore
    // let data = [220, 182, 191, 234, 290, 330, 310, 123, 442, 321, 90, 149, 210, 122, 133, 334, 198, 123, 125, 220];
    // let yMax = 500;
    // let dataShadow = [];
    // for (let i = 0; i < data.length; i++) {
    //   dataShadow.push(yMax);
    // }

    const outputs = ref([])

    // 在这里可以使用 outputs 数据，并对其进行修改



    let echart = echarts;
    onMounted(() => {
      initChart1();
      initChart2();
      initChart3();
    });

    onUnmounted(() => {
      echart.dispose;
    });




    // 基础配置一下Echarts
    function initChart1() {
      let chart = echart.init(document.getElementById("myEchart1"), "dark");
      // console.log("输出以下outputs");
      // console.log(outputs);
      //这里如何使用data中的output？？？？？？？？？？？
      console.log("initChart");
      console.log(outputs._rawValue);

      // 获取第一列的数据
      let xTest = [];
      for (let i = 0; i < outputs._rawValue.length; i++) {
        xTest.push(outputs._rawValue[i].y);
      }
      console.log(xTest);

      // 算出现次数的 返回一个map
      function countOccurrences(arr) {
        const counts = {};
        for (const element of arr) {
          counts[element] = (counts[element] || 0) + 1;
        }
        return new Map(Object.entries(counts));
      }

      let mapTest = countOccurrences(xTest);
      console.log(mapTest);

      function getTopNItems(inputMap, n) {
        // 获取键值对数组
        const items = Array.from(inputMap);
        // 按值从大到小排序
        items.sort((a, b) => b[1] - a[1]);
        // 取出前n个键值对
        const topItems = items.slice(0, n);
        // 转化为新的Map
        const topMap = new Map(topItems);
        return topMap;
      }







      // 数据要50个
      let newMap = getTopNItems(mapTest, 50);
      console.log("new Map");
      console.log(newMap
      );
      let dataAxis = Array.from(newMap.keys());
      let data = Array.from(newMap.values());


      let newData = [];

      for (var i = 0; i < data.length; i++) {
        var tempObj = {};
        tempObj.name = dataAxis[i];
        tempObj.value = data[i];
        newData.push(tempObj)
      }






      // 把配置和数据放这里
      chart.setOption({
        title: {
          text: '公司新能源产业链产品数量',
          subtext: '前50',
          left: 'center'
        },
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
          type: 'scroll',
          orient: 'vertical',
          right: 200,
          top: 20,
          bottom: 20,
          data: dataAxis
        },
        // grid: {
        //   top:'40%',
        //   left:'3%',
        //   right:'4%',
        //   bottom:'3%',
        //   containLabel:true

        // },
        series: [
          {
            name: '姓名',
            type: 'pie',
            radius: '55%',
            center: ['40%', '50%'],
            data: newData,
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      });
      window.onresize = function () {
        //自适应大小
        chart.resize();
      };


    }




    function initChart2() {
      let chart = echart.init(document.getElementById("myEchart2"), "dark");
      // console.log("输出以下outputs");
      // console.log(outputs);
      //这里如何使用data中的output？？？？？？？？？？？
      console.log("initChart");
      console.log(outputs._rawValue);

      // 获取第一列的数据
      let xTest = [];
      for (let i = 0; i < outputs._rawValue.length; i++) {
        xTest.push(outputs._rawValue[i].x);
      }
      console.log(xTest);

      // 算出现次数的 返回一个map
      function countOccurrences(arr) {
        const counts = {};
        for (const element of arr) {
          counts[element] = (counts[element] || 0) + 1;
        }
        return new Map(Object.entries(counts));
      }

      let mapTest = countOccurrences(xTest);
      console.log(mapTest);

      let dataAxis = Array.from(mapTest.keys());
      let data = Array.from(mapTest.values());
      // prettier-ignore
      // let dataAxis = ['点', '击', '柱', '子', '或', '者', '两', '指', '在', '触', '屏', '上', '滑', '动', '能', '够', '自', '动', '缩', '放'];
      // prettier-ignore
      // let data = [220, 182, 191, 234, 290, 330, 310, 123, 442, 321, 90, 149, 210, 122, 133, 334, 198, 123, 125, 220];
      let yMax = 500;
      let dataShadow = [];
      for (let i = 0; i < data.length; i++) {
        dataShadow.push(yMax);
      }






      // 把配置和数据放这里
      chart.setOption({
        title: {

        },
        xAxis: {
          data: dataAxis,
          axisLabel: {
            inside: true,
            color: '#fff'
          },
          axisTick: {
            show: false
          },
          axisLine: {
            show: false
          },
          z: 10
        },
        yAxis: {
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            color: '#fff'
          }
        },
        dataZoom: [
          {
            type: 'inside'
          }
        ],
        series: [
          {
            type: 'bar',
            showBackground: true,
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: '#83bff6' },
                { offset: 0.5, color: '#188df0' },
                { offset: 1, color: '#188df0' }
              ])
            },
            emphasis: {
              itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  { offset: 0, color: '#2378f7' },
                  { offset: 0.7, color: '#2378f7' },
                  { offset: 1, color: '#83bff6' }
                ])
              }
            },
            data: data
          }
        ]
      });
      window.onresize = function () {
        //自适应大小
        chart.resize();
      };
      const zoomSize = 6;
      chart.on('click', function (params) {
        console.log(dataAxis[Math.max(params.dataIndex - zoomSize / 2, 0)]);
        chart.dispatchAction({
          type: 'dataZoom',
          startValue: dataAxis[Math.max(params.dataIndex - zoomSize / 2, 0)],
          endValue:
            dataAxis[Math.min(params.dataIndex + zoomSize / 2, data.length - 1)]
        });
      });

    }






    function initChart3() {
      let chart = echart.init(document.getElementById("myEchart3"), "dark");
      // console.log("输出以下outputs");
      // console.log(outputs);
      //这里如何使用data中的output？？？？？？？？？？？
      console.log("initChart");
      console.log(outputs._rawValue);

      // 获取第一列的数据
      let xTest = [];
      for (let i = 0; i < outputs._rawValue.length; i++) {
        xTest.push(outputs._rawValue[i].y);
      }
      console.log(xTest);

      // 算出现次数的 返回一个map
      function countOccurrences(arr) {
        const counts = {};
        for (const element of arr) {
          counts[element] = (counts[element] || 0) + 1;
        }
        return new Map(Object.entries(counts));
      }

      let mapTest = countOccurrences(xTest);
      console.log(mapTest);

      function getTopNItems(inputMap, n) {
        // 获取键值对数组
        const items = Array.from(inputMap);
        // 按值从大到小排序
        items.sort((a, b) => b[1] - a[1]);
        // 取出前n个键值对
        const topItems = items.slice(0, n);
        // 转化为新的Map
        const topMap = new Map(topItems);
        return topMap;
      }







      // 数据要20个
      let newMap = getTopNItems(mapTest, 20);
      console.log("new Map");
      console.log(newMap
      );
      let dataAxis = Array.from(newMap.keys());
      let data = Array.from(newMap.values());


      let newData = [];

      for (var i = 0; i < data.length; i++) {
        var tempObj = {};
        tempObj.name = dataAxis[i];
        tempObj.value = data[i];
        newData.push(tempObj)
      }






      // 把配置和数据放这里
      chart.setOption({
        title: {
          text: '公司新能源产业链产品数量',
          subtext: '前20',
          left: 'center',
        },
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        // grid: {

        //   y: 101,    //上下距离

        //   // y2: 36,

        //   x2: 10,

        //   height: "70%"

        // },

        legend: {
          type: 'scroll',
          orient: 'vertical',
          right: 200,
          top: 20,
          bottom: 20,
          data: dataAxis
        },
        series: [
          {
            name: '姓名',
            type: 'pie',
            radius: '55%',
            center: ['40%', '50%'],
            data: newData,
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      });
      window.onresize = function () {
        //自适应大小
        chart.resize();
      };


    }

























    return { initChart1, initChart2, initChart3, outputs };
  }




};
</script>