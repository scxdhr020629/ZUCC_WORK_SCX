
<!-- 第一题 -->
<!-- <template>
  <div>
      <ul style="list-style-type: none;">
          <li v-for="(item, index) in sports" :key="index">
              <input type="checkbox" v-model="item.checked">
              {{ item.name }}
          </li>
      </ul>
      <p>数组定义格式:{{ sports }}</p>
      <button @click="selectAll">全选</button>
      <button @click="deselectAll">取消全选</button>
  </div>
</template>

<script>
import { ref } from 'vue';

export default {
  setup() {
      const sports = ref([
          { name: '足球', checked: true },
          { name: '篮球', checked: true },
          { name: '乒乓球', checked: true }
      ]);

      const selectAll = () => {
          for (const item of sports.value) {
              item.checked = true;
          }
      };

      const deselectAll = () => {
          for (const item of sports.value) {
              item.checked = false;
          }
      };

      return {
          sports,
          selectAll,
          deselectAll
      };
  }
};
</script> -->


<!-- 第二题 -->
<template>
  <div>
      <p>字符串反转:{{ state.message }}</p>
      <p>计数器:{{ count }},该数据是响应式数据否:{{ flag }}</p>
      <button @click="reverseMessage">测试</button>
  </div>
</template>

<script>
import { reactive, ref, isRef, isProxy } from 'vue';

export default {
  setup() {
      const state = reactive({
          message: 'Hello Vue3 World!'
      });

      const count = ref(0);

      const reverseMessage = () => {
          state.message = state.message.split('').reverse().join('');
          count.value++;
      };

      const flag = isRef(count);
      return {
          state,
          flag,
          count,
          reverseMessage
      };
  }
};
</script>
