<template>
  <div>
      <ul style="list-style-type: none;">
          <li v-for="(item, index) in sports" :key="index">
              <input type="checkbox" v-model="item.checked">
              {{ item.name }}
          </li>
      </ul>
      <p>数组定义格式:{{ sports }}</p>
      <button @click="selectAll">全选</button>
      <button @click="deselectAll">取消全选</button>
  </div>
</template>

<script>
import { ref } from 'vue';

export default {
  setup() {
      const sports = ref([
          { name: '足球', checked: true },
          { name: '篮球', checked: true },
          { name: '乒乓球', checked: true }
      ]);

      const selectAll = () => {
          for (const item of sports.value) {
              item.checked = true;
          }
      };

      const deselectAll = () => {
          for (const item of sports.value) {
              item.checked = false;
          }
      };

      return {
          sports,
          selectAll,
          deselectAll
      };
  }
};
</script>