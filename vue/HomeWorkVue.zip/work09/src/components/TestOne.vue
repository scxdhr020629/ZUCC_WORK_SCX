<template>
    <div class="carousel" @mouseenter="stopCarousel" @mouseleave="startCarousel">
      <div class="slides" :style="{ transform: 'translateX(' + (-currentIndex * 100) + '%)' }">
        <div class="slide" v-for="(image, index) in images" :key="index">
          <img :src="image" alt="">
        </div>
      </div>
      <div class="indicators">
        <span class="indicator" v-for="(image, index) in images" :key="index"
              :class="{ active: index === currentIndex }"
              @click="setCurrentIndex(index)">{{ index + 1 }}
        </span>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    props: {
      images: {
        type: Array,
        required: true
      }
    },
    data() {
      return {
        currentIndex: 0,
        timerId:null
      }
    },
    mounted(){
      this.startCarousel()
    },
    methods: {
      setCurrentIndex(index) {
        this.currentIndex = index
      },
      startCarousel(){
        this.timerId = setInterval(() => {
          this.currentIndex = (this.currentIndex+1)%this.images.length
        }, 2000);
      },
      stopCarousel(){
        clearInterval(this.timerId)
      }
    }
  }
  </script>
  
  <style>
  .carousel {
    width: 100%;
    height: 640px;
    overflow: hidden;
    position: relative;
  }
  .slides {
    display: flex;
    transition: transform 1s ease-in-out;
  }
  .slide {
    flex: 1 0 100%;
  }
  .slide img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  .indicators {
    position: absolute;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
  }
  .indicator {
    text-align: center;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background-color: #fdfdfd;
    margin-right: 10px;
    cursor: pointer;
  }
  .indicator.active {
    background-color: #bd1a1a;
  }
  </style>
  