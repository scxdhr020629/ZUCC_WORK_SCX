<template>
    <div>
        <p>字符串反转:{{ state.message }}</p>
        <p>计数器:{{ count }},该数据是响应式数据否:{{ flag }}</p>
        <button @click="reverseMessage">测试</button>
    </div>
</template>
  
<script>
import { reactive, ref, isRef, isProxy } from 'vue';

export default {
    setup() {
        const state = reactive({
            message: 'Hello Vue3 World!'
        });

        const count = ref(0);

        const reverseMessage = () => {
            state.message = state.message.split('').reverse().join('');
            count.value++;
        };

        const flag = isRef(count);
        return {
            state,
            flag,
            count,
            reverseMessage
        };
    }
};
</script>
  