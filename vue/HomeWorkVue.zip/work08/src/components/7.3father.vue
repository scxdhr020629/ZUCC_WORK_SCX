<template>
    <br>
    <child1 @event="handleClick"></child1>
    <br>{{ mytext }}<br>
    <child2 v-if="isShow"></child2>
</template>

<script>
import {reactive,toRefs} from 'vue'
import child1 from './7.3child1.vue'
import child2 from './7.3child2.vue'
export default{
    components:{
        child1,
        child2
    },
    setup(){
        const state = reactive({
            isShow:false,
            mytext:''
        })
        const handleClick = (sonData) => {
            state.isShow = !state.isShow
            if(state.isShow){
                state.mytext = sonData
            }
            else{
                state.mytext = ''
            }
        }
        return{
            ...toRefs(state),
            handleClick
        }
    }
}
</script>
