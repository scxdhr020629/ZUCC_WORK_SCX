import { createApp } from 'vue'
import app from './App.vue'

createApp(app).mount('#app')
