<template>
  <div>
    <h1>简易记事本</h1>
    <div>
      <input type="text" v-model="newNote" v-on:keyup.enter="addNote">
      <button v-on:click="addNote">添加</button>
    </div>
    <ul>
      <li v-for="(note, index) in notes" :key="index">
        {{ note }}
        <button v-on:click="removeNote(index)">删除</button>
      </li>
    </ul>
    <div v-if="notes.length > 0">
      共有 {{ notes.length }} 条记事
      <button v-on:click="clearNotes">清除所有记录</button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      notes: [],
      newNote: '',
    };
  },
  methods: {
    addNote() {
      if (this.newNote !== '') {
        this.notes.push(this.newNote);
        this.newNote = '';
      }
    },
    removeNote(index) {
      this.notes.splice(index, 1);
    },
    clearNotes() {
      this.notes = [];
    },
  },
};
</script>
<style>
  /* Style for the container */
  .container {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    font-family: Arial, sans-serif;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
  }

  /* Style for the title */
  h1 {
    font-size: 36px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333;
  }

  /* Style for the input box */
  input[type="text"] {
    width: 80%;
    padding: 10px;
    border: 2px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    outline: none;
  }

  /* Style for the Add button */
  button {
    padding: 10px 20px;
    border-radius: 5px;
    border: none;
    background-color: #4286f4;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
  }

  /* Style for the notes list */
  ul {
    list-style: none;
    margin: 20px 0;
    padding: 0;
  }

  li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f2f2f2;
    border-radius: 5px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
  }

  li button {
    padding: 5px 10px;
    border-radius: 5px;
    border: none;
    background-color: #e74c3c;
    color: #fff;
    font-size: 14px;
    cursor: pointer;
  }

  /* Style for the notes count and clear all button */
  .notes-count {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 20px;
  }

  .notes-count button {
    padding: 10px 20px;
    border-radius: 5px;
    border: none;
    background-color: #e74c3c;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
  }
</style>