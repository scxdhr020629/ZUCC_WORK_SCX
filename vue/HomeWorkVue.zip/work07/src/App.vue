<template>
  <nav>
    <router-link to="/">主页</router-link> |
    <router-link to="/news">学校新闻</router-link> |
    <router-link to="/organization">学校机构</router-link> |
    <router-link to="/about">关于</router-link>
  </nav>
  <router-view/>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

nav {
  padding: 30px;
  font-size: 50px;
  text-align: center;
  display: flex;
  justify-content: space-between;
  margin-left: 100px;
  margin-right: 100px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
