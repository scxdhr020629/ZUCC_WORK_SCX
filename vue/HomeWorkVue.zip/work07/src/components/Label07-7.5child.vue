<template>
    <div>头部区域</div>
    <slot>默认显示区域</slot>
    <div>底部区域</div>
</template>