<template>
    <p />
    <table width="300" height="300" align="center" border="1">
        <caption><h3>用户详细信息</h3></caption>
        <tr align="center">
            <td>编号</td>
            <td>{{ userList[index].id }}</td>
        </tr>
        <tr align="center">
            <td>姓名</td>
            <td>{{ userList[index].name }}</td>
        </tr>
        <tr align="center">
            <td>年龄</td>
            <td>{{ userList[index].age }}</td>
        </tr>
        <tr align="center">
            <td>性别</td>
            <td>{{ userList[index].sex }}</td>
        </tr>
        <tr align="center">
            <td>生日</td>
            <td>{{ userList[index].birthday }}</td>
        </tr>
        <tr align="center">
            <td>电话</td>
            <td>{{ userList[index].telephone }}</td>
        </tr>
        <tr>
            <td align="center" colspan="2"><button @click="goback()">返回</button></td>
        </tr>
    </table>
</template>

<script>
    import { reactive ,toRefs} from 'vue'
    import {useRouter,useRoute} from 'vue-router'
    export default{
        setup(){
            const state = reactive({
                userList:[
                    {
                        id:1,
                        name:'尹世超1',
                        age:21,
                        sex:'男',
                        birthday:'2002.02.14',
                        telephone:'13095661685'
                    },
                    {
                        id:2,
                        name:'尹世超2',
                        age:21,
                        sex:'男',
                        birthday:'2002.02.14',
                        telephone:'13095661685'
                    },
                    {
                        id:3,
                        name:'尹世超3',
                        age:21,
                        sex:'男',
                        birthday:'2002.02.14',
                        telephone:'13095661685'
                    }
                ],
                index:0
            })
            const route = useRoute()
            state.index = route.query.id
            const router = useRouter()
            const goback = () => {
                router.go(-1)
            }
            return{
                ...toRefs(state),
                goback
            }
        }
    }
</script>


<style scoped>
    .table{
        width: 300px;
        height: 300px;
        align-items: center;
        border: 1px solid black;
    }
</style>