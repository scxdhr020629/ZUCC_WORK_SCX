<template>
    <h1>商品管理</h1>
</template>

<srcipt>

</srcipt>

<style scoped>

</style>