<template>
    <br>学习Vue3.0之前需要掌握的知识包括:<br>
    <child1 v-for="post in posts" :key="post.id" :title="post.title" :id="post.id">

    </child1>
</template>

<script>
import {reactive,toRefs} from 'vue'
import child1 from './Label07-7.2child.vue'
export default{
    components:{
        child1
    },
    setup(){
        const state = reactive({
            posts:[
                {id:1,title:'HTML'},
                {id:2,title:'CSS'},
                {id:3,title:'JavaScript'},
                {id:4,title:'jQuery'},
            ]
        })
        return{
            ...toRefs(state)
        }
    }
}
</script>