<template>
    <button @click="showList">显示列表</button>
</template>

<script>
import {reactive,toRefs} from 'vue'
export default{
    setup(props,{emit}){
        const state = reactive({
            count:0
        })
        const showList = () => {
            emit('event','我是子组件传过来的数据')
        }
        return{
            ...toRefs(state),
            showList
        }
    }
}
</script>