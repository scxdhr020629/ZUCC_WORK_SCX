<template>
    <child></child>
    <hr>
    <child>
        <h1>
            主要内容<button>测试</button>
        </h1>
    </child>
</template>

<script>
import {reactive,toRefs} from 'vue'
import child from './Label07-7.5child.vue'
export default{
    components:{
        child
    },
    setup(){
        const state = ({
            count:0
        })
        return{
            ...toRefs(state)
        }
    }
}
</script>
