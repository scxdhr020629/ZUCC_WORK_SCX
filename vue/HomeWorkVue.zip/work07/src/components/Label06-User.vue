<template>
    <table class="table">
        <caption><h3>用户管理</h3></caption>
        <thead>
            <tr>
                <th>编号</th>
                <th>姓名</th>
                <th>年龄</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody align="center">
            <tr v-for="item in i=userList" :key="item.id">
                <td>{{ item.id }}</td>
                <td>{{ item.name }}</td>
                <td>{{ item.age }}</td>
                <td>
                    <button @click="goDetail(item.id-1)">详情</button>
                </td>
            </tr>
        </tbody>
    </table>
</template>

<script>
    import {reactive,toRefs} from 'vue'
    import {useRouter} from 'vue-router'
    export default{
        setup(){
            const state = reactive({
                userList:[
                    {
                        id:1,
                        name:"尹世超1",
                        age:21
                    },
                    {
                        id:2,
                        name:"尹世超2",
                        age:21
                    },
                    {
                        id:3,
                        name:"尹世超3",
                        age:21
                    },
                ]
            })

            const router = useRouter()
            const goDetail = (index) => {
                router.push({
                    path:'/userInfo',
                    query:{
                        id:index
                    }
                })
            }

            return{
                ...toRefs(state),
                goDetail
            }
        }
    }
</script>


<style scoped>
    .table{
        width: 1000px;
    }
    tr{
        height: 40px;
    }
</style>