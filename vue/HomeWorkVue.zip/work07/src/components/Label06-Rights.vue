<template>
    <h1>权限管理</h1>
</template>

<srcipt>

</srcipt>

<style scoped>

</style>