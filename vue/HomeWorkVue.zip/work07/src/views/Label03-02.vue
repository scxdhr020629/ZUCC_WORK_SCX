<template>
    <div id="app">
        <h1>记事本</h1>
        <input type="text" v-model="Newnote" @keyup.enter="addNote">
        <ul>
            <li v-for="(item,index) in notes" :key="index">
                <span class="number">{{ index+1 }}</span>
                <text>{{ item }}</text>
                <button @click="deleteNote(index)">删除</button>
            </li>
        </ul>
        <div v-if="notes.length > 0">
            条数:{{ notes.length }}
            <button @click="clearAll">清除所有记录</button>
        </div>
    </div>
</template>

<script>
    export default{
        data(){
            return{
                Newnote:"",
                notes:[]
            }
        },
        methods:{
            addNote(){
                if(this.Newnote){
                    this.notes.push(this.Newnote);
                    this.Newnote = '';
                }
            },
            deleteNote(index){
                this.notes.splice(index,1);
            },
            clearAll(){
                this.notes = []
            }
        }
    }
</script>

<style>
    *{
        box-sizing: border-box;
    }
    #app{
        max-width: 600px;
        margin: 0 auto;
    }
    h1{
        text-align: center;
    }
    input{
        width: 100%;
        padding: 10px;
        border: 2px solid black;
    }
    ul{
        list-style: none;
        padding: 0;
    }
    li{
        display: flex;
        align-items: center;
        margin: 10px 0;
        border-bottom: 2px solid black;
        padding-bottom: 10px;
    }
    .number{
        display: inline-block;
        width: 20px;
        height: 20px;
        line-height: 20px;
        text-align: center;
        background-color: gray;
        margin-right: 10px;
    }
    button{
        margin-left: auto;
    }
</style>
