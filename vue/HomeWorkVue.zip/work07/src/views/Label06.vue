<template>
    <div class="header">
        YSC管理系统
    </div>
    <div class="content left">
        <ul>
            <li><router-link to="/users">用户管理</router-link></li>
            <li><router-link to="/rights">权限管理</router-link></li>
            <li><router-link to="/goods">商品管理</router-link></li>
            <li><router-link to="/order">订单管理</router-link></li>
            <li><router-link to="/settings">系统设置</router-link></li>
        </ul>
    </div>
    <div class="content right">
        <router-view></router-view>
    </div>
    <div class="footer">
        版权页
    </div>
</template>

<style scoped>
    *{
        margin: 0px;
        padding: 0px;
    }
    .header,.footer{
        width: 100%;
        height: 50px;
        background-color: rgb(201, 195, 195);
        color: black;
        font-size: 20px;
        text-align: center;
        line-height: 50px;
    }
    .content{
        height: 580px;
        float: left;
    }
    .left{
        background-color: rgb(160, 203, 187);
        width: 20%;
    }
    .right{
        /* background-color: rgb(41, 205, 145); */
        width: 80%;
    }
    .left li{
        list-style: none;
        text-align: center;
        height: 40px;
        line-height: 40px;
        border-bottom: thistle;
        cursor: pointer;
    }
    .left li a{
        text-decoration-line: none;
    }
    .left li:hover{
        background-color: yellowgreen;
    }
    .footer{
        clear: both;
    }
</style>