<template>
    <div class="pre">内容为:{{Msg}}</div>
    <div class="after" v-bind:style="{fontSize:'20px'}">反转后内容为:{{ reverseMsg }}</div>
    <div class="total">反转前内容为{{ Msg }},反转后内容为{{ reverseMsg }}</div>
</template>

<script>
    export default{
        data(){
            return{
                Msg:'你好,欢迎学习vue'
            };
        },
        computed:{
            reverseMsg(){
                return this.Msg.split('').reverse().join('');
            },
        },
        mounted(){
            let divs = document.querySelectorAll('div');
            divs.forEach((div)=>{
                div.style.color = 'green'
            })
        }
    }
</script>
<style>
    .pre,
    .after,
    .total{
        color: green;
    }
</style>