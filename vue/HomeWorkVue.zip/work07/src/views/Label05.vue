<template>
    <div class="film">
        <div class="filmLeft">
            <!-- 电影的座位 -->
            <h3>屏幕</h3>
            <p style="text-align: center;color: red;" v-if="seatflag.length>0">({{ tips }})</p>
            <ul>
                <li v-for="(item,index) in seatflag" :key="index" class="seat"
                    :class="{'noSeat':seatflag[index]==-1,
                            'seatSpace':seatflag[index]==0,
                            'seatActive':seatflag[index]==1,
                            'seatNoUse':seatflag[index]==2}"
                    @click="handleClick(index)">
                </li>
            </ul>
        </div>
        <div class="filmRight">
            <div class="rightTop">
                <div class="rightTopleft">
                    <!-- 电影的海报 -->
                    <a href="#">
                        <img :src="require('../assets/长津湖.png')" alt="..." height="200">
                    </a>
                </div>
                <div class="rightTopRight">
                    <!-- 电影的基本信息 -->
                    <p>影片中文名:<strong>{{ filmInfo.name }}</strong></p>
                    <p>影片英文名:{{ filmInfo.nameEnglish }}</p>
                    <p>影片类型:{{ filmInfo.storyType }}</p>
                    <p>版本:{{ filmInfo.copyRight }}</p>
                    <p>{{ filmInfo.place }} / {{ filmInfo.timeLength }}</p>
                    <p>{{ filmInfo.timeShow }}</p>
                </div>
            </div>
            <div class="rightBootom">
                <!-- 电影的购买信息 -->
                <p>电影院:<strong>{{ filmInfo.cinema }}</strong></p>

                <p>
                    影厅:
                    <select v-model="selectedRoom" @change="changeRoom()">
                        <option selected="selected">请选择影厅</option>
                        <option v-for="(item,index) in filmInfo.room" :key="index">{{ item.name }}</option>
                    </select>
                </p>
                
                <p>
                    场次:
                    <select v-model="selectedTime" @change="changeSeatAndPrice()">
                        <option selected="selected">请选择场次</option>
                        <option v-for="(item,index) in selectedRoomObj.time" :key="index">{{ item }}</option>
                    </select>
                </p>

                <p>
                    座位:
                    <span v-for="(item,index) in curSeatDisp" :key="index" class="seatSelect">
                        {{ item }}
                    </span>
                </p>
                <p>
                    已选择
                    <strong style="color: red;">{{ count }}</strong>个座位
                    <strong style="color: red;">再次点击座位可取消。
                        <span v-if="maxFlag">您一次最多只能买五张票！</span>
                    </strong>
                </p>
                <hr>
                <p>单价：<strong>{{ numberFormat(unitPrice) }}</strong></p>
                <p>总价：<strong style="color: red;">{{ numberFormat(fileTotal) }}</strong></p>
                <hr>
                <button type="button" class="btn" @click="filmSubmit">
                    确认下单
                </button>
            </div>
        </div>
    </div>
</template>

<script>
    import { computed, reactive,toRefs} from 'vue';
    import data from "../../public/Label05.json";
    export default{
        setup(){
            const state = reactive({
                seatflag:[],
                filmInfo:data.filmInfo,
                curSeat:[],
                curSeatDisp:[],
                count:0,
                maxLength:5,
                unitPrice:0,
                maxFlag:false,
                seatCol:10,
                selectedRoom:'',
                selectedRoomObj:{},
                selectedTime:'',
                isFull:0,
                tips:"仍有余位",
                nowIndex:0
            })
            const handleClick = (index) => {
                if(state.seatflag[index]===1){
                    state.seatflag[index]=0;
                    state.curSeat.splice(state.curSeat.findIndex(item => item === index),1);
                }
                else{
                    if(state.seatflag[index]===0 && state.curSeat.length<5){
                        state.seatflag[index] = 1;
                        state.curSeat.push(index);
                    }
                }
                state.curSeatDisp = [];
                for(const data of state.curSeat){
                    state.curSeatDisp.push((Math.floor(data / state.seatCol) +1) + '行' + (data%state.seatCol+1)+'列')
                }
                var mySeat = state.seatflag.filter(item=>item===1)
                state.count = mySeat.length;
                if(state.count>=5){
                    state.maxFlag = true;
                }
                else{
                    state.maxFlag = false;
                }
            }
            const fileTotal = computed(()=>{
                return state.count*state.unitPrice
            })

            const changeRoom = () => {
                for(let i=0;i<state.filmInfo.room.length;i++){
                    if(state.selectedRoom===state.filmInfo.room[i].name){
                        state.selectedRoomObj = state.filmInfo.room[i]
                    }
                }
                state.seatflag = []
            }
            const changeSeatAndPrice = () => {
                for(let i=0;i<state.selectedRoomObj.time.length;i++){
                    if(state.selectedTime===state.selectedRoomObj.time[i]){
                        state.unitPrice = state.selectedRoomObj.unitPrice[i]
                        state.seatflag = state.selectedRoomObj.seatflag[i]
                        state.isFull = state.selectedRoomObj.isFull[i]
                        state.tips = state.selectedRoomObj.tips[i]
                        state.nowIndex = i
                    }
                }
                state.curSeat = [];
                state.curSeatDisp = [];
                state.count = 0;
            }
            const filmSubmit = () => {
                if(state.curSeat.length==0){
                    alert("请购买至少1张票")
                    return
                }
                var answer = confirm(`您的购买信息如下,请核对:\n影厅:${state.selectedRoom}\n场次:${state.selectedTime}\n座位:${state.curSeatDisp}\n共${state.count}张票,单价${state.unitPrice}元,总价${state.unitPrice*state.count}元\n请确认`)
                if(!answer) return
                window.alert("下单成功!")
                for(let i=0;i<state.curSeat.length;i++){
                    state.seatflag[state.curSeat[i]] = 2
                }

                //0位置未满,1位置已满
                for(let i=0;i<state.seatflag.length;i++){
                    if(state.seatflag[i]==0){
                        state.isFull = 0
                        break
                    }
                    state.isFull = 1
                }
                if(state.isFull==1){
                    state.tips = "座位已满"
                    state.selectedRoomObj.tips[state.nowIndex] = "座位已满"
                }
                state.curSeat = [];
                state.curSeatDisp = [];
                state.count = 0;
                state.maxFlag = false
            }
            const numberFormat = (value) => typeof value === 'number' ? '￥' + value.toFixed(2) : '￥0.00';
            return{
                ...toRefs(state),
                fileTotal,
                handleClick,
                numberFormat,
                changeRoom,
                changeSeatAndPrice,
                filmSubmit
            }
        }
    }
</script>

<style>
    .film{
        margin: 0 auto;
        width: 100%;
        height: 100%;

    }
    .filmLeft{
        width: 50%;
        height: 100%;
        float: left;
    }
    .filmLeft h3{
        text-align: center;
    }
    .filmLeft ul{
        list-style: none;
    }
    .filmRight{
        width: 50%;
        height: 100%;
        float: left;
        background-color: bisque;
    }
    .rightTopleft{
        float:left;
        margin: 20px 15px 5px 10px;
    }
    .rightTopRight{
        float: left;
        margin: 0px 0px 5px 5px;
    }
    .rightBootom{
        clear: both;
        margin: 0px 10px;
    }
    .rightBootom p{
        line-height: 18px;
    }
    .seat{
        float: left;
        width: 30px;
        height: 30px;
        margin: 5px 10px;
        cursor: pointer;
    }
    .seatSpace{
        background: url("../assets/seat.png") no-repeat 1px -29px;
    }
    .seatActive{
        background: url("../assets/seat.png") 1px 0px;
    }
    .seatNoUse{
        background: url("../assets/seat.png") 1px -56px;
    }
    .noSeat{
        background: url("../assets/seat.png") 1px -84px;
    }
    .btn{
        width: 100px;
        height: 60px;
        margin-left: 200px;
    }
    .seatSelect{
        border: 1px solid black;
        margin-left: 5px;
    }
</style>