<template>
    <div id="dynamic-component-demo" class="demo">
        <button v-for="(tab,index) in tabsName" v-bind:key="index"
            v-bind:class="['tab-button',{active:currentTab===index}]"
            v-on:click="currentTab=index">
            {{ tab }}
        </button>
        <component :is="currentTabComponent" class="tab"></component>
    </div>
</template>

<script>
import {computed, reactive,toRefs} from 'vue'
import child1 from '../components/Label07-7.2father.vue'
import child2 from '../components/Label07-7.3father.vue'
import child3 from '../components/Label07-7.5father.vue'
export default{
    components:{
        child1,
        child2,
        child3
    },
    setup(){
        const state = reactive({
            currentTab:0,
            tabsCompName:['child1','child2','child3'],
            tabsName:['7-2','7-3','7-5']
        })
        const currentTabComponent = computed(()=>{
            return state.tabsCompName[state.currentTab]
        })
        return{
            ...toRefs(state),
            currentTabComponent
        }
    }
}
</script>
<style scoped>
.tab-button{
    padding: 6px 10px;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
    border:1px solid pink;
    cursor: pointer;
    background: #f0f0f0;
    margin-bottom: -1px;
    margin-right: -1px;
}
.tab-button:hover{
    background: #f5d1d1;
}
.tab-button.active{
    background: #e0e0e0;
}
.demo-tab{
    border:1px solid #ccc;
    padding: 10px;
}
</style>