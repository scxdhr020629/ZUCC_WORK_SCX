import { createRouter, createWebHashHistory } from 'vue-router'

const routes = [
  {
    path:'/',
    redirect:'/users'
  },
  {
    path:'/users',
    name:'User',
    component:()=>import('../components/Label06-User.vue'),
    meta:{
      title:"用户信息"
    }
  },
  {
    path:'/userInfo',
    name:'UserInfo',
    component:()=>import('../components/Label06-UserInfo.vue'),
    meta:{
      title:"用户详情"
    }
  },
  {
    path:'/rights',
    name:'Rights',
    component:()=>import('../components/Label06-Rights.vue'),
    meta:{
      title:"权限管理"
    }
  },
  {
    path:'/goods',
    name:'Goods',
    component:()=>import('../components/Label06-Goods.vue'),
    meta:{
      title:"商品管理"
    }
  },
  {
    path:'/order',
    name:'Order',
    component:()=>import('../views/Label05.vue'),
    meta:{
      title:"订单管理"
    }
  },
  {
    path:'/settings',
    name:'Settings',
    component:()=>import('../components/Label06-Settings.vue'),
    meta:{
      title:"系统设置"
    }
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
