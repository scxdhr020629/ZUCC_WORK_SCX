//app.js
App({

  globalData: {
    client:null,
    humi:null,
    temp:null
  }
})