// pages/humitemp/humitemp.js
import * as echarts from '../../ec-canvas/echarts';


const app = getApp();
var mqtt = require('../../utils/mqtt.js');

function initChartHumi(canvas, width, height, dpr) {

  const chart = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio: dpr
  });
  canvas.setChart(chart);
  var humi = parseInt(app.globalData.humi);
  var temp = parseInt(app.globalData.temp);
  var option = {
    tooltip: {
      formatter: '{a} <br/>{b} : {c}%'
    },
    series: [
      {
        name: 'Pressure',
        type: 'gauge',
        detail: {
          formatter: '{value}'
        },
        data: [
          {
            value: parseInt(app.globalData.humi),
            name: 'humi'
          }
        ]
      }
    ]
  };

  setInterval(function() {
    option.series[0].data[0].value = parseInt(app.globalData.humi);
    chart.setOption(option, true);
  }, 2000)

  chart.setOption(option,true);
  return chart;
}

function initChartTemp(canvas, width, height, dpr) {

  const chart = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio: dpr
  });
  canvas.setChart(chart);
  var humi = parseInt(app.globalData.humi);
  var temp = parseInt(app.globalData.temp);
  var option = {
    series: [
      {
        type: 'gauge',
        center: ['50%', '60%'],
        startAngle: 200,
        endAngle: -20,
        min: 0,
        max: 60,
        splitNumber: 12,
        itemStyle: {
          color: '#FFAB91'
        },
        progress: {
          show: true,
          width: 30
        },
        pointer: {
          show: false
        },
        axisLine: {
          lineStyle: {
            width: 30
          }
        },
        axisTick: {
          distance: -45,
          splitNumber: 5,
          lineStyle: {
            width: 2,
            color: '#999'
          }
        },
        splitLine: {
          distance: -52,
          length: 14,
          lineStyle: {
            width: 3,
            color: '#999'
          }
        },
        axisLabel: {
          distance: -20,
          color: '#999',
          fontSize: 20
        },
        anchor: {
          show: false
        },
        title: {
          show: false
        },
        detail: {
          valueAnimation: true,
          width: '60%',
          lineHeight: 40,
          borderRadius: 8,
          offsetCenter: [0, '-15%'],
          fontSize: 60,
          fontWeight: 'bolder',
          formatter: '{value} °C',
          color: 'auto'
        },
        data: [
          {
            value: parseInt(app.globalData.temp)
          }
        ]
      },
      {
        type: 'gauge',
        center: ['50%', '60%'],
        startAngle: 200,
        endAngle: -20,
        min: 0,
        max: 60,
        itemStyle: {
          color: '#FD7347'
        },
        progress: {
          show: true,
          width: 8
        },
        pointer: {
          show: false
        },
        axisLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        splitLine: {
          show: false
        },
        axisLabel: {
          show: false
        },
        detail: {
          show: false
        },
        data: [
          {
            value: parseInt(app.globalData.temp)
          }
        ]
      }
    ]
  };
  setInterval(function () {
    
    chart.setOption({
      series: [
        {
          data: [
            {
              value: parseInt(app.globalData.temp)
            }
          ]
        },
        {
          data: [
            {
              value: parseInt(app.globalData.temp)
            }
          ]
        }
      ]
    });
  }, 2000);



  chart.setOption(option,true);
  return chart;
}









Page({
  data: {
    
    ec: {
      onInit: initChartHumi
    },
    ec1:{
      onInit: initChartTemp
    }
  }
})
