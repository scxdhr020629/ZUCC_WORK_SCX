package cn.edu.zucc.model;

import java.util.List;

public class Knowledge {
    private int id;
    private String name;
    private String importantIntroduction;
    //
    private List<String> anLi;
    // 这里可能出错
    private List<Knowledge> usedKnowledge;

    private String description;
}
