package cn.edu.zucc.controller;

import cn.edu.zucc.model.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MVCJsonController {
    //映射URL地址
    @GetMapping("/jsonobject")
    public User queryUser() {
        //实例化对象
        User user=new User();
        user.setName("城院青年");
        user.setAge(22);
        return user;
    }
}
