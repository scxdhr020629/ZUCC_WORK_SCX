package cn.edu.zucc.controller;

import cn.edu.zucc.model.Course;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/courses")
public class CourseController {

    @GetMapping()
    public Course queryUser() {
        //实例化对象
        Course course = new Course();
        //设置值
        course.setId(1);
        course.setCid("");
        return course;
    }
}
