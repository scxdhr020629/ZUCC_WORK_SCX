package cn.edu.zucc.controller;

import cn.edu.zucc.model.User;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("student")
public class MVCParamController {
    //映射URL地址
    @RequestMapping("query/{clazz}/{name}")
    public User queryUser(@PathVariable("clazz") String clazz,
                          @PathVariable("name") String name) {
        //查询
        User user = new User();
        user.setName(name);
        user.setAge(22);
        return user;
    }
}
