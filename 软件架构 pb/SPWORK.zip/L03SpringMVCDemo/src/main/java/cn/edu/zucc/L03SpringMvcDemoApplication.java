package cn.edu.zucc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L03SpringMvcDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(L03SpringMvcDemoApplication.class, args);
	}

}
