package ysc.teamwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamworkApplicationTests {

    @Test
    void contextLoads() {
    }

}
