package ysc.teamwork.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import ysc.teamwork.entity.Course;
import ysc.teamwork.service.CourseService;

import java.util.List;

@RestController
@RequestMapping("/course")
public class CourseController {
    @Autowired
    private CourseService courseService;

    //增加课程信息
    @PostMapping("/add")
    public Course add(Course course){
        return courseService.add(course);
    }

    //根据主键id删除课程
    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Integer id){
        courseService.delete(id);
        return "成功删除课程"+id;
    }

    //修改课程信息
    @PostMapping("/update")
    public Course update(Course course){
        return courseService.update(course);
    }

    //根据课程主键查询课程
    @GetMapping("/findById/{id}")
    public Course findById(@PathVariable Integer id){
        return courseService.findCourseByIid(id);
    }
    //根据课程编号查询课程
    @GetMapping("/findByCourseId/{id}")
    public List<Course> findByCourseId(@PathVariable String id){
        return courseService.findCourseByCourse_id(id);
    }
    //根据课程名称查询课程
    @GetMapping("/findByName/{name}")
    public List<Course> findByName(@PathVariable String name){
        return courseService.findCourseByCourse_name(name);
    }
    //根据课程学分查询课程
    @GetMapping("/findByCredit/{credit}")
    public List<Course> findByCredit(@PathVariable Double credit){
        return courseService.findCourseByCourse_credit(credit);
    }
    //根据课程教师查询课程
    @GetMapping("/findByTeacher/{teacher}")
    public List<Course> findByTeacher(@PathVariable String teacher){
        return courseService.findCourseByTeacher(teacher);
    }
}
