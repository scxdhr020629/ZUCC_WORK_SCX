package ysc.teamwork.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ysc.teamwork.entity.Course;
import ysc.teamwork.repository.CourseRepository;
import ysc.teamwork.service.CourseService;

import java.util.List;

@Service
public class CourseServiceImpl implements CourseService {
    @Autowired
    private CourseRepository courseRepository;
    @Override
    public Course add(Course course) {
        return courseRepository.save(course);
    }

    @Override
    public void delete(Integer id) {
        courseRepository.deleteById(id);
    }

    @Override
    public Course update(Course course) {
        return courseRepository.save(course);
    }

    @Override
    public Course findCourseByIid(Integer id) {
        return courseRepository.findCourseByIid(id);
    }

    @Override
    public List<Course> findCourseByCourse_id(String course_id) {
        return courseRepository.findCourseByCourse_id(course_id);
    }

    @Override
    public List<Course> findCourseByCourse_name(String course_name) {
        return courseRepository.findCourseByCourse_name(course_name);
    }

    @Override
    public List<Course> findCourseByCourse_credit(Double course_credit) {
        return courseRepository.findCourseByCourse_credit(course_credit);
    }

    @Override
    public List<Course> findCourseByTeacher(String teacher) {
        return courseRepository.findCourseByTeacher(teacher);
    }


}
