package ysc.teamwork.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ysc.teamwork.entity.Course;

import java.util.List;

public interface CourseRepository extends JpaRepository<Course,Integer> {
    //通过主键查询课程
    Course findCourseByIid(Integer id);

    //通过课程编号查询课程
    @Query(name = "findCourseByCourse_id",nativeQuery = true,value = "select c.*,t.teacher_name,t.teacher_phone from course c,teacher t\n" +
            "where c.teacher_id = t.teacher_id and c.course_id=:course_id")
    List<Course> findCourseByCourse_id(@Param("course_id") String course_id);

    //通过课程名称查询课程
    @Query(name = "findCourseByCourse_name",nativeQuery = true,value = "select c.*,t.teacher_name,t.teacher_phone from course c,teacher t\n" +
            "where c.teacher_id = t.teacher_id and c.course_name=:course_name")
    List<Course> findCourseByCourse_name(@Param("course_name") String course_name);

    //通过课程学分查询课程
    @Query(name = "findCourseByCourse_credit",nativeQuery = true,value = "select c.*,t.teacher_name,t.teacher_phone from course c,teacher t\n" +
            "where c.teacher_id = t.teacher_id and c.course_credit=:course_credit")
    List<Course> findCourseByCourse_credit(@Param("course_credit") Double course_credit);

    //通过任课老师查询课程
    @Query(name = "findCourseByTeacher",nativeQuery = true,value = "select c.*,t.teacher_name,t.teacher_phone from course c,teacher t\n" +
            "where c.teacher_id = t.teacher_id and t.teacher_name=:teacher")
    List<Course> findCourseByTeacher(@Param("teacher") String teacher);
}
