package ysc.teamwork.service;

import org.springframework.data.repository.query.Param;
import ysc.teamwork.entity.Course;

import java.util.List;

public interface CourseService {
    Course add(Course course);
    void delete(Integer id);
    Course update(Course course);
    Course findCourseByIid(Integer id);
    List<Course> findCourseByCourse_id(String course_id);
    List<Course> findCourseByCourse_name(String course_name);
    List<Course> findCourseByCourse_credit(Double course_credit);
    List<Course> findCourseByTeacher(String teacher);
}
