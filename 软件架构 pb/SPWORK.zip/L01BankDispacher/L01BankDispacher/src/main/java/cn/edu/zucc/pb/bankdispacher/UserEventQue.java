package cn.edu.zucc.pb.bankdispacher;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 用户排队队列
 * @author pengbin
 * @version 1.0
 */
public class UserEventQue {
    private static int SEQ = 0; // 公用

    //队列
    private List<UserEvent> events = new ArrayList<UserEvent>();

    //单例模式使用UserEventQue
    private static UserEventQue instance = new UserEventQue();  // 公用
    private UserEventQue(){}
    public static UserEventQue getInstance(){
        return instance;
    }

    /**
     * 分配一个用户事件，对应比如用户在叫号机上按一下
     * @param category 来的用户类别
     * @return
     */
    public UserEvent nextUserArrive(EUserCategory category){
        UserEvent event = new UserEvent();
        event.setArriveTime(new Date());
        event.setCategory(category);
//        System.out.println("尝试一下get的输出 "+event.getCategory());
        //保证线程安全；TODO: 思考，这里为什么需要保证线程安全
        // 不保证线程安全的话，添加事件的顺序就会出错。

        synchronized (UserEventQue.class){
            System.out.println("----------------------------------------------------------");
            System.out.println("添加排队锁死");

            event.setSeq(SEQ++);
//            System.out.println("输出这个时间到达的时间");
//            System.out.println(event.getArriveTime());
            System.out.println("我是"+event.getCategory()+"来办理业务");
            System.out.println("当前我的seq序号为"+event.getSeq());
            events.add(event);
        }

        return event;
    }

    /**
     * 分派一个用户到窗口处理
     * @return
     */
    public UserEvent dispatchUser(){
        //使用工厂类动态加载算法实现类
        IUserSelector selector = UserSelectorFactory.getSelector();
//        System.out.println(selector);

//        不晓得这一行为什么会输出一点hashcode
        if(selector != null){
            //保证线程安全；TODO: 思考，这里为什么需要保证线程安全
            // 不保证线程安全的话，删除顺序会出错，导致select里的index 出现差错
            synchronized (UserEventQue.class){
                System.out.println("----------------------------------------------");
                System.out.println("删除事件开始，并进行锁死");
                UserEvent event = selector.select(events);
                // 选择优先的算法
                //TODO 移除队列中选中的event


                if(event == null){
                    System.out.println("队列里面现在还没有东西呢，你这三个柜台急啥");
                }
                else
                {
//                    System.out.println("哈哈哈，我删掉了");
                    System.out.println("" +event.getCategory()+"正在办理业务");
                    System.out.println("序号为 "+event.getSeq());
                    events.remove((event));
                }
                System.out.println("----------------------------------------------");
                return event;
            }

        }

        return null;
    }
}
