package cn.edu.zucc.pb.bankdispacher;

import cn.edu.zucc.pb.bankdispacher.simulator.BankCounter;
import cn.edu.zucc.pb.bankdispacher.simulator.UserGenerator;

import java.io.IOException;
import java.util.Properties;

/**
 * 主控程序，让仿真程序和实际的调度程序运行起来
 * @author pengbin
 * @version 1.0
 */
public class Main {
    public static void main(String[] args) {
        //TODO 实现从配置文件 bank.properties加载counter.count配置项
        int counterCount = 1;
        // 这里目前使用的是绝对路径
        String f = "E:\\SPWORK\\L01BankDispacher\\L01BankDispacher\\src\\main\\java\\cn\\edu\\zucc\\pb\\bankdispacher\\bank.properties";
        Properties props = new Properties();
        try {
            props.load(new java.io.FileInputStream(f));
            counterCount = Integer.parseInt(props.getProperty("counter.count"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        // 原先老师设置的为 1 改为 3
        System.out.println("*********"+counterCount);
        //创建n个柜台，仿真银行开门
        for(int i = 0; i < counterCount; i++){
            Thread counterThread = new Thread("Counter-" + i){
                @Override
                public void run() {
                    BankCounter counter = new BankCounter();
                    counter.start();
                }
            };
            counterThread.start();
        }

        //开始启动用户产生仿真
        // 模拟生成一百个用户吧

        Thread userGenerator = new Thread("UserGenerator"){
            @Override
            public void run() {
//                BankCounter counter = new BankCounter();
//                counter.start();
                UserGenerator users = new UserGenerator();
                users.start(20);
            }
        };
        userGenerator.start();
        System.out.println("主线程结束");
        /**TODO 如果这里什么都不做，那么主线程就退出了，上面启动的所有仿真线程还活着
            这个是不好的设计，请修改这个main方法，是否可以做到可以控制所有的仿真线程在
            仿真运行比如100个用户后可以恰当的退出
         */
        // 设置了一个计时器。然后counter线程结束了运行
        // 生成用户线程在生成二十个用户之后结束运行
    }


}
