package cn.edu.zucc.pb.bankdispacher;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

/**
 * 此类从bank.properties文件加载selector，实现用户选择算法实现的动态加载
 * 重点体会
 * 1）接口约定规范的服务
 * 2）用反射动态获取实现类实现动态性
 * @author pengbin
 * @version 1.0
 */
public class UserSelectorFactory {
    public static IUserSelector getSelector(){
        //TODO 实现从配置文件 bank.properties加载selector配置项
        String selectorName = "实现配置文件加载";
        String f = "E:\\SPWORK\\L01BankDispacher\\L01BankDispacher\\src\\main\\java\\cn\\edu\\zucc\\pb\\bankdispacher\\bank.properties";
        Properties props = new Properties();
        try {
            props.load(new java.io.FileInputStream(f));
            selectorName = props.getProperty("selector");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

//        System.out.println(selectorName);
        //TODO 通过反射接口从上面的selectorName进行实现类创建
        IUserSelector selector = null;
        if(selectorName.equals("cn.edu.zucc.pb.bankdispacher.VipFirstSelector")){
            // 使用 vip 优先算法
            selector = new VipFirstSelector();
        }
        else if(selectorName.equals("cn.edu.zucc.pb.bankdispacher.TimeFirstSelector")){
            // 使用 时间 优先算法
            selector = new TimeFirstSelector();
        }
        else {
            selector = null;
        }



        return selector;
    }
}
