package cn.edu.zucc.pb.bankdispacher.simulator;

import cn.edu.zucc.pb.bankdispacher.UserEvent;
import cn.edu.zucc.pb.bankdispacher.UserEventQue;
import org.apache.commons.lang3.RandomUtils;

/**
 * 银行柜台办理业务仿真程序
 *
 * @author pengbin
 * @version 1.0
 */
public class BankCounter {
    /**
     * 模拟柜台开始办理业务
     */
    public void start() {
        //TODO 增加柜台下班的控制
        //while(true)柜台一直不下班
    // 初步写一个判断
        boolean flag = true;
        long startTime = System.currentTimeMillis();


        while (flag) {
            UserEvent userEvent = UserEventQue.getInstance().dispatchUser();// 办理一个取消一个

            //等待一点时间,模拟在办理或者等待
            //TODO 实现不同业务类型等待不同时间
            // userEvent 可能为空
            if (userEvent != null) {
                if (userEvent.getCategory().ordinal() == 0) {
                    // vip 用户 办理时间就短一点吧
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                } else if (userEvent.getCategory().ordinal() == 1) {
                    // 私人用户 那处理时间长一点吧
                    try {
                        Thread.sleep(12000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    try {
                        Thread.sleep(6000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            } else {
                //为空
                waitSomeTime();
            }

            long currentTime = System.currentTimeMillis();
            if (currentTime - startTime >= 120000) {
                flag = false;
                System.out.println("超过两分钟了，这个柜台休息了");
            }


        }
    }

    private void waitSomeTime() {
        //随机2秒到12秒之间
        try {
            Thread.sleep(RandomUtils.nextInt(2000, 12000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return;
    }

}
