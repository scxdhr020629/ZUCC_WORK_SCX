package cn.edu.zucc.pb.bankdispacher;

import java.util.List;

/**
 * Vip优先选择器，队列中如果有vip，优先处理，其他按照到达时间顺序处理
 *
 * @author pengbin
 * @version 1.0
 */
public class VipFirstSelector implements IUserSelector {
    public UserEvent select(List<UserEvent> events) {
        //TODO 实现vip优先算法的用户选择器
        int vipIndex = -1;
        for (int i = 0; i < events.size(); i++) {
            UserEvent event = events.get(i);
            if (event.getCategory().ordinal()==0) {
                vipIndex = i;
                break;
            }
        }
        System.out.println("输出一下vipIndex"+vipIndex);
        if (vipIndex != -1) {
            // 说明 有 vip 先处理
            System.out.println("好欸，查询到一个vip");
            return events.get(vipIndex);
        } else if (!events.isEmpty()) {
            // 没有vip
            return events.get(0);
        } else {
            // 列表为空
            return null;
        }

    }
}
