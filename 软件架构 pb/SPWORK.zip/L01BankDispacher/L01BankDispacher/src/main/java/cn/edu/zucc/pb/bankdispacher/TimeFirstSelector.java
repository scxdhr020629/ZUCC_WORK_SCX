package cn.edu.zucc.pb.bankdispacher;

import java.util.List;

/**
 * 时间优先选择器，按照到达时间顺序处理
 * @author pengbin
 * @version 1.0
 */
public class TimeFirstSelector implements IUserSelector {
    public UserEvent select(List<UserEvent> events) {
        //TODO 实现到达时间优先算法的用户选择器
        // 因为进来的时候就是按照时间顺序进来的，所以只需要访问第一个数据即可
        if(!events.isEmpty()){
            //如果不为空

            return events.get(0);
        }
        else {
            return null;
        }
    }
}
