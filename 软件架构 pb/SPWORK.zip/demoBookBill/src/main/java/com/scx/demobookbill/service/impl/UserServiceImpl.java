package com.scx.demobookbill.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.scx.demobookbill.entity.User;
import com.scx.demobookbill.mapper.UserMapper;
import com.scx.demobookbill.service.UserService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {


    @Override
    public List<User> selectAll() {
        return null;
    }
}
