package com.scx.demobookbill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoBookBillApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoBookBillApplication.class, args);
    }

}
