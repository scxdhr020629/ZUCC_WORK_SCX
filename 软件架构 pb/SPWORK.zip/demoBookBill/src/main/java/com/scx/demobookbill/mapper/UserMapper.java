package com.scx.demobookbill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.scx.demobookbill.entity.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserMapper extends BaseMapper<User> {
    public List<User> selectAll();
}
