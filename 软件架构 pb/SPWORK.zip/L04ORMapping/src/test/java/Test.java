import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

 class Box<T> {
    private T data;
    // ...
}

 class IntegerBox extends Box<Integer> {
}

public class Test {
    public static void main(String[] args) {
        IntegerBox integerBox = new IntegerBox();
        Type superclassType = integerBox.getClass().getGenericSuperclass();
        if (superclassType instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType) superclassType;
            Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
            for (Type type : actualTypeArguments) {
                System.out.println("泛型类型参数：" + type.getTypeName());
            }
        }
    }
}
