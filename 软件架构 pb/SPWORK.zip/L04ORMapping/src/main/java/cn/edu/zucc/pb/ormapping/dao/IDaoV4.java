package cn.edu.zucc.pb.ormapping.dao;

/**
 * @author pengbin
 * @version 1.0
 */
public interface IDaoV4<T> {
    T getEntity(String key, String clazz);
}
