package cn.edu.zucc.pb.ormapping.entity;

/**
 * @author pengbin
 * @version 1.0
 */
public class DepartmentEntity {
    private String userid;
    private String name;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
