package cn.edu.zucc.pb.ormapping.view;

/**
 * @author pengbin
 * @version 1.0
 * @date 2020-03-11 17:50
 */
public class User {
    private String name;
    private String userid;
    private String password;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
