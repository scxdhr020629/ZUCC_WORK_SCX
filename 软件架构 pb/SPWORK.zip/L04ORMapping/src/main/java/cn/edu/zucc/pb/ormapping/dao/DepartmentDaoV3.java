package cn.edu.zucc.pb.ormapping.dao;

import cn.edu.zucc.pb.ormapping.db.DataBaseManager;
import cn.edu.zucc.pb.ormapping.entity.DepartmentEntity;
import cn.edu.zucc.pb.ormapping.entity.UserEntity;

import java.sql.Connection;
import java.sql.SQLException;

public class DepartmentDaoV3 implements IDepartmentDao{
    @Override
    public DepartmentEntity getDepartment(String deptid) {
        return null;
    }
}
