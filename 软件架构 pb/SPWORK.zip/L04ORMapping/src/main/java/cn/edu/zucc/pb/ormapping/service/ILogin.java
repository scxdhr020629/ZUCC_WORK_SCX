package cn.edu.zucc.pb.ormapping.service;

public interface ILogin {
    public boolean login(String userid, String password);
}
