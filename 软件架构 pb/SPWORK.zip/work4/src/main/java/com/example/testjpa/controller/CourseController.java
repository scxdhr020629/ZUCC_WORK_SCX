package com.example.testjpa.controller;

import com.example.testjpa.entity.CourseEntity;
import com.example.testjpa.repository.CourseEntityRepository;
import com.example.testjpa.repository.KnowledgeEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("courses")
public class CourseController {
    @Autowired
    private CourseEntityRepository courseEntityRepository;

    @Autowired
    private KnowledgeEntityRepository knowledgeEntityRepository;
    // 下面的查询部分写的不好，到时候要查询整合到一起
    // 查询所有课程
    @GetMapping
    public List<CourseEntity> findList(){
        return courseEntityRepository.findAll();
    }


    // 根据课程代码查询课程
    @GetMapping("/{course_id}")
    public List<CourseEntity> findCourseByCourseId(@PathVariable String course_id){
        return courseEntityRepository.findCourseEntitiesByCourseId(course_id);

    }

    // 根据课程名称查询课程
    @GetMapping("/name/{course_name}")
    public List<CourseEntity> findCourseByCourseName(@PathVariable String course_name){
        return courseEntityRepository.findCourseEntitiesByCourseName(course_name);

    }

    // 根据学分查询课程
    @GetMapping("/credit/{course_credit}")
    public List<CourseEntity> findCourseByCourseCredit(@PathVariable float course_credit){
        return courseEntityRepository.findCourseEntitiesByCourseCredit(course_credit);
    }



    // 增加一门课程
//    @PostMapping
//    public String createOneCourse(@RequestBody Map<String,String> queryExample){
//        // 写的太罗嗦
////        Integer iid = Integer.parseInt(queryExample.get("iid"));
//        String courseId = queryExample.get("course_id");
//        String courseName = queryExample.get("course_name");
//        String courseDescription = queryExample.get("course_description");
//        float courseCredit = Float.parseFloat(queryExample.get("course_credit"));
//        String teacherId = queryExample.get("teacher_id");
////        System.out.println(courseId);
//        CourseEntity courseEntity = new CourseEntity();
////        courseEntity.setIid(iid);
//        courseEntity.setCourseId(courseId);
//        courseEntity.setCourseName(courseName);
//        courseEntity.setCourseDescription(courseDescription);
//        courseEntity.setCourseCredit(courseCredit);
//        courseEntity.setTeacherId(teacherId);
////        System.out.println(courseEntity.getIid());
//        courseEntityRepository.save(courseEntity);
//
//        return "done";
//    }
    // 和上面的的重复了。其实没必要这样写的，但是想put post区分开


    // 重新写一段,更改之后，不需要判断是否有iid了

    @PostMapping
    public String createOneCourse(@RequestBody CourseEntity courseEntity){
        System.out.println(courseEntity.getTeacherEntity().getIid());
        System.out.println(courseEntity.getLabelEntities().get(0).getIid());
        courseEntityRepository.save(courseEntity);
//        System.out.println(courseEntity.getKnowledgeEntities().get(0).getIid());
//        knowledgeEntityRepository.save(courseEntity.getKnowledgeEntities().get(0));
        return "done";
    }


//    @PutMapping
//    public String updateOneCourse(@RequestBody Map<String,String> queryExample){
//        Integer iid = Integer.parseInt(queryExample.get("iid"));
//        String courseId = queryExample.get("course_id");
//        String courseName = queryExample.get("course_name");
//        String courseDescription = queryExample.get("course_description");
//        float courseCredit = Float.parseFloat(queryExample.get("course_credit"));
//        String teacherId = queryExample.get("teacher_id");
////        System.out.println(courseId);
//        CourseEntity courseEntity = new CourseEntity();
//        courseEntity.setIid(iid);
//        courseEntity.setCourseId(courseId);
//        courseEntity.setCourseName(courseName);
//        courseEntity.setCourseDescription(courseDescription);
//        courseEntity.setCourseCredit(courseCredit);
//        courseEntity.setTeacherId(teacherId);
//
//        courseEntityRepository.save(courseEntity);
//
//        return "done";
//    }



    // 删除一门课程,这里使用的是iid删除
    @DeleteMapping("{iid}")
    public String deleteCourseById(@PathVariable Integer iid){
        courseEntityRepository.deleteById(iid);
        return "done";
    }

    

}
