package com.example.testjpa.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "course", schema = "zuccqa", catalog = "")
public class CourseEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "iid")
    private int iid;
    @Basic
    @Column(name = "course_id")
    private String courseId;
    @Basic
    @Column(name = "course_name")
    private String courseName;
    @Basic
    @Column(name = "course_description")
    private String courseDescription;


    @Basic
    @Column(name = "course_credit")
    private float courseCredit;

    // 教材属性是新加的。所以放这里了

    @Basic
    @Column(name = "course_used_book")
    private  String courseUsedBook;


    public String getCourseUsedBook() {
        return courseUsedBook;
    }

    public void setCourseUsedBook(String courseUsedBook) {
        this.courseUsedBook = courseUsedBook;
    }




//    @Basic
//    @Column(name = "teacher_iid")
//    private int teacherIid;


    @ManyToOne(cascade={CascadeType.MERGE,CascadeType.REFRESH},optional=false)//可选属性optional=false,表示author不能为空。删除文章，不影响用户
    @JoinColumn(name="teacher_iid")//设置在article表中的关联字段(外键)
    private TeacherEntity teacherEntity;//所属作者

    public TeacherEntity getTeacherEntity() {
        return teacherEntity;
    }

    public void setTeacherEntity(TeacherEntity teacherEntity) {
        this.teacherEntity = teacherEntity;
    }

    // 多对多测试
    @ManyToMany
    @JoinTable(name = "map_course_knowledge"
    ,joinColumns = {@JoinColumn(name = "course_iid")},
    inverseJoinColumns = {@JoinColumn(name = "knowledge_iid")})
    private List<KnowledgeEntity> knowledgeEntities;

    public List<KnowledgeEntity> getKnowledgeEntities() {
        return knowledgeEntities;
    }

    public void setKnowledgeEntities(List<KnowledgeEntity> knowledgeEntities) {
        this.knowledgeEntities = knowledgeEntities;
    }




    @ManyToMany
    @JoinTable(name = "map_course_label"
    ,joinColumns = {@JoinColumn(name = "course_iid")},
    inverseJoinColumns = {@JoinColumn(name = "label_iid")})
    private  List<LabelEntity> labelEntities;
    public List<LabelEntity> getLabelEntities() {
        return labelEntities;
    }

    public void setLabelEntities(List<LabelEntity> labelEntities) {
        this.labelEntities = labelEntities;
    }


    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseDescription() {
        return courseDescription;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }

    public float getCourseCredit() {
        return courseCredit;
    }

    public void setCourseCredit(float courseCredit) {
        this.courseCredit = courseCredit;
    }

//    public int getTeacherIid() {
//        return teacherIid;
//    }
//
//    public void setTeacherIid(int teacherIid) {
//        this.teacherIid = teacherIid;
//    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CourseEntity that = (CourseEntity) o;
//        return iid == that.iid && Objects.equals(courseId, that.courseId) && Objects.equals(courseName, that.courseName) && Objects.equals(courseDescription, that.courseDescription) && Objects.equals(teacherIid, that.teacherIid);
        return iid == that.iid && Objects.equals(courseId, that.courseId) && Objects.equals(courseName, that.courseName) && Objects.equals(courseDescription, that.courseDescription);

    }

    @Override
    public int hashCode() {
        return Objects.hash(iid, courseId, courseName, courseDescription);
    }
}
