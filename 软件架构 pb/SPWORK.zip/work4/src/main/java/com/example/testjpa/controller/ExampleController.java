package com.example.testjpa.controller;

import com.example.testjpa.entity.ExampleEntity;
import com.example.testjpa.repository.ExampleEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/examples")
public class ExampleController {
    @Autowired
    private ExampleEntityRepository exampleEntityRepository;

    @GetMapping
    public List<ExampleEntity> findAll(){
        return exampleEntityRepository.findAll();
    }
    // 通过id 来进行查找
    @GetMapping("/iid/{iid}")
    public java.util.Optional<ExampleEntity> findExampleById(@PathVariable Integer iid){
        return exampleEntityRepository.findById(iid);
    }

//    @PostMapping
//    public String createOneExample(@RequestBody Map<String,String> queryExample){
//        String exampleId = queryExample.get("example_id");
//        String exampleUrl = queryExample.get("example_url");
//        ExampleEntity exampleEntity = new ExampleEntity();
//        exampleEntity.setExampleId(exampleId);
//        exampleEntity.setExampleUrl(exampleUrl);
//        exampleEntityRepository.save(exampleEntity);
//        return"done";
//    }
//
//    @PutMapping
//    public String updateOneExample(@RequestBody Map<String,String> queryExample){
//        Integer iid = Integer.parseInt(queryExample.get("iid"));
//        String exampleId = queryExample.get("example_id");
//        String exampleUrl = queryExample.get("example_url");
//        ExampleEntity exampleEntity = new ExampleEntity();
//        exampleEntity.setIid(iid);
//        exampleEntity.setExampleId(exampleId);
//        exampleEntity.setExampleUrl(exampleUrl);
//        exampleEntityRepository.save(exampleEntity);
//        return "done";
//    }

    @PostMapping
    public String updateOneExample(@RequestBody ExampleEntity exampleEntity){
        exampleEntityRepository.save(exampleEntity);
        return "done";
    }

    @DeleteMapping("{iid}")
    public String deleteOneExampleById(@PathVariable Integer iid){
        exampleEntityRepository.deleteById(iid);
        return "done";
    }

}
