package com.example.testjpa.entity;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "knowledge", schema = "zuccqa", catalog = "")
public class KnowledgeEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "iid")
    private int iid;
    @Basic
    @Column(name = "knowledge_id")
    private String knowledgeId;
    @Basic
    @Column(name = "knowledge_description")
    private String knowledgeDescription;
    @Basic
    @Column(name = "knowledge_important_description")
    private String knowledgeImportantDescription;
    @Basic
    @Column(name = "pre_knowledge_iid")
    private Integer preKnowledgeIid;


    @ManyToMany(mappedBy = "knowledgeEntities")
    private List<CourseEntity> courseEntities;

    public List<CourseEntity> getCourseEntities() {
        return courseEntities;
    }

    public void setCourseEntities(List<CourseEntity> courseEntities) {
        this.courseEntities = courseEntities;
    }



    @ManyToMany
    @JoinTable(name = "map_knowledge_example"
            ,joinColumns = {@JoinColumn(name = "knowledge_iid")},
            inverseJoinColumns = {@JoinColumn(name = "example_iid")})
    private List<ExampleEntity> exampleEntities;

    public List<ExampleEntity> getExampleEntities() {
        return exampleEntities;
    }

    public void setExampleEntities(List<ExampleEntity> exampleEntities) {
        this.exampleEntities = exampleEntities;
    }


    @ManyToMany
    @JoinTable(name = "map_knowledge_label"
            ,joinColumns = {@JoinColumn(name = "knowledge_iid")},
            inverseJoinColumns = {@JoinColumn(name = "label_iid")})
    private List<LabelEntity> labelEntities;

    public List<LabelEntity> getLabelEntities() {
        return labelEntities;
    }

    public void setLabelEntities(List<LabelEntity> labelEntities) {
        this.labelEntities = labelEntities;
    }

    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public String getKnowledgeId() {
        return knowledgeId;
    }

    public void setKnowledgeId(String knowledgeId) {
        this.knowledgeId = knowledgeId;
    }

    public String getKnowledgeDescription() {
        return knowledgeDescription;
    }

    public void setKnowledgeDescription(String knowledgeDescription) {
        this.knowledgeDescription = knowledgeDescription;
    }

    public String getKnowledgeImportantDescription() {
        return knowledgeImportantDescription;
    }

    public void setKnowledgeImportantDescription(String knowledgeImportantDescription) {
        this.knowledgeImportantDescription = knowledgeImportantDescription;
    }

    public Integer getPreKnowledgeIid() {
        return preKnowledgeIid;
    }

    public void setPreKnowledgeIid(Integer preKnowledgeIid) {
        this.preKnowledgeIid = preKnowledgeIid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        KnowledgeEntity that = (KnowledgeEntity) o;
        return iid == that.iid && Objects.equals(knowledgeId, that.knowledgeId) && Objects.equals(knowledgeDescription, that.knowledgeDescription) && Objects.equals(knowledgeImportantDescription, that.knowledgeImportantDescription) && Objects.equals(preKnowledgeIid, that.preKnowledgeIid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(iid, knowledgeId, knowledgeDescription, knowledgeImportantDescription, preKnowledgeIid);
    }
}
