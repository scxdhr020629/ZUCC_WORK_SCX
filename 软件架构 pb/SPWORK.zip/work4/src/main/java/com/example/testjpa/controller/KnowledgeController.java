package com.example.testjpa.controller;

import com.example.testjpa.entity.KnowledgeEntity;
import com.example.testjpa.repository.CourseEntityRepository;
import com.example.testjpa.repository.KnowledgeEntityRepository;
import com.example.testjpa.repository.LabelGroupEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/knowledge")
public class KnowledgeController {
    @Autowired
    private KnowledgeEntityRepository knowledgeEntityRepository;


    @GetMapping
    public List<KnowledgeEntity> findAll(){
        return knowledgeEntityRepository.findAll();
    }

    // 根据iid 来进行查询，因为直接选中
    @GetMapping("iid/{iid}")
    public java.util.Optional<KnowledgeEntity> findKnowledgeByIid(@PathVariable Integer iid){
        return knowledgeEntityRepository.findById(iid);
    }

    // 再加一条 用knowledge_id来进行查询的
    @GetMapping("knowledge_id/{knowledge_id}")
    public List<KnowledgeEntity> findKnowledgeByKnowledgeId(@PathVariable String knowledge_id){
        return knowledgeEntityRepository.findKnowledgeEntitiesByKnowledgeId(knowledge_id);
    }


//    // 不知道iid 直接往后增加一条记录
//    @PostMapping
//    public String createOneKnowledge(@RequestBody Map<String,String> queryExample){
//        String knowledgeId = queryExample.get("knowledge_id");
//        String knowledgeDescription = queryExample.get("knowledge_description");
//        String knowledgeImportantDescription = queryExample.get("knowledge_important_description");
//        Integer preKnowledgeIid = Integer.parseInt(queryExample.get("pre_knowledge_iid"));
//        KnowledgeEntity knowledgeEntity = new KnowledgeEntity();
//        knowledgeEntity.setKnowledgeId(knowledgeId);
//        knowledgeEntity.setKnowledgeDescription(knowledgeDescription);
//        knowledgeEntity.setKnowledgeImportantDescription(knowledgeImportantDescription);
//        knowledgeEntity.setPreKnowledgeIid(preKnowledgeIid);
//        knowledgeEntityRepository.save(knowledgeEntity);
//
//
//
//        return "done";
//    }
//
//    @PutMapping
//    public String updateOneKnowledge(@RequestBody Map<String,String> queryExample){
//        Integer iid = Integer.parseInt(queryExample.get("iid"));
//        String knowledgeId = queryExample.get("knowledge_id");
//        String knowledgeDescription = queryExample.get("knowledge_description");
//        String knowledgeImportantDescription = queryExample.get("knowledge_important_description");
//        Integer preKnowledgeIid = Integer.parseInt(queryExample.get("pre_knowledge_iid"));
//        KnowledgeEntity knowledgeEntity = new KnowledgeEntity();
//        knowledgeEntity.setIid(iid);
//        knowledgeEntity.setKnowledgeId(knowledgeId);
//        knowledgeEntity.setKnowledgeDescription(knowledgeDescription);
//        knowledgeEntity.setKnowledgeImportantDescription(knowledgeImportantDescription);
//        knowledgeEntity.setPreKnowledgeIid(preKnowledgeIid);
//        knowledgeEntityRepository.save(knowledgeEntity);
//
//        return "done";
//    }
    @PostMapping
    public String updateKnowledge(@RequestBody KnowledgeEntity knowledgeEntity){
        knowledgeEntityRepository.save(knowledgeEntity);
        return "done";
    }

    @DeleteMapping("{iid}")
    public String deleteKnowledgeById(@PathVariable Integer iid){
        knowledgeEntityRepository.deleteById(iid);
//        courseEntityRepository.deleteById(iid);
        return "done";

    }

}
