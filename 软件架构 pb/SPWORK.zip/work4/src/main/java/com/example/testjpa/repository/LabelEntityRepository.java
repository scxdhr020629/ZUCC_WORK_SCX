package com.example.testjpa.repository;

import com.example.testjpa.entity.LabelEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LabelEntityRepository extends JpaRepository<LabelEntity, Integer> {
    List<LabelEntity> findLabelEntitiesByLabelId(String labelId);
}