package com.example.testjpa.controller;

import com.example.testjpa.entity.TeacherEntity;
import com.example.testjpa.repository.TeacherEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/teachers")
public class TeacherController {

    @Autowired
    private TeacherEntityRepository teacherEntityRepository;

    @GetMapping
    public List<TeacherEntity> findAll(){
        return teacherEntityRepository.findAll();
    }


    // by iid
    @GetMapping("/iid/{iid}")
    public java.util.Optional<TeacherEntity> findTeacherByIid(@PathVariable Integer iid){
        return teacherEntityRepository.findById(iid);
    }

    // by teacher_id
    @GetMapping("/teacher_id/{teacher_id}")
    public List<TeacherEntity> findTeacherByTeacherId(@PathVariable String teacher_id){
        return teacherEntityRepository.findTeacherEntitiesByTeacherId(teacher_id);
    }

//    @PostMapping
//    public String createOneTeacher(@RequestBody Map<String,String> queryExample){
//        String teacherId = queryExample.get("teacher_id");
//        String teacherName = queryExample.get("teacher_name");
//        String teacherPhone = queryExample.get("teacher_phone");
//        String teacherDescription = queryExample.get("teacher_description");
//        TeacherEntity teacherEntity = new TeacherEntity();
//        teacherEntity.setTeacherId(teacherId);
//        teacherEntity.setTeacherName(teacherName);
//        teacherEntity.setTeacherPhone(teacherPhone);
//        teacherEntity.setTeacherDescription(teacherDescription);
//        teacherEntityRepository.save(teacherEntity);
//        return "done";
//    }
//
//    @PutMapping
//    public String updateOneTeacher(@RequestBody Map<String,String> queryExample){
//        Integer iid = Integer.parseInt(queryExample.get("iid"));
//        String teacherId = queryExample.get("teacher_id");
//        String teacherName = queryExample.get("teacher_name");
//        String teacherPhone = queryExample.get("teacher_phone");
//        String teacherDescription = queryExample.get("teacher_description");
//        TeacherEntity teacherEntity = new TeacherEntity();
//        teacherEntity.setIid(iid);
//        teacherEntity.setTeacherId(teacherId);
//        teacherEntity.setTeacherName(teacherName);
//        teacherEntity.setTeacherPhone(teacherPhone);
//        teacherEntity.setTeacherDescription(teacherDescription);
//        teacherEntityRepository.save(teacherEntity);
//        return "done";
//    }

    @PostMapping
    public String UpdateOneTeacher(@RequestBody TeacherEntity teacherEntity){
        System.out.println(teacherEntity.getTeacherName());
        teacherEntityRepository.save(teacherEntity);
        return  "done";
    }
    @DeleteMapping("{iid}")
    public String deleteOneTeacher(@PathVariable Integer iid){
        teacherEntityRepository.deleteById(iid);
        return "done";
    }


}
