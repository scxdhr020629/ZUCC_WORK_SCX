package com.example.testjpa.controller;

import com.example.testjpa.entity.LabelGroupEntity;
import com.example.testjpa.repository.LabelGroupEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/label_groups")
public class LabelGroupController {
    @Autowired
    private LabelGroupEntityRepository labelGroupEntityRepository;

    @GetMapping
    public List<LabelGroupEntity> findAll(){
        return  labelGroupEntityRepository.findAll();
    }

    @GetMapping("iid/{iid}")
    public java.util.Optional<LabelGroupEntity> findLabelGroupById(@PathVariable Integer iid){
        return labelGroupEntityRepository.findById(iid);
    }

    @GetMapping("label_group_id/{label_group_id}")
    public List<LabelGroupEntity> findLabelGroupByLabelGroupId(@PathVariable String label_group_id){
         return  labelGroupEntityRepository.findLabelGroupEntitiesByLabelGroupId(label_group_id);
    }

//    @PostMapping
//    public String createOneLabelGroup(@RequestBody Map<String,String> queryExample) {
//        String labelGroupId = queryExample.get("label_group_id");
//        String labelGroupDescription = queryExample.get("label_group_description");
//        LabelGroupEntity labelGroupEntity = new LabelGroupEntity();
//        labelGroupEntity.setLabelGroupId(labelGroupId);
//        labelGroupEntity.setLabelGroupDescription(labelGroupDescription);
//        labelGroupEntityRepository.save(labelGroupEntity);
//        return "done";
//    }
//
//    @PutMapping
//    public String UpdateOneLabelGroup(@RequestBody Map<String,String> queryExample){
//        Integer iid = Integer.parseInt(queryExample.get("iid"));
//        String labelGroupId = queryExample.get("label_group_id");
//        String labelGroupDescription = queryExample.get("label_group_description");
//        LabelGroupEntity labelGroupEntity = new LabelGroupEntity();
//        labelGroupEntity.setIid(iid);
//        labelGroupEntity.setLabelGroupId(labelGroupId);
//        labelGroupEntity.setLabelGroupDescription(labelGroupDescription);
//        labelGroupEntityRepository.save(labelGroupEntity);
//        return "done";
//    }

    @PostMapping
    public String updateOneLabelGroup(@RequestBody LabelGroupEntity labelGroupEntity){
        labelGroupEntityRepository.save(labelGroupEntity);
        return "done";
    }
    @DeleteMapping("/{iid}")
    public String deleteLabelGroupById(@PathVariable Integer iid){
        labelGroupEntityRepository.deleteById(iid);
        return  "done";
    }



}
