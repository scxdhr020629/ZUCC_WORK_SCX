package com.example.testjpa.repository;

import com.example.testjpa.entity.KnowledgeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface KnowledgeEntityRepository extends JpaRepository<KnowledgeEntity, Integer> {
    List<KnowledgeEntity> findKnowledgeEntitiesByKnowledgeId(String knowledgeId);
}