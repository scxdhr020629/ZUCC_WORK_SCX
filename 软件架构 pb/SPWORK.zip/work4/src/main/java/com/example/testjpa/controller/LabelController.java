package com.example.testjpa.controller;

import com.example.testjpa.entity.LabelEntity;
import com.example.testjpa.repository.LabelEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/labels")
public class LabelController {
    @Autowired
    private LabelEntityRepository labelEntityRepository;

    // 查询所有标签
    @GetMapping
    public List<LabelEntity> findAll(){
        return  labelEntityRepository.findAll();
    }

    // 查询标签 根据iid
    @GetMapping("/iid/{iid}")
    public java.util.Optional<LabelEntity> findLabelById(@PathVariable Integer iid){
        return labelEntityRepository.findById(iid);
    }

    // 查询标签 根据Label_id
    @GetMapping("/label_id/{label_id}")
    public List<LabelEntity> findLabelByLabelId(@PathVariable String label_id){
    return labelEntityRepository.findLabelEntitiesByLabelId(label_id);
    }

//    @PostMapping
//    public String createOneLabel(@RequestBody Map<String,String> queryExample){
//        String labelId = queryExample.get("label_id");
//        String labelContent = queryExample.get("label_content");
//        String labelGroupId = queryExample.get("label_group_id");
//         LabelEntity labelEntity = new LabelEntity();
//         labelEntity.setLabelId(labelId);
//         labelEntity.setLabelContent(labelContent);
//         labelEntity.setLabelGroupId(labelGroupId);
//         labelEntityRepository.save(labelEntity);
//        return "done";
//    }
//
//
//    @PutMapping
//    public String updateOneLabel(@RequestBody Map<String,String> queryExample){
//        Integer iid = Integer.parseInt(queryExample.get("iid"));
//        String labelId = queryExample.get("label_id");
//        String labelContent = queryExample.get("label_content");
//        String labelGroupId = queryExample.get("label_group_id");
//        LabelEntity labelEntity = new LabelEntity();
//        labelEntity.setIid(iid);
//        labelEntity.setLabelId(labelId);
//        labelEntity.setLabelContent(labelContent);
//        labelEntity.setLabelGroupId(labelGroupId);
//        labelEntityRepository.save(labelEntity);
//        return "done";
//    }

    @PostMapping
    public String updateOneLabel(@RequestBody LabelEntity labelEntity){
        labelEntityRepository.save(labelEntity);
        return "done";
    }

    @DeleteMapping("{iid}")
    public String deleteCourseById(@PathVariable Integer iid){
        labelEntityRepository.deleteById(iid);
        return  "done";
    }
}
