package cn.edu.zucc.jpa.qa.repository;

import cn.edu.zucc.jpa.qa.entity.QaAnswerEntity;
import cn.edu.zucc.jpa.qa.formbean.AnswerUserView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 * @author pengbin
 * @version 1.0
 */
public interface AnswerRepository extends JpaRepository<QaAnswerEntity, Integer> {
    @Query(value="select count(*) from qa_answer", nativeQuery = true)
    Long countAll();

    @Query(value="select u.sid as sid, u.loginname as name, count(q.sid) as answerCount " +
            "from qa_answer q, mst_user u where q.creator = u.sid and u.sid = ?1", nativeQuery = true)
    AnswerUserView countAllByUser(int uid);

}
