package cn.edu.zucc.jpa.qa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L06JpaQaApplication {

    public static void main(String[] args) {
        SpringApplication.run(L06JpaQaApplication.class, args);
    }

}
