package cn.edu.zucc.jpa.qa.formbean;

/**
 * @author pengbin
 * @version 1.0
 */
public interface AnswerUserView {
    int getSid();
    String getName();
    int getAnswerCount();
}
