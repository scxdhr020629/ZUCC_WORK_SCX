package cn.edu.zucc.echo.form;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * @author pengbin
 * @version 1.0
 */
@Data
@Getter
@Setter
public class AnswerSheetDto implements Serializable {
    private Integer id;
    private Integer paperId;
    private Integer userId;
    private String startTime;
    private String submitTime;
    private String memo;
    private List<AnswerSheetDetailDto> answerDetail;
}
