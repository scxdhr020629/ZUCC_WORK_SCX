package cn.edu.zucc.echo.service.impl;

import cn.edu.zucc.echo.entity.TpQuestionEntity;
import cn.edu.zucc.echo.entity.TpQuestionOptionEntity;
import cn.edu.zucc.echo.entity.TpTemplateEntity;
import cn.edu.zucc.echo.exception.EchoServiceException;
import cn.edu.zucc.echo.form.TpQuestionDto;
import cn.edu.zucc.echo.form.TpQuestionOptionDto;
import cn.edu.zucc.echo.form.TpTemplateDto;
import cn.edu.zucc.echo.repository.TpTemplateEntityRepository;
import cn.edu.zucc.echo.service.ModelService;
import cn.edu.zucc.echo.utils.Constants;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.stream.Collectors;

/**
 * @author pengbin
 * @version 1.0
 */
@Service
public class ModelServiceImpl implements ModelService {
    @Autowired
    private TpTemplateEntityRepository templateEntityRepository;

    @Override
    public Integer createModel(TpTemplateDto templateDto) throws EchoServiceException {
        //检查
        if (templateDto.getId() != null) {
            throw new EchoServiceException("新建模板不能上传id");
        }

        if (templateDto.getQuestions() != null) {
            templateDto.getQuestions().stream().forEach(
                    question -> {
                        if (!Constants.Q_CATEGORY_SINGLE_CHOICE.equals(question.getCategory())
                                && !Constants.Q_CATEGORY_MULTI_CHOICE.equals(question.getCategory())
                                && !Constants.Q_CATEGORY_SUBJECTIVE.equals(question.getCategory())
                        ) {
                            throw new EchoServiceException(question.getTitle() + "的类型不支持");
                        }
                        //提升可读性，分为两级判断
                        if (Constants.Q_CATEGORY_SINGLE_CHOICE.equals(question.getCategory())
                                || Constants.Q_CATEGORY_MULTI_CHOICE.equals(question.getCategory())) {
                            if (question.getOptions() == null || question.getOptions().size() == 0) {
                                throw new EchoServiceException(question.getTitle() + "的选项不能为空");
                            }
                        }
                    }
            );
        }

        //保存到数据库
        TpTemplateEntity templateEntity = new TpTemplateEntity();
        BeanUtils.copyProperties(templateDto, templateEntity);
        templateEntity.setStatus(Constants.TEMPLATE_STATUS_NORMAL);
        //处理题目
        for (TpQuestionDto questionDto : templateDto.getQuestions()) {
            TpQuestionEntity questionEntity = new TpQuestionEntity();
            BeanUtils.copyProperties(questionDto, questionEntity);
            questionEntity.setTemplate(templateEntity);
            templateEntity.getTpQuestions().add(questionEntity);
            for (TpQuestionOptionDto optionDto : questionDto.getOptions()) {
                TpQuestionOptionEntity optionEntity = new TpQuestionOptionEntity();
                BeanUtils.copyProperties(optionDto, optionEntity);
                optionEntity.setQuestion(questionEntity);
                questionEntity.getTpQuestionOptions().add(optionEntity);
            }
        }
        this.templateEntityRepository.save(templateEntity);
        return templateEntity.getId();
    }

    @Override
    public TpTemplateDto queryModelDetail(Integer templateId) throws EchoServiceException {
        TpTemplateEntity templateEntity = this.templateEntityRepository.getOne(templateId);
        if (templateEntity == null) {
            throw new EchoServiceException("模板不存在.");
        }

        TpTemplateDto retObj = new TpTemplateDto(templateEntity.getId(), templateEntity.getName(),
                templateEntity.getStatus(), templateEntity.getMemo(),
                templateEntity.getTpQuestions().stream().map(
                        question -> new TpQuestionDto(question.getId(), question.getCategory(),
                                question.getTitle(), question.getIsRequired(), question.getRemark(),
                                question.getTpQuestionOptions().stream()
                                        .sorted(Comparator.comparing(TpQuestionOptionEntity::getId))
                                        .map(option -> new TpQuestionOptionDto(option.getId(),
                                                option.getTitle())).collect(Collectors.toList()))
                        ).collect(Collectors.toList()));

        return retObj;
    }
}
