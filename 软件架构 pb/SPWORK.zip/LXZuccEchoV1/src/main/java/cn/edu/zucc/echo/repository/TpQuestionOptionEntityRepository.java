package cn.edu.zucc.echo.repository;

import cn.edu.zucc.echo.entity.TpQuestionOptionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TpQuestionOptionEntityRepository extends JpaRepository<TpQuestionOptionEntity, Integer> {
}