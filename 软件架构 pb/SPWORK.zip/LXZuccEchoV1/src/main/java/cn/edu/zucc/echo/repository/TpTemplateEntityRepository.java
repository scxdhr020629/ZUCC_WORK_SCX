package cn.edu.zucc.echo.repository;

import cn.edu.zucc.echo.entity.TpTemplateEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TpTemplateEntityRepository extends JpaRepository<TpTemplateEntity, Integer> {
}