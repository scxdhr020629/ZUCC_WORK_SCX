package cn.edu.zucc.echo.service;

import cn.edu.zucc.echo.exception.EchoServiceException;
import cn.edu.zucc.echo.form.AnswerSheetDto;
import cn.edu.zucc.echo.form.FbPaperDto;
import cn.edu.zucc.echo.form.PublishFeedBackDto;
import org.springframework.stereotype.Service;

/**
 * @author pengbin
 * @version 1.0
 */
@Service
public interface FeedbackService {
    /**
     * 教师发布一个反馈问卷
     * @param dto
     * @return
     * @throws EchoServiceException
     */
    FbPaperDto publishFeedback(PublishFeedBackDto dto) throws EchoServiceException;

    /**
     * 返回给定的反馈问卷
     * @param paperId
     * @return
     * @throws EchoServiceException
     */
    FbPaperDto queryPaperDetail(Integer paperId) throws EchoServiceException;

    /**
     * 用户回答问卷
     * @param answerSheetDto
     * @return
     */
    Integer answerWorkSheet(AnswerSheetDto answerSheetDto) throws EchoServiceException;

}
