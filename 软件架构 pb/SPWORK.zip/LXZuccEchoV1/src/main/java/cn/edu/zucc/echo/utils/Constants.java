package cn.edu.zucc.echo.utils;

/**
 * @author pengbin
 * @version 1.0
 */
public class Constants {
    public static final String Q_CATEGORY_SUBJECTIVE = "subjective";
    public static final String Q_CATEGORY_SINGLE_CHOICE = "single";
    public static final String Q_CATEGORY_MULTI_CHOICE = "multi";

    public static final String TEMPLATE_STATUS_NORMAL = "normal";

    public static final String PAPER_STATUS_PUBLISHED = "published";

    public static final String DATE_FORMAT_YYYYMMDDHHMMSS = "yyyy/MM/dd HH:mm:ss";

}
