package cn.edu.zucc.echo.repository;

import cn.edu.zucc.echo.entity.FbQuestionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FbQuestionEntityRepository extends JpaRepository<FbQuestionEntity, Integer> {
}