package cn.edu.zucc.echo.form;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author pengbin
 * @version 1.0
 */
@Data
public class PublishFeedBackDto implements Serializable {
    private final Integer templateId;
    private final Integer userId;
    private final Integer classId;
    private final String name;
    private final String deadLine;

    private final List<TpQuestionOptionDto> options;

}
