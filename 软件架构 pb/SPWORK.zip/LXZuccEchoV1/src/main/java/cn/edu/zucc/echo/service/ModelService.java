package cn.edu.zucc.echo.service;

import cn.edu.zucc.echo.exception.EchoServiceException;
import cn.edu.zucc.echo.form.TpTemplateDto;

/**
 * @author pengbin
 * @version 1.0
 */
public interface ModelService {
    /**
     * 创建一个模板
     * @param templateDto
     * @return
     * @throws EchoServiceException
     */
    Integer createModel(TpTemplateDto templateDto) throws EchoServiceException;

    /**
     * 查询模板明细
     * @param templateId
     * @return
     * @throws EchoServiceException
     */
    TpTemplateDto queryModelDetail(Integer templateId) throws EchoServiceException;
}
