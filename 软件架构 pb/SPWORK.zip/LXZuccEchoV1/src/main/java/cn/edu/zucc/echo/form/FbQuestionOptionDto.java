package cn.edu.zucc.echo.form;

import lombok.Data;

import java.io.Serializable;

/**
 * @author pengbin
 * @version 1.0
 */
@Data
public class FbQuestionOptionDto implements Serializable {
    private final Integer id;
    private final String title;
}
