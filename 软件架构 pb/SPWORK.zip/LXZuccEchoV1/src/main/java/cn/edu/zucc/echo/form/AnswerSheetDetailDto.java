package cn.edu.zucc.echo.form;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author pengbin
 * @version 1.0
 */
@Data
@Getter @Setter
public class AnswerSheetDetailDto implements Serializable {
    private Integer id;
    private Integer questionId;
    private String questionTitle;
    private String questionCategory;
    private String answerContent;
    private String answerContentView;
    private String memo;
}
