package cn.edu.zucc.echo.controller;

import cn.edu.zucc.echo.form.AnswerSheetDto;
import cn.edu.zucc.echo.result.ResponseData;
import cn.edu.zucc.echo.result.ResponseMsg;
import cn.edu.zucc.echo.service.FeedbackService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/answer")
public class AnswerController {
    private final Logger logger = LoggerFactory.getLogger(AnswerController.class);

    @Autowired
    private FeedbackService feedbackService;

    /**
     * 用户提交答卷内容
     * {
     *     "paperId": 10,
     *     "userId": 2,
     *     "answerDetail":[
     *         {
     *             "questionId":11,
     *             "answerContent":"学会了好好编程"
     *         },
     *                 {
     *             "questionId":12,
     *             "answerContent":"13"
     *         }
     *     ]
     * }
     * @param answerSheetDto
     * @return
     */
    @RequestMapping(value = "/submit", method = RequestMethod.POST)
    @ResponseBody
    public ResponseData submitAnswer(@RequestBody AnswerSheetDto answerSheetDto){
        logger.warn(answerSheetDto.toString());
        Integer answerSheetId = feedbackService.answerWorkSheet(answerSheetDto);
        if(answerSheetId > 0){
            return new ResponseData(ResponseMsg.SUCCESS, answerSheetId);
        } else {
            return new ResponseData(ResponseMsg.FAILED, answerSheetDto);
        }
    }
}
