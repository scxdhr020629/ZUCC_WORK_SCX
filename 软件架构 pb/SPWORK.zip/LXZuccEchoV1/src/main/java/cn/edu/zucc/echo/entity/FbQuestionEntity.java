package cn.edu.zucc.echo.entity;

import javax.persistence.*;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "fb_question")
public class FbQuestionEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "paper_id")
    private FbPaperEntity paper;

    @Column(name = "category")
    private String category;

    @Column(name = "title", length = 600)
    private String title;

    @Column(name = "is_required")
    private String isRequired;

    @Column(name = "remark", length = 600)
    private String remark;

    @OneToMany(mappedBy = "question", cascade = CascadeType.PERSIST)
    private Set<FbQuestionOptionEntity> fbQuestionOptions = new LinkedHashSet<>();

    public Set<FbQuestionOptionEntity> getFbQuestionOptions() {
        return fbQuestionOptions;
    }

    public void setFbQuestionOptions(Set<FbQuestionOptionEntity> fbQuestionOptions) {
        this.fbQuestionOptions = fbQuestionOptions;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getIsRequired() {
        return isRequired;
    }

    public void setIsRequired(String isRequired) {
        this.isRequired = isRequired;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public FbPaperEntity getPaper() {
        return paper;
    }

    public void setPaper(FbPaperEntity paper) {
        this.paper = paper;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}