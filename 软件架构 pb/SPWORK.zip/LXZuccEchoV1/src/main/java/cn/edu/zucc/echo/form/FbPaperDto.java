package cn.edu.zucc.echo.form;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author pengbin
 * @version 1.0
 */
@Data
public class FbPaperDto implements Serializable {
    private final Integer id;
    private final String name;
    private final String memo;
    private final String publishTime;
    private final String deadLine;
    private final List<FbQuestionDto> questions;

}
