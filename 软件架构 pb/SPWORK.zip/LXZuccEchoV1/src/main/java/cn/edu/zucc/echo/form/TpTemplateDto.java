package cn.edu.zucc.echo.form;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author pengbin
 * @version 1.0
 */
@Data
public class TpTemplateDto implements Serializable {
    private final Integer id;
    private final String name;
    private final String status;
    private final String memo;
    private final List<TpQuestionDto> questions;

    @Override
    public String toString() {
        return "TpTemplateDto{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", status='" + status + '\'' +
                ", memo='" + memo + '\'' +
                '}';
    }
}
