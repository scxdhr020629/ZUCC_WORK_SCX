package cn.edu.zucc.echo.entity;

import javax.persistence.*;

@Entity
@Table(name = "fb_answer_sheet_detail")
public class FbAnswerSheetDetailEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sheet_id")
    private FbAnswerSheetEntity sheet;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "question_id")
    private FbQuestionEntity question;

    @Column(name = "question_title")
    private String questionTitle;

    @Column(name = "question_category")
    private String questionCategory;

    @Column(name = "answer_content", length = 2048)
    private String answerContent;

    @Column(name = "answer_content_view")
    private String answerContentView;

    @Column(name = "memo")
    private String memo;

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getAnswerContentView() {
        return answerContentView;
    }

    public void setAnswerContentView(String answerContentView) {
        this.answerContentView = answerContentView;
    }

    public String getAnswerContent() {
        return answerContent;
    }

    public void setAnswerContent(String answerContent) {
        this.answerContent = answerContent;
    }

    public String getQuestionCategory() {
        return questionCategory;
    }

    public void setQuestionCategory(String questionCategory) {
        this.questionCategory = questionCategory;
    }

    public String getQuestionTitle() {
        return questionTitle;
    }

    public void setQuestionTitle(String questionTitle) {
        this.questionTitle = questionTitle;
    }

    public FbQuestionEntity getQuestion() {
        return question;
    }

    public void setQuestion(FbQuestionEntity question) {
        this.question = question;
    }

    public FbAnswerSheetEntity getSheet() {
        return sheet;
    }

    public void setSheet(FbAnswerSheetEntity sheet) {
        this.sheet = sheet;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}