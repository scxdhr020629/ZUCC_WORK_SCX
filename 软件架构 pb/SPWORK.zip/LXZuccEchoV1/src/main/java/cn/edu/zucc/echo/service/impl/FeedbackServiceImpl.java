package cn.edu.zucc.echo.service.impl;

import cn.edu.zucc.echo.entity.*;
import cn.edu.zucc.echo.exception.EchoServiceException;
import cn.edu.zucc.echo.form.*;
import cn.edu.zucc.echo.repository.FbPaperEntityRepository;
import cn.edu.zucc.echo.repository.MstClassEntityRepository;
import cn.edu.zucc.echo.repository.MstUserEntityRepository;
import cn.edu.zucc.echo.repository.TpTemplateEntityRepository;
import cn.edu.zucc.echo.service.FeedbackService;
import cn.edu.zucc.echo.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.stream.Collectors;

/**
 * @author pengbin
 * @version 1.0
 */
@Service
public class FeedbackServiceImpl implements FeedbackService {
    @Autowired
    private TpTemplateEntityRepository templateEntityRepository;

    @Autowired
    private FbPaperEntityRepository paperEntityRepository;
    @Autowired
    private MstClassEntityRepository classEntityRepository;
    @Autowired
    private MstUserEntityRepository userEntityRepository;

    @Override
    public FbPaperDto publishFeedback(PublishFeedBackDto dto) throws EchoServiceException {
        Integer paperId = copyPaperFromTemplate(dto);
        return queryPaperDetail(paperId);
    }

    @Override
    public FbPaperDto queryPaperDetail(Integer paperId) throws EchoServiceException {
        FbPaperEntity paperEntity = this.paperEntityRepository.getOne(paperId);
        if (paperEntity == null) {
            throw new EchoServiceException("没有找到反馈卷:" + paperId);
        }

        FbPaperDto fbPaperDto = new FbPaperDto(
                paperEntity.getId(), paperEntity.getName(), paperEntity.getMemo(),
                paperEntity.getPublishTime().toString(),
                paperEntity.getDeadLine().toString(),
                paperEntity.getFbQuestions().stream().map(
                        fbQuestionEntity -> {
                            return new FbQuestionDto(
                                    fbQuestionEntity.getId(), fbQuestionEntity.getCategory(),
                                    fbQuestionEntity.getTitle(), fbQuestionEntity.getIsRequired(),
                                    fbQuestionEntity.getRemark(),
                                    fbQuestionEntity.getFbQuestionOptions().stream()
                                            .sorted(Comparator.comparing(FbQuestionOptionEntity::getId))
                                            .map(
                                            fbQuestionOptionEntity -> {
                                                return new FbQuestionOptionDto(fbQuestionOptionEntity.getId(), fbQuestionOptionEntity.getTitle());
                                            }).collect(Collectors.toList()));
                        }
                ).collect(Collectors.toList())
        );

        return fbPaperDto;
    }

    public Integer answerWorkSheet(AnswerSheetDto answerSheetDto){
        /**
         * TODO 完成下面的要求
         * 1.获取答卷对应的问卷
         * 2.检查必填项是否已经填写
         * 3.填充缺失的项（比如问题title等）
         * 4.构造方便用于显示的answerContentView字段
         * 5.构造AnswerSheet对应的Entity然后入库
         * 6.返回入库后对应的AnswerSheet的id
         */
        return -1;
    }

    private Integer copyPaperFromTemplate(PublishFeedBackDto dto) {
        TpTemplateEntity templateEntity = this.templateEntityRepository.getOne(dto.getTemplateId());
        if (templateEntity == null) {
            throw new EchoServiceException("没有找到模板:" + dto.getTemplateId());
        }

        MstClassEntity classEntity = this.classEntityRepository.getOne(dto.getClassId());
        if (classEntity == null) {
            throw new EchoServiceException("没有找到班级:" + dto.getTemplateId());
        }

        MstUserEntity teacherEntity = this.userEntityRepository.getOne(dto.getUserId());
        if (teacherEntity == null) {
            throw new EchoServiceException("没有找到教师:" + dto.getTemplateId());
        }

        FbPaperEntity paperEntity = new FbPaperEntity();
        paperEntity.setName(templateEntity.getName());
        paperEntity.setMemo(templateEntity.getMemo());
        paperEntity.set_class(classEntity);
        paperEntity.setStatus(Constants.PAPER_STATUS_PUBLISHED);
        paperEntity.setCreatorId(dto.getUserId());
        paperEntity.setCreateTime(Instant.now());
        paperEntity.setPublishTime(Instant.now());
        paperEntity.setDeadLine(LocalDateTime.parse(dto.getDeadLine(),
                        DateTimeFormatter.ofPattern(Constants.DATE_FORMAT_YYYYMMDDHHMMSS))
                .toInstant(ZoneOffset.UTC));

        paperEntity.setFbQuestions(
                templateEntity.getTpQuestions().stream().map(tpQuestionEntity -> {
                    FbQuestionEntity fbQuestionEntity = new FbQuestionEntity();
                    fbQuestionEntity.setPaper(paperEntity);
                    fbQuestionEntity.setCategory(tpQuestionEntity.getCategory());
                    fbQuestionEntity.setRemark(tpQuestionEntity.getRemark());
                    fbQuestionEntity.setTitle(tpQuestionEntity.getTitle());
                    fbQuestionEntity.setIsRequired(tpQuestionEntity.getIsRequired());
                    fbQuestionEntity.setFbQuestionOptions(
                            tpQuestionEntity.getTpQuestionOptions().stream()
                                    .sorted(Comparator.comparing(TpQuestionOptionEntity::getId))
                                    .map(tpQuestionOptionEntity -> {
                                        FbQuestionOptionEntity fbQuestionOptionEntity = new FbQuestionOptionEntity();
                                        fbQuestionOptionEntity.setQuestion(fbQuestionEntity);
                                        fbQuestionOptionEntity.setTitle(tpQuestionOptionEntity.getTitle());
                                        return fbQuestionOptionEntity;
                                    }).collect(Collectors.toSet())
                    );
                    return fbQuestionEntity;
                }).collect(Collectors.toSet())
        );
        this.paperEntityRepository.save(paperEntity);

        return paperEntity.getId();
    }

}
