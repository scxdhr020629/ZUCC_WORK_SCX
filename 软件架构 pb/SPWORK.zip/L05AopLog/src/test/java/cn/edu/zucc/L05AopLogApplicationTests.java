package cn.edu.zucc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L05AopLogApplicationTests {

	@Test
	void contextLoads() {
	}

}
