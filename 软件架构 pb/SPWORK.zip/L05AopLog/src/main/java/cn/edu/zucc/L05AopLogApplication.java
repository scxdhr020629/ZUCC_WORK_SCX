package cn.edu.zucc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L05AopLogApplication {

	public static void main(String[] args) {
		SpringApplication.run(L05AopLogApplication.class, args);
	}

}
