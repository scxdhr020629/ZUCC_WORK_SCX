package cn.zucc.edu.pb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L01HelloWorldBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(L01HelloWorldBootApplication.class, args);
	}

}
