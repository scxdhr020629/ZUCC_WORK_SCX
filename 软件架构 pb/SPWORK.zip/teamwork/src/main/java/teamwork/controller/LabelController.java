package teamwork.controller;

import org.springframework.web.bind.annotation.*;
import teamwork.model.Label;

import java.util.UUID;

@RestController
@RequestMapping("/label")
public class LabelController {

    //根据编号找标签
    @GetMapping("/queryLabelByNum/{labelNum}")
    public Label queryLabelByNum(@PathVariable("labelNum") String labelNum) {
        Label label = new Label();
        label.setLabelNum(labelNum);
        System.out.println("找到了");
        return label;
    }

    //添加标签
    @PostMapping("/addLabel/{labelNum}/{labelContent}")
    public Label addLabel(@PathVariable("labelNum") String labelNum,
                          @PathVariable("labelContent") String labelContent) {
        Label label = new Label();
        String preUuid = UUID.randomUUID().toString();
        label.setId(preUuid);
        label.setLabelNum(labelNum);
        label.setLabelContent(labelContent);
        System.out.println("已成功添加编号为"+labelNum+"的标签");
        return label;
    }

    //更新标签
    @PostMapping("/updateLabel/{labelNum}/{labelContent}")
    public Label updateLabel(@PathVariable("labelNum") String labelNum,
                          @PathVariable("labelContent") String labelContent) {
        Label label = new Label();
        label.setLabelNum(labelNum);
        label.setLabelContent(labelContent);
        System.out.println("已成功更新编号为"+labelNum+"的标签");
        return label;
    }

    //删除标签
    @DeleteMapping("/deleteLabel/{labelNum}")
    public String deleteLabel(@PathVariable("labelNum") String labelNum) {
        return "已成功删除编号为"+labelNum+"的标签";
    }
}
