package teamwork.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import teamwork.model.Course;

import java.sql.Timestamp;
import java.util.UUID;

@RestController
//设置前缀
@RequestMapping("/course")
public class CourseController {

    //根据编号查找特定的课程
    @GetMapping("/queryCourseByNum/{courseNum}")
    public Course queryCourseByNum(@PathVariable("courseNum") String courseNum) {
        Course course = new Course();
        course.setCourseNum(courseNum);
        System.out.println("找到了");
        return course;
    }

    //根据名称查找特定的课程
    @GetMapping("/queryCourseByName/{courseName}")
    public Course queryCourseByName(@PathVariable("courseName") String courseName) {
        Course course = new Course();
        course.setCourseName(courseName);
        System.out.println("找到了");
        return course;
    }

    //根据教材查找特定的课程
    @GetMapping("/queryCourseByTextBook/{textbook}")
    public Course queryCourseByTextBook(@PathVariable("textbook") String textbook) {
        Course course = new Course();
        course.setTextbook(textbook);
        System.out.println("找到了");
        return course;
    }

    //根据老师查找特定的课程
    @GetMapping("/queryCourseByTeacher/{courseTeacher}")
    public Course queryCourseByTeacher(@PathVariable("courseTeacher") String courseTeacher) {
        Course course = new Course();
        course.setCourseTeacher(courseTeacher);
        System.out.println("找到了");
        return course;
    }


    //更新课程信息
    @RequestMapping("/updateCourse/{courseNum}/{courseName}/{courseDescription}/{textbook}/{courseLabel}/{courseTeacher}")
    public Course updateCourse(@PathVariable("courseNum") String courseNum,
                               @PathVariable("courseName") String courseName,
                               @PathVariable("courseDescription") String courseDescription,
                               @PathVariable("textbook") String textbook,
                               @PathVariable("courseLabel") String[] courseLabel,
                               @PathVariable("courseTeacher") String courseTeacher) {
        Course course = new Course();
        course.setCourseNum(courseNum);
        course.setCourseName(courseName);
        course.setCourseDescription(courseDescription);
        course.setTextbook(textbook);
        course.setCourseLabel(courseLabel);
        course.setCourseTeacher(courseTeacher);
        System.out.println("已成功更新"+courseName+"的信息");
        return course;
    }


    //删除课程
    @RequestMapping("/deleteCourse/{courseNum}")
    public String deleteCourse(@PathVariable("courseNum") String courseNum) {
        System.out.println("已成功删除");
        return "已删除编号为" + courseNum + "的课程";
    }

    //增加课程
    @RequestMapping("/addCourse/{courseNum}/{courseName}/{courseDescription}/{textbook}/{courseLabel}/{courseTeacher}")
    public Course addCourse(@PathVariable("courseNum") String courseNum,
                            @PathVariable("courseName") String courseName,
                            @PathVariable("courseDescription") String courseDescription,
                            @PathVariable("textbook") String textbook,
                            @PathVariable("courseLabel") String[] courseLabel,
                            @PathVariable("courseTeacher") String courseTeacher) {
        Course course = new Course();
        String preUuid = UUID.randomUUID().toString();
        course.setId(preUuid);
        course.setCourseNum(courseNum);
        course.setCourseName(courseName);
        course.setCourseDescription(courseDescription);
        course.setTextbook(textbook);
        course.setCourseLabel(courseLabel);
        course.setCourseTeacher(courseTeacher);
        System.out.println("已成功添加"+courseName+"的信息");
        return course;
    }


}
