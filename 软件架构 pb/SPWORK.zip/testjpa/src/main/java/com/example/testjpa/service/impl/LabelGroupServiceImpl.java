package com.example.testjpa.service.impl;

import com.example.testjpa.entity.LabelGroupEntity;
import com.example.testjpa.entity.LabelGroupIsSystemEntity;
import com.example.testjpa.entity.UserIsAdminEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.LabelGroupForm;
import com.example.testjpa.repository.LabelGroupEntityRepository;
import com.example.testjpa.repository.LabelGroupIsSystemEntityRepository;
import com.example.testjpa.service.LabelGroupService;
import com.example.testjpa.service.UserIsAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class LabelGroupServiceImpl implements LabelGroupService {

    @Autowired
    private LabelGroupEntityRepository labelGroupEntityRepository;

    @Autowired
    private LabelGroupIsSystemEntityRepository labelGroupIsSystemEntityRepository;

    @Autowired
    private UserIsAdminService userIsAdminService;
    @Override
    public List<LabelGroupForm> findAllLabelGroup() throws EchoServiceException {

        List<LabelGroupEntity> oldList = labelGroupEntityRepository.findAll();
        if(oldList == null){
            throw new EchoServiceException("没有标签组");
        }
        List<LabelGroupForm> newList = new ArrayList<>();
        for(int i=0;i<oldList.size();i++){
            LabelGroupForm labelGroupForm = new LabelGroupForm();
            labelGroupForm.setIid(oldList.get(i).getIid());
            labelGroupForm.setLabelGroupId(oldList.get(i).getLabelGroupId());
            labelGroupForm.setLabelGroupDescription(oldList.get(i).getLabelGroupDescription());
            newList.add(labelGroupForm);
        }

        return newList;

    }

    @Override
    public LabelGroupForm findLabelGroupById(Integer iid) throws EchoServiceException {

        LabelGroupEntity labelGroupEntity = labelGroupEntityRepository.findById(iid).get();
        if(labelGroupEntity==null){
            throw new EchoServiceException("找不到这样的标签组 iid为"+iid);
        }
        LabelGroupForm labelGroupForm = new LabelGroupForm();
        labelGroupForm.setIid(labelGroupEntity.getIid());
        labelGroupForm.setLabelGroupId(labelGroupEntity.getLabelGroupId());
        labelGroupForm.setLabelGroupDescription(labelGroupEntity.getLabelGroupDescription());
        return labelGroupForm;
    }


    //  创建标签组应该都可以创建
    // 之后再给他赋予系统内置的权限
    @Override
    public Integer createOneLabelGroup(LabelGroupEntity labelGroupEntity) throws EchoServiceException {


        if(labelGroupEntity.getIid()!=0){
            throw new EchoServiceException("我们在创建一个标签组 不需要iid");
        }
        try {
            labelGroupEntityRepository.save(labelGroupEntity);
        }catch (Exception e){
            throw new EchoServiceException("创建一个标签组的时候出错"+e.getMessage());
        }
        return 1;
    }

    @Override
    public Integer updateOneLabelGroup(LabelGroupEntity labelGroupEntity,Integer userIid) throws EchoServiceException {



        boolean  isSystemFlag = false;
        boolean isAdminFlag = false;
        LabelGroupIsSystemEntity labelGroupIsSystemEntity = labelGroupIsSystemEntityRepository.findLabelGroupIsSystemEntityByLabelGroupIid(labelGroupEntity.getIid());

        UserIsAdminEntity userIsAdminEntity = userIsAdminService.findUserIsAdminByUserIid(userIid);
        if(userIsAdminEntity!=null){
            isAdminFlag = true;
        }

        if(labelGroupIsSystemEntity!=null){
            isSystemFlag = true;
        }

        if(isSystemFlag ==true && isAdminFlag!=true){
            throw new EchoServiceException("内置系统标签组，只能管理员来进行更新");
        }




        if(labelGroupEntity.getIid()==0){
            throw new EchoServiceException("我们在更新一个标签组 需要iid");
        }
        try {
            labelGroupEntityRepository.save(labelGroupEntity);

        }catch (Exception e){
            throw new EchoServiceException("创建一个标签组的时候出错"+e.getMessage());
        }
        return 1;

    }

    @Override
    public Integer deleteOneLabelGroup(Integer iid,Integer userIid) throws EchoServiceException {

        boolean  isSystemFlag = false;
        boolean isAdminFlag = false;
        LabelGroupIsSystemEntity labelGroupIsSystemEntity = labelGroupIsSystemEntityRepository.findLabelGroupIsSystemEntityByLabelGroupIid(iid);

        UserIsAdminEntity userIsAdminEntity = userIsAdminService.findUserIsAdminByUserIid(userIid);
        if(userIsAdminEntity!=null){
            isAdminFlag = true;
        }

        if(labelGroupIsSystemEntity!=null){
            isSystemFlag = true;
        }

        if(isSystemFlag ==true && isAdminFlag!=true){
            throw new EchoServiceException("内置系统标签组，只能管理员来进行删除");
        }

        if(iid==0){
            throw new EchoServiceException("删除一个标签组 iid 不能为0");
        }
        try{
            labelGroupEntityRepository.deleteById(iid);
            if(isSystemFlag){
                labelGroupIsSystemEntityRepository.deleteById(labelGroupIsSystemEntity.getIid());
            }
        }catch (Exception e){
            throw new EchoServiceException("删除一个标签组时出错");
        }
        return  1;
    }
}
