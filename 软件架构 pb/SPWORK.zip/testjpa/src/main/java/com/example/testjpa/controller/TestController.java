package com.example.testjpa.controller;

import com.example.testjpa.entity.UserEntity;
import com.example.testjpa.entity.UserIsAdminEntity;
import com.example.testjpa.formbean.KnowledgeForm;
import com.example.testjpa.formbean.LabelForm;
import com.example.testjpa.result.ResponseData;
import com.example.testjpa.result.ResponseMsg;
import com.example.testjpa.service.KnowledgeService;
import com.example.testjpa.service.LabelService;
import com.example.testjpa.service.UserIsAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;


/**
 * 这是一段测试的controller
 */

@RestController
@RequestMapping("test")
public class TestController {

    @Autowired
    private UserIsAdminService userIsAdminService;


    @Autowired
    private LabelService labelService;

    @Autowired
    private KnowledgeService knowledgeService;

    @PostMapping("/user")
    public ResponseData findUserIsAdmin(@RequestBody UserEntity userEntity){
        UserIsAdminEntity userIsAdminEntity = userIsAdminService.findUserIsAdminByUserIid(userEntity.getIid());
        return new ResponseData(ResponseMsg.SUCCESS,userIsAdminEntity);
    }


    @PostMapping("/courseLikedLabels")
    public ResponseData findCourseLikedLabels(){
        List<LabelForm> labelFormList = labelService.findCourseLikedLabels();
        return  new ResponseData(ResponseMsg.SUCCESS,labelFormList);
    }


    @PostMapping("/knowledgeLikedLabels")
    public ResponseData findKnowledgeLikedLabels(){
        List<LabelForm> labelFormList = labelService.findKnowledgeLikedLabels();
        return  new ResponseData(ResponseMsg.SUCCESS,labelFormList);
    }



    @PostMapping("pre")
    public ResponseData findPreKnowledges(@RequestBody Map<String,String> map){
        List<KnowledgeForm> knowledgeFormList = knowledgeService.findPreKnowledgeList(Integer.valueOf(map.get("iid")));
        return  new ResponseData(ResponseMsg.SUCCESS,knowledgeFormList);
    }


    @PostMapping("after")
    public ResponseData findAfterKnowledges(@RequestBody Map<String,String> map){
        List<KnowledgeForm> knowledgeFormList = knowledgeService.findPostKnowledgeList(Integer.valueOf(map.get("iid")));
        return  new ResponseData(ResponseMsg.SUCCESS,knowledgeFormList);
    }
}
