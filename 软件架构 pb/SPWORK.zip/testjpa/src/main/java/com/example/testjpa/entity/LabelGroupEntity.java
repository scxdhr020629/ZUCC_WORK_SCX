package com.example.testjpa.entity;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "label_group", schema = "zuccqa", catalog = "")
public class LabelGroupEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "iid")
    private int iid;
    @Basic
    @Column(name = "label_group_id")
    private String labelGroupId;
    @Basic
    @Column(name = "label_group_description")
    private String labelGroupDescription;


    @OneToMany(mappedBy = "labelGroupEntity",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
    //级联保存、更新、删除、刷新;延迟加载。当删除用户，会级联删除该用户的所有文章
    //拥有mappedBy注解的实体类为关系被维护端
    //mappedBy="author"中的author是Article中的author属性
    private List<LabelEntity> labelEntities;



    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public String getLabelGroupId() {
        return labelGroupId;
    }

    public void setLabelGroupId(String labelGroupId) {
        this.labelGroupId = labelGroupId;
    }

    public String getLabelGroupDescription() {
        return labelGroupDescription;
    }

    public void setLabelGroupDescription(String labelGroupDescription) {
        this.labelGroupDescription = labelGroupDescription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LabelGroupEntity that = (LabelGroupEntity) o;
        return iid == that.iid && Objects.equals(labelGroupId, that.labelGroupId) && Objects.equals(labelGroupDescription, that.labelGroupDescription);
    }

    @Override
    public int hashCode() {
        return Objects.hash(iid, labelGroupId, labelGroupDescription);
    }
}
