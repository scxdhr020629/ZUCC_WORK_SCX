package com.example.testjpa.service;

import com.example.testjpa.entity.TeacherEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.TeacherForm;

import java.util.List;

public interface TeacherService {
    public List<TeacherForm> findAllTeachers() throws EchoServiceException;

    public TeacherForm findTeacherById(Integer iid) throws  EchoServiceException;

    public List<TeacherForm> findTeacherByTeacherId(String teacherId) throws  EchoServiceException;

    public Integer updateOneTeacher(TeacherEntity teacherEntity) throws EchoServiceException;

    public Integer createOneTeacher(TeacherEntity teacherEntity) throws EchoServiceException;

    public Integer deleteOneTeacher(Integer iid) throws  EchoServiceException;
}
