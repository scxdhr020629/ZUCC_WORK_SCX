package com.example.testjpa.service.impl;

import com.example.testjpa.entity.ExampleEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.ExampleForm;
import com.example.testjpa.repository.ExampleEntityRepository;
import com.example.testjpa.service.ExampleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ExampleServiceImpl implements ExampleService {
    @Autowired
    private ExampleEntityRepository exampleEntityRepository;


    @Override
    public List<ExampleForm> findAllExample() throws EchoServiceException {
        List<ExampleEntity> oldList =exampleEntityRepository.findAll();
        if(oldList.size()==0){
            throw new EchoServiceException("没有案例");
        }
        List<ExampleForm> newList = new ArrayList<>();
        for(int i=0;i<oldList.size();i++){
            ExampleForm exampleForm = new ExampleForm();
            exampleForm.setIid(oldList.get(i).getIid());
            exampleForm.setExampleId((oldList.get(i)).getExampleId());
            exampleForm.setExampleUrl(oldList.get(i).getExampleUrl());
            newList.add(exampleForm);
        }


        return newList;
    }

    @Override
    public ExampleForm findExampleById(Integer iid) throws EchoServiceException {

        ExampleEntity exampleEntity = exampleEntityRepository.findById(iid).orElse(null);
        if(exampleEntity==null){
            throw new EchoServiceException("找不到这样的示例 iid 为"+iid);
        }
        ExampleForm exampleForm = new ExampleForm();
        exampleForm.setIid(exampleEntity.getIid());
        exampleForm.setExampleId(exampleEntity.getExampleId());
        exampleForm.setExampleUrl(exampleEntity.getExampleUrl());


        return exampleForm;
    }

    @Override
    public Integer updateOneExample(ExampleEntity exampleEntity) throws EchoServiceException {

        if(exampleEntity.getIid()==0){
            throw new EchoServiceException("我们在更新一门示例 需要 iid");
        }
        try {
            exampleEntityRepository.save(exampleEntity);
        }catch (Exception e){
            throw new EchoServiceException("更新一个示例时出错"+e.getMessage());
        }

        return 1;
    }

    @Override
    public Integer createOneExample(ExampleEntity exampleEntity) throws EchoServiceException {

        if(exampleEntity.getIid()!=0){
            throw new EchoServiceException("我们在创建一门示例 不需要 iid");
        }
        try {
            exampleEntityRepository.save(exampleEntity);
        }catch (Exception e){
            throw new EchoServiceException("创建一个示例时出错"+e.getMessage());
        }

        return 1;
    }

    @Override
    public Integer deleteOneExample(Integer iid) throws EchoServiceException {

        if(iid==0){
            throw new EchoServiceException("删除一门示例 iid 不能 为 0");
        }
        try {
            exampleEntityRepository.deleteById(iid);
        }catch (Exception e){
            throw new EchoServiceException("删除一门示例出错");
        }
        return 1;
    }
}
