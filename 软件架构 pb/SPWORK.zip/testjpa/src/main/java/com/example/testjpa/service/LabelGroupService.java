package com.example.testjpa.service;

import com.example.testjpa.entity.LabelEntity;
import com.example.testjpa.entity.LabelGroupEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.LabelGroupForm;

import java.util.List;

public interface LabelGroupService {

    public List<LabelGroupForm> findAllLabelGroup() throws EchoServiceException;
    public LabelGroupForm findLabelGroupById(Integer iid) throws EchoServiceException;
    public Integer createOneLabelGroup(LabelGroupEntity labelGroupEntity) throws  EchoServiceException;
    public Integer updateOneLabelGroup(LabelGroupEntity labelGroupEntity,Integer userIid) throws  EchoServiceException;
    public Integer deleteOneLabelGroup(Integer iid,Integer userIid) throws  EchoServiceException;


}
