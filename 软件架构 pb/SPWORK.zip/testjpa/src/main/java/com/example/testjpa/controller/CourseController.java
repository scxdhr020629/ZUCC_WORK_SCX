package com.example.testjpa.controller;

import com.example.testjpa.entity.CourseEntity;
import com.example.testjpa.formbean.CourseForm;
import com.example.testjpa.repository.CourseEntityRepository;
import com.example.testjpa.repository.KnowledgeEntityRepository;
import com.example.testjpa.result.ResponseData;
import com.example.testjpa.result.ResponseMsg;
import com.example.testjpa.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("courses")
public class CourseController {




    @Autowired
    private CourseService courseService;


    // 下面的查询部分写的不好，到时候要查询整合到一起
    // 查询所有课程
    @GetMapping
    public ResponseData findList(){
        List<CourseForm> courseFormList = courseService.findAllCourse();
        if(courseFormList.size()>0){
            return new ResponseData(ResponseMsg.SUCCESS,courseFormList);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,courseFormList);
        }

    }


    // 根据iid来进行课程查询
    @GetMapping("iid/{iid}")
    public ResponseData findCourseByIid(@PathVariable Integer iid){
         CourseForm courseForm = courseService.findCourseByIid(iid);
         if(courseForm.getIid()!=0){
             return new ResponseData(ResponseMsg.SUCCESS,courseForm);
         }
         else {
             return new ResponseData(ResponseMsg.FAILED,courseForm);
         }

    }


    /**
     * 这是一段测试的代码
     * @param courseForm
     * @return
     */
    @PostMapping("/queryCourse")
    public ResponseData queryCourse(@RequestBody CourseForm courseForm){
        List<CourseForm> courseFormList = courseService.findCourse(courseForm);
        if(courseFormList.size()>0){
            return new ResponseData(ResponseMsg.SUCCESS,courseFormList);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,courseFormList);
        }


    }

    @PostMapping("/createOneCourse")
    public ResponseData createOneCourse(@RequestBody CourseEntity courseEntity){
        Integer flag = courseService.createOneCourse(courseEntity);
        if(flag !=0){
            return  new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }

    }

    @PostMapping("/updateOneCourse")
    public ResponseData updateOneCourse(@RequestBody CourseEntity courseEntity){
        Integer flag = courseService.updateOneCourse(courseEntity);
        if(flag !=0){
            return  new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }






    // 删除一门课程,这里使用的是iid删除
    @PostMapping("/deleteOneCourse/{iid}")
    public ResponseData deleteCourseById(@PathVariable Integer iid){
        Integer flag = courseService.deleteOneCourse(iid);
        if(flag !=0){
            return  new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

    

}
