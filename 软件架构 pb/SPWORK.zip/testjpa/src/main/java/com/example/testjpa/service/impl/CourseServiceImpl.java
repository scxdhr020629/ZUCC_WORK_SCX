package com.example.testjpa.service.impl;

import com.example.testjpa.entity.CourseEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.CourseForm;
import com.example.testjpa.repository.CourseEntityRepository;
import com.example.testjpa.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class CourseServiceImpl implements CourseService {
   @Autowired
   private CourseEntityRepository courseEntityRepository;

    @Override
    public List<CourseForm> findAllCourse() throws EchoServiceException {
        List<CourseEntity> oldList = courseEntityRepository.findAll();
        if(oldList ==null){
            throw new EchoServiceException("没有课程");
        }
        List<CourseForm> newList = new ArrayList<>();
        for (int i = 0;i< oldList.size();i++){
            CourseForm courseForm = new CourseForm();
            courseForm.setIid(oldList.get(i).getIid());
            courseForm.setCourseId(oldList.get(i).getCourseId());
            courseForm.setCourseName(oldList.get(i).getCourseName());
            courseForm.setCourseDescripiton(oldList.get(i).getCourseDescription());
            courseForm.setCourseUsedBook(oldList.get(i).getCourseUsedBook());
            courseForm.setTeacherIid(oldList.get(i).getTeacherEntity().getIid());
            newList.add(courseForm);
        }
        return newList;
    }

    @Override
    public CourseForm findCourseByIid(Integer iid) throws EchoServiceException {
        CourseEntity courseEntity = courseEntityRepository.findById(iid).orElse(null);
        if(courseEntity==null){
            throw new EchoServiceException("找不到这样的课程 iid 为"+iid);
        }
        CourseForm courseForm = new CourseForm();
        courseForm.setIid(courseEntity.getIid());
        courseForm.setCourseId(courseEntity.getCourseId());
        courseForm.setCourseName(courseEntity.getCourseName());
        courseForm.setCourseCredit(courseEntity.getCourseCredit());
        courseForm.setCourseDescripiton(courseEntity.getCourseDescription());
        courseForm.setCourseUsedBook(courseEntity.getCourseUsedBook());
        courseForm.setTeacherIid(courseEntity.getTeacherEntity().getIid());
        return courseForm;
    }

    @Override
    public List<CourseForm> findCourse(CourseForm courseForm) throws EchoServiceException {
        List<CourseEntity> oldList = courseEntityRepository.findCourseEntitiesByCourseIdOrCourseNameOrCourseCredit(courseForm.getCourseId(), courseForm.getCourseName(), courseForm.getCourseCredit());
        if(oldList ==null){
            throw new EchoServiceException("没有这样的课程");
        }
        List<CourseForm> newList = new ArrayList<>();
        for (int i = 0;i< oldList.size();i++){
            CourseForm tCourseForm = new CourseForm();
            tCourseForm.setIid(oldList.get(i).getIid());
            tCourseForm.setCourseId(oldList.get(i).getCourseId());
            tCourseForm.setCourseName(oldList.get(i).getCourseName());
            tCourseForm.setCourseCredit(oldList.get(i).getCourseCredit());
            tCourseForm.setCourseDescripiton(oldList.get(i).getCourseDescription());
            tCourseForm.setCourseUsedBook(oldList.get(i).getCourseUsedBook());
            tCourseForm.setTeacherIid(oldList.get(i).getTeacherEntity().getIid());

            newList.add(tCourseForm);



        }

        return newList;
    }

    @Override
    public Integer createOneCourse(CourseEntity courseEntity) throws EchoServiceException {

        if(courseEntity.getIid()!=0){
            throw new EchoServiceException("我们在创建一门课程 不需要iid");
        }
        try{
            courseEntityRepository.save(courseEntity);
        }catch (Exception e){
            throw new EchoServiceException("创建一门课程时出错"+e.getMessage());
        }
        return 1;
    }

    @Override
    public Integer updateOneCourse(CourseEntity courseEntity) throws EchoServiceException {
        if(courseEntity.getIid()==0){
            throw new EchoServiceException("我们在更新一门课程 需要iid");
        }
        try{
            courseEntityRepository.save(courseEntity);
        }catch (Exception e){
            throw new EchoServiceException("更新一门课程时出错"+e.getMessage());
        }
        return 1;
    }

    @Override
    public Integer deleteOneCourse(Integer iid) throws EchoServiceException {
        if(iid ==0){
            throw new EchoServiceException("删除一名课程的iid 不能为0");
        }
        try{
            courseEntityRepository.deleteById(iid);
        }catch (Exception e){
            throw  new EchoServiceException("删除一名课程的时候出错");
        }
        return 1;
    }

}
