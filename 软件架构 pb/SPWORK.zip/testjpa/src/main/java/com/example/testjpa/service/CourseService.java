package com.example.testjpa.service;

import com.example.testjpa.entity.CourseEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.CourseForm;

import java.util.List;

public interface CourseService {
    public List<CourseForm> findAllCourse() throws EchoServiceException;

    public CourseForm findCourseByIid(Integer iid) throws  EchoServiceException;

    public List<CourseForm> findCourse(CourseForm courseForm) throws  EchoServiceException;

    public Integer createOneCourse(CourseEntity courseEntity) throws EchoServiceException;

    public Integer updateOneCourse(CourseEntity courseEntity) throws  EchoServiceException;

    public Integer deleteOneCourse(Integer iid) throws  EchoServiceException;
}
