package com.example.testjpa.repository;

import com.example.testjpa.entity.LabelGroupEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LabelGroupEntityRepository extends JpaRepository<LabelGroupEntity, Integer> {
    List<LabelGroupEntity> findLabelGroupEntitiesByLabelGroupId(String labelGroupId);
}