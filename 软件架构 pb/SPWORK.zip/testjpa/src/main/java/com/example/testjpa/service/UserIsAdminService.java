package com.example.testjpa.service;


import com.example.testjpa.entity.UserIsAdminEntity;
import com.example.testjpa.exception.EchoServiceException;

public interface UserIsAdminService {
    //  查找这个userIid 是否在 管理员权限表中
    public UserIsAdminEntity findUserIsAdminByUserIid(Integer userIid) throws EchoServiceException;
    public UserIsAdminEntity findUserIsAdminByIid(Integer iid) throws EchoServiceException;


    // 增加一个管理员权限
    public Integer createOneUser(UserIsAdminEntity userIsAdminEntity) throws EchoServiceException;

    public Integer deleteOneUserIsAdmin(Integer iid) throws  EchoServiceException;
}
