package com.example.testjpa.service;

import com.example.testjpa.entity.ExampleEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.ExampleForm;

import java.util.List;

public interface ExampleService {
    public List<ExampleForm> findAllExample() throws EchoServiceException;

    public ExampleForm findExampleById(Integer iid) throws EchoServiceException;

    public Integer updateOneExample(ExampleEntity exampleEntity) throws EchoServiceException;

    public Integer createOneExample(ExampleEntity exampleEntity) throws EchoServiceException;

    public Integer deleteOneExample(Integer iid) throws EchoServiceException;
}
