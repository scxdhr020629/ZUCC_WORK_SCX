package com.example.testjpa.formbean;

public class LabelForm {
    private int iid;
    private String labelId;
    private String labelContent;



    private int labelGroupIid;
    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public String getLabelId() {
        return labelId;
    }

    public void setLabelId(String labelId) {
        this.labelId = labelId;
    }

    public String getLabelContent() {
        return labelContent;
    }

    public void setLabelContent(String labelContent) {
        this.labelContent = labelContent;
    }
    public int getLabelGroupIid() {
        return labelGroupIid;
    }

    public void setLabelGroupIid(int labelGroupIid) {
        this.labelGroupIid = labelGroupIid;
    }
}
