package com.example.testjpa.repository;

import com.example.testjpa.entity.CourseEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CourseEntityRepository extends JpaRepository<CourseEntity, Integer> {

   List<CourseEntity> findCourseEntitiesByCourseId(String courseId);
   List<CourseEntity> findCourseEntitiesByCourseName(String courseName);

   List<CourseEntity> findCourseEntitiesByCourseCredit(float courseCredit);

   List<CourseEntity> findCourseEntitiesByCourseIdOrCourseNameOrCourseCredit(String courseId,String courseName,float courseCredit);
}