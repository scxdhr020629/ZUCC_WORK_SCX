package com.example.testjpa.service.impl;

import com.example.testjpa.entity.UserIsAdminEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.repository.UserIsAdminEntityRepository;
import com.example.testjpa.service.UserIsAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserIsAdminServiceImpl implements UserIsAdminService {

    @Autowired
    private UserIsAdminEntityRepository userIsAdminEntityRepository;


    @Override
    public UserIsAdminEntity findUserIsAdminByUserIid(Integer userIid) throws EchoServiceException {
//        System.out.println(userIid);
        UserIsAdminEntity userIsAdminEntity = userIsAdminEntityRepository.findUserIsAdminEntityByUserIid(userIid);


        return userIsAdminEntity;
    }

    @Override
    public UserIsAdminEntity findUserIsAdminByIid(Integer iid) throws EchoServiceException {
        UserIsAdminEntity userIsAdminEntity = userIsAdminEntityRepository.findById(iid).orElse(null);

        // 在这里如果找不到的话 我们就不给他报错好了
        // 因为可以为空 如果为空的话后面就不删除了
        //        if(userIsAdminEntity==null){
//            throw new EchoServiceException("");
//        }
        return userIsAdminEntity;
    }

    @Override
    public Integer createOneUser(UserIsAdminEntity userIsAdminEntity) throws EchoServiceException {
        if(userIsAdminEntity.getIid()!=0){
            throw new EchoServiceException("我们在赋予用户管理员权限 不需要iid");
        }
        if(userIsAdminEntity.getUserIid()==0){
            throw new EchoServiceException("我们在赋予用户管理员权限 需要用户的userIid");
        }
        // 应该加一段判断是否在这个表里的代码，原先已经有权限的
        UserIsAdminEntity originUserIsAdminEntity = userIsAdminEntityRepository.findUserIsAdminEntityByUserIid(userIsAdminEntity.getUserIid());
        if(originUserIsAdminEntity==null){

            try{
                userIsAdminEntityRepository.save(userIsAdminEntity);
            }catch (Exception e){
                throw new EchoServiceException("赋予用户管理员权限时候出错");
            }


        }



        return 1;
    }

    @Override
    public Integer deleteOneUserIsAdmin(Integer iid) throws EchoServiceException {
        if(iid == 0){
            throw new EchoServiceException("删除用户的管理员权限 iid 不能为 0");
        }

        try{
            userIsAdminEntityRepository.deleteById(iid);
        }catch (Exception e){
            throw new EchoServiceException("删除一名用户的管理员权限时出错"+e.getMessage());
        }

        return 1;
    }
}
