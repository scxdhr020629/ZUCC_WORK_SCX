package com.example.testjpa.controller;

import com.example.testjpa.entity.UserEntity;
import com.example.testjpa.entity.UserIsAdminEntity;
import com.example.testjpa.result.ResponseData;
import com.example.testjpa.result.ResponseMsg;
import com.example.testjpa.service.UserIsAdminService;
import com.example.testjpa.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.jws.soap.SOAPBinding;

@RestController
@RequestMapping("user")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private UserIsAdminService userIsAdminService;
    /**
     *  public Integer createOneUser(UserEntity userEntity) throws EchoServiceException;
     *
     *     public Integer updateOneUser(UserEntity userEntity) throws  EchoServiceException;
     *
     *     public Integer deleteOneUser(Integer iid) throws  EchoServiceException;
     */

    @PostMapping("/createOneUser")
    public ResponseData createOneUser(@RequestBody UserEntity userEntity){
        Integer flag = userService.createOneUser(userEntity);
        if(flag !=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

    @PostMapping("/updateOneUser")
    public ResponseData updateOneUser(@RequestBody UserEntity userEntity){
        Integer flag = userService.updateOneUser(userEntity);
        if(flag !=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

    @PostMapping("/deleteOneUser/{iid}")
    public ResponseData deleteOneUser(@PathVariable Integer iid){
        Integer flag = userService.deleteOneUser(iid);
        if(flag !=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

    /**
     * 授予管理员权限的
     */

    @PostMapping("/enableOneUser")
    public ResponseData enableOneUser(@RequestBody UserIsAdminEntity userIsAdminEntity){
        Integer flag = userIsAdminService.createOneUser(userIsAdminEntity);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }







}
