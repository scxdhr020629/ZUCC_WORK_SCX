package com.example.testjpa.entity;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "teacher", schema = "zuccqa", catalog = "")
public class TeacherEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "iid")
    private int iid;
    @Basic
    @Column(name = "teacher_id")
    private String teacherId;
    @Basic
    @Column(name = "teacher_name")
    private String teacherName;
    @Basic
    @Column(name = "teacher_phone")
    private String teacherPhone;
    @Basic
    @Column(name = "teacher_description")
    private String teacherDescription;



    // 一对多
    @OneToMany(mappedBy = "teacherEntity",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
    //级联保存、更新、删除、刷新;延迟加载。当删除用户，会级联删除该用户的所有文章
    //拥有mappedBy注解的实体类为关系被维护端
    //mappedBy="author"中的author是Article中的author属性
    private List<CourseEntity> courseEntityList;//文章列表





    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getTeacherPhone() {
        return teacherPhone;
    }

    public void setTeacherPhone(String teacherPhone) {
        this.teacherPhone = teacherPhone;
    }

    public String getTeacherDescription() {
        return teacherDescription;
    }

    public void setTeacherDescription(String teacherDescription) {
        this.teacherDescription = teacherDescription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TeacherEntity that = (TeacherEntity) o;
        return iid == that.iid && Objects.equals(teacherId, that.teacherId) && Objects.equals(teacherName, that.teacherName) && Objects.equals(teacherPhone, that.teacherPhone) && Objects.equals(teacherDescription, that.teacherDescription);
    }

    @Override
    public int hashCode() {
        return Objects.hash(iid, teacherId, teacherName, teacherPhone, teacherDescription);
    }
}
