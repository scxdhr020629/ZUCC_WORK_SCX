package com.example.testjpa.formbean;

public class LabelGroupForm {
 private int iid;
 private String labelGroupId;
 private String labelGroupDescription;

 public int getIid() {
  return iid;
 }

 public void setIid(int iid) {
  this.iid = iid;
 }

 public String getLabelGroupId() {
  return labelGroupId;
 }

 public void setLabelGroupId(String labelGroupId) {
  this.labelGroupId = labelGroupId;
 }

 public String getLabelGroupDescription() {
  return labelGroupDescription;
 }

 public void setLabelGroupDescription(String labelGroupDescription) {
  this.labelGroupDescription = labelGroupDescription;
 }
}
