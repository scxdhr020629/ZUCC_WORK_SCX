package com.example.testjpa.repository;

import com.example.testjpa.entity.LabelEntity;
import io.lettuce.core.dynamic.annotation.Param;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface LabelEntityRepository extends JpaRepository<LabelEntity, Integer> {
    List<LabelEntity> findLabelEntitiesByLabelId(String labelId);
    @Query(value = "select label_iid, count(*) as cnt from map_course_label group by label_iid order by cnt desc limit ?1", nativeQuery = true)
    List<Object[]> findCourseLikedLabels(int n);
//@Query("select labelEntity.iid, count(*) as cnt from LabelEntity labelEntity group by labelEntity.iid order by cnt desc limit :num")
//List<Object[]> groupByLabelIidAndOrderByCountDesc(@Param("num")Integer num);
//@Query("select labelEntity.iid, count(*) as cnt from LabelEntity  labelEntity group by labelEntity.iid order by cnt desc")
//List<Object[]> groupByLabelIidAndOrderByCountDesc(Pageable pageable);

    @Query(value = "select label_iid, count(*) as cnt from map_knowledge_label group by label_iid order by cnt desc limit ?1", nativeQuery = true)
    List<Object[]> findKnowledgeLikedLabels(int n);

}