package com.example.testjpa.service;

import com.example.testjpa.entity.KnowledgeEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.ExampleForm;
import com.example.testjpa.formbean.KnowledgeForm;

import java.util.List;

public interface KnowledgeService {
    /**
     * public List<ExampleForm> findAllExample() throws EchoServiceException;
     *
     *     public ExampleForm findExampleById(Integer iid) throws EchoServiceException;
     *
     *     public Integer updateOneExample(ExampleEntity exampleEntity) throws EchoServiceException;
     *
     *     public Integer createOneExample(ExampleEntity exampleEntity) throws EchoServiceException;
     *
     *     public Integer deleteOneExample(Integer iid) throws EchoServiceException;
     */
    public List<KnowledgeForm> findAllKnowledge()throws EchoServiceException;

    public KnowledgeForm findKnowledgeById(Integer iid) throws  EchoServiceException;

    public Integer updateOneKnowledge(KnowledgeEntity knowledgeEntity) throws EchoServiceException;

    public Integer createOneKnowledge(KnowledgeEntity knowledgeEntity) throws EchoServiceException;

    public Integer deleteOneKnowledge(Integer iid) throws EchoServiceException;

    public KnowledgeForm findPreKnowledgeById(Integer iid) throws EchoServiceException;
    //  根据preKnowledgeId 来进行查询
    public List<KnowledgeForm> findAllUsingKnowledge(Integer iid) throws EchoServiceException;


    // 来进行知识点关系的遍历 找下前置知识点和后置的知识点
    public List<KnowledgeForm> findPreKnowledgeList(Integer iid) throws  EchoServiceException;
    // 这个是后置的
    public List<KnowledgeForm> findPostKnowledgeList(Integer iid) throws  EchoServiceException;


}
