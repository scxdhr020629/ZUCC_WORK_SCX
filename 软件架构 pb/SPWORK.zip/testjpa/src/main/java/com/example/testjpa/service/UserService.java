package com.example.testjpa.service;

import com.example.testjpa.entity.UserEntity;
import com.example.testjpa.exception.EchoServiceException;

public interface UserService {
//    public Integer addUser() throws EchoServiceException;

    public Integer createOneUser(UserEntity userEntity) throws EchoServiceException;

    public Integer updateOneUser(UserEntity userEntity) throws  EchoServiceException;

    public Integer deleteOneUser(Integer iid) throws  EchoServiceException;




}
