package com.example.testjpa.controller;

import com.example.testjpa.entity.KnowledgeEntity;
import com.example.testjpa.formbean.KnowledgeForm;
import com.example.testjpa.repository.CourseEntityRepository;
import com.example.testjpa.repository.KnowledgeEntityRepository;
import com.example.testjpa.repository.LabelGroupEntityRepository;
import com.example.testjpa.result.ResponseData;
import com.example.testjpa.result.ResponseMsg;
import com.example.testjpa.service.KnowledgeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/knowledge")
public class KnowledgeController {
    @Autowired
    private KnowledgeService knowledgeService;


    @GetMapping
    public ResponseData findAll(){

        List<KnowledgeForm> knowledgeFormList =knowledgeService.findAllKnowledge();
        if(knowledgeFormList.size()>0){
            return new ResponseData(ResponseMsg.SUCCESS,knowledgeFormList);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,knowledgeFormList);
        }
    }

    // 根据iid 来进行查询，因为直接选中
    @GetMapping("iid/{iid}")
    public ResponseData findKnowledgeByIid(@PathVariable Integer iid){

        KnowledgeForm knowledgeForm = knowledgeService.findKnowledgeById(iid);
        if(knowledgeForm.getIid()!=0){
            return new ResponseData(ResponseMsg.SUCCESS,knowledgeForm);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,knowledgeForm);
        }
    }


    @PostMapping("findPreKnowledgeByIid/{iid}")
    public ResponseData findPreKnowledgeByIid(@PathVariable Integer iid){
        KnowledgeForm knowledgeForm = knowledgeService.findPreKnowledgeById(iid);
        if(knowledgeForm.getIid()!=0){
            return new ResponseData(ResponseMsg.SUCCESS,knowledgeForm);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,knowledgeForm);
        }
    }


    @PostMapping("findAllUsingKnowledgeByIid/{iid}")
    public ResponseData findAllUsingKnowledgeByIid(@PathVariable Integer iid){
        List<KnowledgeForm> knowledgeFormList = knowledgeService.findAllUsingKnowledge(iid);
        if(knowledgeFormList.size()>0){
            return new ResponseData(ResponseMsg.SUCCESS,knowledgeFormList);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,knowledgeFormList);
        }
    }




    @PostMapping("updateOneKnowledge")
    public ResponseData updateOneKnowledge(@RequestBody KnowledgeEntity knowledgeEntity){
        Integer flag = knowledgeService.updateOneKnowledge(knowledgeEntity);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

    @PostMapping("createOneKnowledge")
    public ResponseData createOneKnowledge(@RequestBody KnowledgeEntity knowledgeEntity){
        Integer flag = knowledgeService.createOneKnowledge(knowledgeEntity);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }





    @PostMapping("/deleteOneKnowledge/{iid}")
    public ResponseData deleteKnowledgeById(@PathVariable Integer iid){

        Integer flag = knowledgeService.deleteOneKnowledge(iid);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,flag);
        }

    }




    // 知识点查询
    @PostMapping("preAll")
    public ResponseData findPreKnowledges(@RequestBody Map<String,String> map){
        List<KnowledgeForm> knowledgeFormList = knowledgeService.findPreKnowledgeList(Integer.valueOf(map.get("iid")));
        return  new ResponseData(ResponseMsg.SUCCESS,knowledgeFormList);
    }





//    @PostMapping("after")
//    public ResponseData findAfterKnowledges(@RequestBody Map<String,String> map){
//        List<KnowledgeForm> knowledgeFormList = knowledgeService.findPostKnowledgeList(Integer.valueOf(map.get("iid")));
//        return  new ResponseData(ResponseMsg.SUCCESS,knowledgeFormList);
//    }

}
