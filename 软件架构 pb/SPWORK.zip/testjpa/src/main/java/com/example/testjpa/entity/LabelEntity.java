package com.example.testjpa.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;
@ToString(exclude = {"courseEntities","knowledgeEntities"})
@EqualsAndHashCode(exclude = {"courseEntities","knowledgeEntities"})
@Entity
@Table(name = "label", schema = "zuccqa", catalog = "")
public class LabelEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "iid")
    private int iid;
    @Basic
    @Column(name = "label_id")
    private String labelId;
    @Basic
    @Column(name = "label_content")
    private String labelContent;
//    @Basic
//    @Column(name = "label_group_iid")
//    private int labelGroupIid;

    @ManyToOne(cascade={CascadeType.MERGE,CascadeType.REFRESH},optional=false)//可选属性optional=false,表示author不能为空。删除文章，不影响用户
    @JoinColumn(name="label_group_iid")//设置在article表中的关联字段(外键)
    private LabelGroupEntity labelGroupEntity;//所属作者

    public LabelGroupEntity getLabelGroupEntity() {
        return labelGroupEntity;
    }

    public void setLabelGroupEntity(LabelGroupEntity labelGroupEntity) {
        this.labelGroupEntity = labelGroupEntity;
    }

    @ManyToMany(mappedBy = "labelEntities")
//    @JsonIgnore
//    @JsonIgnoreProperties(value = "labelEntities")
    private List<CourseEntity> courseEntities;

    public List<CourseEntity> getCourseEntities() {
        return courseEntities;
    }

    public void setCourseEntities(List<CourseEntity> courseEntities) {
        this.courseEntities = courseEntities;
    }



    @ManyToMany(mappedBy = "labelEntities")
//    @JsonIgnore
    private List<KnowledgeEntity> knowledgeEntities ;
    public List<KnowledgeEntity> getKnowledgeEntities() {
        return knowledgeEntities;
    }

    public void setKnowledgeEntities(List<KnowledgeEntity> knowledgeEntities) {
        this.knowledgeEntities = knowledgeEntities;
    }



    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public String getLabelId() {
        return labelId;
    }

    public void setLabelId(String labelId) {
        this.labelId = labelId;
    }

    public String getLabelContent() {
        return labelContent;
    }

    public void setLabelContent(String labelContent) {
        this.labelContent = labelContent;
    }

//    public int getLabelGroupIid() {
//        return labelGroupIid;
//    }
//
//    public void setLabelGroupIid(int labelGroupIid) {
//        this.labelGroupIid = labelGroupIid;
//    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LabelEntity that = (LabelEntity) o;
//        return iid == that.iid && Objects.equals(labelId, that.labelId) && Objects.equals(labelContent, that.labelContent) && Objects.equals(labelGroupIid, that.labelGroupIid);
        return iid == that.iid && Objects.equals(labelId, that.labelId) && Objects.equals(labelContent, that.labelContent) ;

    }

    @Override
//    public int hashCode() {
//        return Objects.hash(iid, labelId, labelContent, labelGroupIid);
//    }
    public int hashCode() {
        return Objects.hash(iid, labelId, labelContent);
    }

}
