package com.example.testjpa.service;

import com.example.testjpa.entity.LabelEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.LabelForm;

import java.util.List;

public interface LabelService {
    public List<LabelForm> findAllLabel() throws EchoServiceException;
    public LabelForm findLabelById(Integer iid) throws EchoServiceException;
    public Integer createOneLabel(LabelEntity labelEntity,Integer userIid) throws EchoServiceException;
    public Integer updateOneLabel(LabelEntity labelEntity,Integer userIid) throws  EchoServiceException;
    public Integer deleteOneLabel(Integer iid,Integer userIid) throws EchoServiceException;

    public List<LabelForm> findCourseLikedLabels() throws  EchoServiceException;

    public List<LabelForm> findKnowledgeLikedLabels() throws  EchoServiceException;
    // 根据标签组id进行查询

}
