package com.example.testjpa.service.impl;

import com.example.testjpa.entity.KnowledgeEntity;
import com.example.testjpa.entity.LabelEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.KnowledgeForm;
import com.example.testjpa.repository.KnowledgeEntityRepository;
import com.example.testjpa.service.KnowledgeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.vendor.EclipseLinkJpaDialect;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class KnowledgeServiceImpl implements KnowledgeService {

    @Autowired
    private KnowledgeEntityRepository knowledgeEntityRepository;
    @Override
    public List<KnowledgeForm> findAllKnowledge() throws EchoServiceException {


        List<KnowledgeEntity> oldList = knowledgeEntityRepository.findAll();
        if(oldList == null){
            throw new EchoServiceException("没有知识点");
        }
        List<KnowledgeForm> newList = new ArrayList<>();
        for(int i =0;i< oldList.size();i++){
            KnowledgeForm knowledgeForm = new KnowledgeForm();
            knowledgeForm.setIid(oldList.get(i).getIid());
            knowledgeForm.setKnowledgeId(oldList.get(i).getKnowledgeId());
            knowledgeForm.setKnowledgeDescription(oldList.get(i).getKnowledgeDescription());
            knowledgeForm.setKnowledgeDescription(oldList.get(i).getKnowledgeDescription());
            knowledgeForm.setKnowledgeImportantDescription(oldList.get(i).getKnowledgeImportantDescription());
            knowledgeForm.setPreKnowledgeIid(oldList.get(i).getPreKnowledgeIid());
            newList.add(knowledgeForm);
        }
        return newList;
    }

    @Override
    public KnowledgeForm findKnowledgeById(Integer iid) throws EchoServiceException {

        KnowledgeEntity knowledgeEntity = knowledgeEntityRepository.findById(iid).orElse(null);
        if(knowledgeEntity==null){
            throw new EchoServiceException("找不到这样的知识点 iid为"+iid);
        }
        KnowledgeForm knowledgeForm = new KnowledgeForm();
        knowledgeForm.setIid(knowledgeEntity.getIid());
        knowledgeForm.setKnowledgeId(knowledgeEntity.getKnowledgeId());
        knowledgeForm.setKnowledgeDescription(knowledgeEntity.getKnowledgeDescription());
        knowledgeForm.setKnowledgeImportantDescription(knowledgeEntity.getKnowledgeImportantDescription());
        knowledgeForm.setPreKnowledgeIid(knowledgeEntity.getPreKnowledgeIid());
        return knowledgeForm;
    }

    @Override
    public Integer updateOneKnowledge(KnowledgeEntity knowledgeEntity) throws EchoServiceException {

        if(knowledgeEntity.getIid()==0){
            throw  new EchoServiceException("我们在更新一个知识点 需要iid");
        }
        try {
            knowledgeEntityRepository.save(knowledgeEntity);
        }catch (Exception e){
            throw new EchoServiceException("更新一个知识点的时候出错"+e.getMessage());
        }
        return 1;
    }

    @Override
    public Integer createOneKnowledge(KnowledgeEntity knowledgeEntity) throws EchoServiceException {

        if(knowledgeEntity.getIid()!=0){
            throw  new EchoServiceException("我们在创建一个知识点 需要iid");
        }


        List<LabelEntity> labelEntities = knowledgeEntity.getLabelEntities();
        // 遍历一下这些标签，如果他们不是 101 102  103  则没有难度标签
        int tempCount = 0;
        for(int i=0;i<labelEntities.size();i++){
            if(labelEntities.get(i).getIid()==101||labelEntities.get(i).getIid()==102||labelEntities.get(i).getIid()==103){
                tempCount++;
            }
        }
        if(tempCount!=1){
            throw new EchoServiceException("难度的标签数量不为1");
        }


        try {
            knowledgeEntityRepository.save(knowledgeEntity);
        }catch (Exception e){
            throw new EchoServiceException("创建一个知识点的时候出错"+e.getMessage());
        }
        return 1;
    }

    @Override
    public Integer deleteOneKnowledge(Integer iid) throws EchoServiceException {
        if(iid==0){
            throw new EchoServiceException("删除一门知识点的iid 不能为 0");
        }
        try {
            knowledgeEntityRepository.deleteById(iid);
        }catch (Exception e){
            throw new EchoServiceException("删除一门知识点的时候出错");
        }
        return 1;
    }

    @Override
    public KnowledgeForm findPreKnowledgeById(Integer iid) throws EchoServiceException {
        if(iid == 0){
            throw new EchoServiceException("iid 不能为 0");
        }
        Integer preIid = knowledgeEntityRepository.findPreKnowledgeById(iid);
        if(preIid == 0){
            throw  new EchoServiceException("找不到这样的前置知识点");
        }

        return findKnowledgeById(preIid);
    }

    @Override
    public List<KnowledgeForm> findAllUsingKnowledge(Integer iid) throws EchoServiceException {
        if(iid ==0){
            throw new EchoServiceException("iid 不能为 0");
        }
        List<KnowledgeEntity> oldList = knowledgeEntityRepository.findKnowledgeEntitiesByPreKnowledgeIid(iid);
        if(oldList.size()==0){
            throw new EchoServiceException("没有依赖的知识点");
        }
        List<KnowledgeForm> newList = new ArrayList<>();
        for(int i =0;i< oldList.size();i++){
            KnowledgeForm knowledgeForm = new KnowledgeForm();
            knowledgeForm.setIid(oldList.get(i).getIid());
            knowledgeForm.setKnowledgeId(oldList.get(i).getKnowledgeId());
            knowledgeForm.setKnowledgeDescription(oldList.get(i).getKnowledgeDescription());
            knowledgeForm.setKnowledgeDescription(oldList.get(i).getKnowledgeDescription());
            knowledgeForm.setKnowledgeImportantDescription(oldList.get(i).getKnowledgeImportantDescription());
            knowledgeForm.setPreKnowledgeIid(oldList.get(i).getPreKnowledgeIid());
            newList.add(knowledgeForm);
        }
        return newList;

    }

    @Override
    public List<KnowledgeForm> findPreKnowledgeList(Integer iid) throws EchoServiceException {
        List<KnowledgeEntity> oldList = new ArrayList<>();
        // 调用一个私有的递归方法，传入iid和result
        findPreKnowledgeByIidRecursively(iid, oldList);
        // 返回结果
        List<KnowledgeForm> newList = new ArrayList<>();
        for(int i = 0;i<oldList.size();i++){
            KnowledgeForm knowledgeForm = new KnowledgeForm();
            knowledgeForm.setIid(oldList.get(i).getIid());
            knowledgeForm.setKnowledgeId(oldList.get(i).getKnowledgeId());
            knowledgeForm.setKnowledgeDescription(oldList.get(i).getKnowledgeDescription());
            knowledgeForm.setKnowledgeDescription(oldList.get(i).getKnowledgeDescription());
            knowledgeForm.setKnowledgeImportantDescription(oldList.get(i).getKnowledgeImportantDescription());
            knowledgeForm.setPreKnowledgeIid(oldList.get(i).getPreKnowledgeIid());
            newList.add(knowledgeForm);

            if(oldList.get(i).getIid()==oldList.get(i).getPreKnowledgeIid()){
                break;
            }

        }

        return newList;
    }

    private void findPreKnowledgeByIidRecursively(Integer iid, List<KnowledgeEntity> result) {
        if (result.size() >= 6) {
            return;
        }
        // 根据iid查询知识点实体
        KnowledgeEntity entity = knowledgeEntityRepository.findById(iid).orElse(null);
        // 如果实体不为空，就添加到结果中
        if (entity != null) {
            result.add(entity);
            // 如果实体有前置知识点，就继续递归
            if (entity.getPreKnowledgeIid() != null) {
                findPreKnowledgeByIidRecursively(entity.getPreKnowledgeIid(), result);
            }
        }
    }

    @Override
    public List<KnowledgeForm> findPostKnowledgeList(Integer iid) throws EchoServiceException {
        List<KnowledgeEntity> oldList = knowledgeEntityRepository.findPostKnowledgeByIid(iid);
        List<KnowledgeForm> newList = new ArrayList<>();
        for(int i = 0;i<oldList.size();i++){
            KnowledgeForm knowledgeForm = new KnowledgeForm();
            knowledgeForm.setIid(oldList.get(i).getIid());
            knowledgeForm.setKnowledgeId(oldList.get(i).getKnowledgeId());
            knowledgeForm.setKnowledgeDescription(oldList.get(i).getKnowledgeDescription());
            knowledgeForm.setKnowledgeDescription(oldList.get(i).getKnowledgeDescription());
            knowledgeForm.setKnowledgeImportantDescription(oldList.get(i).getKnowledgeImportantDescription());
            knowledgeForm.setPreKnowledgeIid(oldList.get(i).getPreKnowledgeIid());
            newList.add(knowledgeForm);


        }
        return newList;
    }
}
