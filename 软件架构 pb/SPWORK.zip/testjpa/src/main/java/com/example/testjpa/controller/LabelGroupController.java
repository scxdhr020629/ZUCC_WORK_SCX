package com.example.testjpa.controller;

import com.example.testjpa.entity.LabelGroupEntity;
import com.example.testjpa.entity.LabelGroupIsSystemEntity;
import com.example.testjpa.formbean.LabelGroupForm;
import com.example.testjpa.repository.LabelGroupEntityRepository;
import com.example.testjpa.result.ResponseData;
import com.example.testjpa.result.ResponseMsg;
import com.example.testjpa.service.LabelGroupIsSystemService;
import com.example.testjpa.service.LabelGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/label_groups")
public class LabelGroupController {
    @Autowired
    private LabelGroupService labelGroupService;

    @Autowired
    private LabelGroupIsSystemService labelGroupIsSystemService;

    @GetMapping
    public ResponseData findAll(){
        List<LabelGroupForm> labelGroupFormList = labelGroupService.findAllLabelGroup();
        if(labelGroupFormList.size()>0){
            return new ResponseData(ResponseMsg.SUCCESS,labelGroupFormList);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,labelGroupFormList);
        }
    }

    @GetMapping("iid/{iid}")
    public ResponseData findLabelGroupById(@PathVariable Integer iid){

        LabelGroupForm labelGroupForm = labelGroupService.findLabelGroupById(iid);
        if(labelGroupForm.getIid()!=0){
            return new ResponseData(ResponseMsg.SUCCESS,labelGroupForm);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,labelGroupForm);
        }
    }

    @PostMapping("updateOneLabelGroup/{userIid}")
    public ResponseData updateOneLabelGroup(@RequestBody LabelGroupEntity labelGroupEntity,@PathVariable Integer userIid){

        Integer flag = labelGroupService.updateOneLabelGroup(labelGroupEntity,userIid);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }
    @PostMapping("createOneLabelGroup")
    public ResponseData createOneLabelGroup(@RequestBody LabelGroupEntity labelGroupEntity){

        Integer flag = labelGroupService.createOneLabelGroup(labelGroupEntity);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

    @PostMapping("/deleteOneLabelGroup")
    public ResponseData deleteLabelGroupById(@RequestBody Map<String,String> map){

        Integer flag = labelGroupService.deleteOneLabelGroup(Integer.parseInt(map.get("iid")),Integer.parseInt(map.get("userIid")));
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }


    /**
     * 授予标签组内置的权限
     */
    @PostMapping("enableOneLabelGroup/{userIid}")
    public ResponseData enableOneLabelGroup (@RequestBody LabelGroupIsSystemEntity labelGroupIsSystemEntity,@PathVariable Integer userIid){
         Integer flag = labelGroupIsSystemService.createOneSystemLabel(labelGroupIsSystemEntity,userIid);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

}
