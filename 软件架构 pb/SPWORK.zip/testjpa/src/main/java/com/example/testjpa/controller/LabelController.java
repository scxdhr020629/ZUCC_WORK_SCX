package com.example.testjpa.controller;

import com.example.testjpa.entity.LabelEntity;
import com.example.testjpa.formbean.LabelForm;
import com.example.testjpa.repository.LabelEntityRepository;
import com.example.testjpa.result.ResponseData;
import com.example.testjpa.result.ResponseMsg;
import com.example.testjpa.service.LabelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/labels")
public class LabelController {
    @Autowired
    private LabelService labelService;

    // 查询所有标签
    @GetMapping
    public ResponseData findAll(){

        List<LabelForm> labelFormList = labelService.findAllLabel();
        if(labelFormList.size()>0){
            return new ResponseData(ResponseMsg.SUCCESS,labelFormList);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,labelFormList);
        }
    }

    // 查询标签 根据iid
    @GetMapping("/iid/{iid}")
    public ResponseData findLabelById(@PathVariable Integer iid){

        LabelForm labelForm = labelService.findLabelById(iid);
        if(labelForm.getIid()!=0){
            return new ResponseData(ResponseMsg.SUCCESS,labelForm);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,labelForm);
        }
    }

    @PostMapping("/createOneLabel/{userIid}")
    public ResponseData createOneLabel(@RequestBody LabelEntity labelEntity,@PathVariable Integer userIid){

        Integer flag = labelService.createOneLabel(labelEntity,userIid);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

    @PostMapping("/updateOneLabel/{userIid}")
    public ResponseData updateOneLabel(@RequestBody LabelEntity labelEntity,@PathVariable Integer userIid){

        Integer flag = labelService.updateOneLabel(labelEntity,userIid);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }


    @PostMapping("/deleteOneLabel")
    public ResponseData deleteCourseById(@RequestBody Map<String,String> map){
        Integer flag = labelService.deleteOneLabel(Integer.parseInt(map.get("iid")),Integer.parseInt(map.get("userIid")));
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else{
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

    // 标签的推荐功能
    @PostMapping("/courseLiked")
    public ResponseData findCourseLikedLabels(){
        List<LabelForm> labelFormList = labelService.findCourseLikedLabels();
        return  new ResponseData(ResponseMsg.SUCCESS,labelFormList);
    }


    @PostMapping("/knowledgeLiked")
    public ResponseData findKnowledgeLikedLabels(){
        List<LabelForm> labelFormList = labelService.findKnowledgeLikedLabels();
        return  new ResponseData(ResponseMsg.SUCCESS,labelFormList);
    }












}
