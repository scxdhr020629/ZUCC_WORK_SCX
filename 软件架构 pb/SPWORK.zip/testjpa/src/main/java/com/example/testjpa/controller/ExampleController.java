package com.example.testjpa.controller;

import com.example.testjpa.entity.ExampleEntity;
import com.example.testjpa.formbean.ExampleForm;
import com.example.testjpa.repository.ExampleEntityRepository;
import com.example.testjpa.result.ResponseData;
import com.example.testjpa.result.ResponseMsg;
import com.example.testjpa.service.ExampleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/examples")
public class ExampleController {

    @Autowired
    private ExampleService exampleService;

    @GetMapping
    public ResponseData findAll(){

        List<ExampleForm> exampleFormList = exampleService.findAllExample();
        if(exampleFormList.size()>0){
            return new ResponseData(ResponseMsg.SUCCESS,exampleFormList);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,exampleFormList);
        }

    }
    // 通过id 来进行查找
    @GetMapping("/iid/{iid}")
    public ResponseData findExampleById(@PathVariable Integer iid){

        ExampleForm exampleForm = exampleService.findExampleById(iid);
        if(exampleForm.getIid()!=0){
            return new ResponseData(ResponseMsg.SUCCESS,exampleForm);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,exampleForm);
        }
    }



    @PostMapping("/updateOneExample")
    public ResponseData updateOneExample(@RequestBody ExampleEntity exampleEntity){

        Integer flag = exampleService.updateOneExample(exampleEntity);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

    @PostMapping("/createOneExample")
    public ResponseData createOneExample(@RequestBody ExampleEntity exampleEntity){

        Integer flag = exampleService.createOneExample(exampleEntity);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }


    @PostMapping("/deleteOneExample/{iid}")
    public ResponseData deleteOneExampleById(@PathVariable Integer iid){

        Integer flag = exampleService.deleteOneExample(iid);
        if(flag!=0){
            return new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

}
