package com.example.testjpa.controller;

import com.example.testjpa.entity.TeacherEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.TeacherForm;
import com.example.testjpa.repository.TeacherEntityRepository;
import com.example.testjpa.result.ResponseData;
import com.example.testjpa.result.ResponseMsg;
import com.example.testjpa.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/teachers")
public class TeacherController {




    @Autowired
    private TeacherService teacherService;

    @GetMapping
    public List<TeacherForm> findAll(){
        List<TeacherForm> teacherFormList = teacherService.findAllTeachers();
        if(teacherFormList.size()>0){
            return teacherFormList;
        }
        else {
            System.out.println("ERROR");
            return null;
        }

    }


    // by iid
    @GetMapping("/iid/{iid}")
    public ResponseData findTeacherByIid(@PathVariable Integer iid){
        TeacherForm teacherForm = teacherService.findTeacherById(iid);
        if(teacherForm!=null){
            return  new ResponseData(ResponseMsg.SUCCESS,teacherForm);
        }
        else {
            return  new ResponseData(ResponseMsg.FAILED,teacherForm);
        }


    }

    // by teacher_id
    @GetMapping("/teacher_id/{teacher_id}")
    public ResponseData findTeacherByTeacherId (@PathVariable String teacher_id)  {
        List<TeacherForm> teacherFormList = teacherService.findTeacherByTeacherId(teacher_id);
        if(teacherFormList.size()!=0){
            return new ResponseData(ResponseMsg.SUCCESS,teacherFormList);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,teacherFormList);
        }
    }

    // 更新一名教师
    @PostMapping("updateOneTeacher")
    public ResponseData updateOneTeacher(@RequestBody TeacherEntity teacherEntity){
        Integer flag = teacherService.updateOneTeacher(teacherEntity);
        if(flag !=0){
            return  new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }

    // 创建一名教师
    @PostMapping("createOneTeacher")
    public ResponseData createOneTeacher(@RequestBody TeacherEntity teacherEntity){
        Integer flag = teacherService.createOneTeacher(teacherEntity);
        if(flag !=0){
            return  new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }




    @PostMapping("/deleteOneTeacher/{iid}")
    public ResponseData deleteOneTeacher(@PathVariable Integer iid){
        Integer flag = teacherService.deleteOneTeacher(iid);
        if(flag !=0){
            return  new ResponseData(ResponseMsg.SUCCESS,flag);
        }
        else {
            return new ResponseData(ResponseMsg.FAILED,flag);
        }
    }



}
