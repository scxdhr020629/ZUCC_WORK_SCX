package com.example.testjpa.repository;

import com.example.testjpa.entity.KnowledgeEntity;
import com.example.testjpa.formbean.KnowledgeForm;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface KnowledgeEntityRepository extends JpaRepository<KnowledgeEntity, Integer> {
    List<KnowledgeEntity> findKnowledgeEntitiesByKnowledgeId(String knowledgeId);

    List<KnowledgeEntity> findKnowledgeEntitiesByPreKnowledgeIid(Integer iid);


    @Query("SELECT t1.iid\n" +
            "FROM KnowledgeEntity t1 \n" +
            "JOIN KnowledgeEntity t2 \n" +
            "ON t1.iid = t2.preKnowledgeIid \n" +
            "WHERE t2.iid = :iid \n" )
    Integer findPreKnowledgeById(@Param("iid") int iid);


    @Query(value = "SET @@cte_max_recursion_depth = 10000; " + // 设置递归深度
            "WITH RECURSIVE pre_knowledge AS (" +
            "SELECT * FROM knowledge WHERE iid = ?1 " + // 查询指定的知识点
            "UNION ALL " +
            "SELECT k.* FROM knowledge k JOIN pre_knowledge pk ON k.iid = pk.pre_knowledge_iid " + // 查询前置知识点
            ") SELECT * FROM pre_knowledge LIMIT 4", nativeQuery = true) // 限制查询结果为4条
    List<KnowledgeEntity> findPreKnowledgeByIid(Integer iid); // 返回一个列表，包含知识点及其前置知识点

    // 定义一个方法，使用@Query注解，指定使用原生SQL查询

    @Query(value = "SELECT * FROM knowledge WHERE pre_knowledge_iid = ?1", nativeQuery = true ) // 查询后置知识点
    List<KnowledgeEntity> findPostKnowledgeByIid(Integer iid); // 返回一个列表，包含后置知识点




}