package com.example.testjpa.service.impl;

import com.example.testjpa.entity.LabelGroupIsSystemEntity;
import com.example.testjpa.entity.UserIsAdminEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.repository.LabelGroupIsSystemEntityRepository;
import com.example.testjpa.service.LabelGroupIsSystemService;
import com.example.testjpa.service.UserIsAdminService;
import com.example.testjpa.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LabelGroupIsSystemServiceImpl implements LabelGroupIsSystemService {

    @Autowired
    private LabelGroupIsSystemEntityRepository labelGroupIsSystemEntityRepository;

    @Autowired
    private UserIsAdminService userIsAdminService;


    @Override
    public LabelGroupIsSystemEntity findLabelGroupIsSystemByLabelGroupIid(Integer labelGroupIid) throws EchoServiceException {
        return labelGroupIsSystemEntityRepository.findLabelGroupIsSystemEntityByLabelGroupIid(labelGroupIid);
    }

    @Override
    public Integer createOneSystemLabel(LabelGroupIsSystemEntity labelGroupIsSystemEntity, Integer userIid) throws EchoServiceException {
        UserIsAdminEntity userIsAdminEntity = userIsAdminService.findUserIsAdminByUserIid(userIid);
        if(userIsAdminEntity==null){
            throw new EchoServiceException("创建一个 内置标签组 需要管理员权限");
        }

        if(labelGroupIsSystemEntity.getIid()!=0){
            throw new EchoServiceException("创建一个内置标签组 不需要iid");
        }

        LabelGroupIsSystemEntity originLabelGroupIsSystemEntity = labelGroupIsSystemEntityRepository.findLabelGroupIsSystemEntityByLabelGroupIid(labelGroupIsSystemEntity.getLabelGroupIid());

        if(originLabelGroupIsSystemEntity==null){
            try{
                labelGroupIsSystemEntityRepository.save(labelGroupIsSystemEntity);
            }catch (Exception e){
                throw  new EchoServiceException("创建内置标签组时出错"+e.getMessage());
            }
        }




        return 1;
    }

    @Override
    public Integer deleteOneSystemLabel(Integer iid, Integer userIid) throws EchoServiceException {
        UserIsAdminEntity userIsAdminEntity = userIsAdminService.findUserIsAdminByUserIid(userIid);
        if(userIsAdminEntity==null){
            throw new EchoServiceException("删除一个 内置标签组 需要管理员权限");
        }

        try{
            labelGroupIsSystemEntityRepository.deleteById(iid);
        }catch (Exception e){
            throw new EchoServiceException("删除一个标签组的内置权限时出错"+e.getMessage());
        }



        return 1;
    }


}
