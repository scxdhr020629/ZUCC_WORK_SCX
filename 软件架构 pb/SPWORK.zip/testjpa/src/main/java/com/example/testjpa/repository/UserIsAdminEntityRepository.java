package com.example.testjpa.repository;

import com.example.testjpa.entity.UserIsAdminEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserIsAdminEntityRepository extends JpaRepository<UserIsAdminEntity, Integer> {
    //
    public UserIsAdminEntity findUserIsAdminEntityByUserIid(Integer userIid);


}