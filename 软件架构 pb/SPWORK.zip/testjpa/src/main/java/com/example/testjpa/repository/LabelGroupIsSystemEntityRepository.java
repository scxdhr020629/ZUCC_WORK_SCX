package com.example.testjpa.repository;

import com.example.testjpa.entity.LabelGroupIsSystemEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LabelGroupIsSystemEntityRepository extends JpaRepository<LabelGroupIsSystemEntity, Integer> {
    public LabelGroupIsSystemEntity findLabelGroupIsSystemEntityByLabelGroupIid(Integer labelGroupIid);
}