package com.example.testjpa.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;
@ToString(exclude = {"knowledgeEntities"})
@EqualsAndHashCode(exclude = {"knowledgeEntities"})
@Entity
@Table(name = "example", schema = "zuccqa", catalog = "")
public class ExampleEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "iid")
    private int iid;
    @Basic
    @Column(name = "example_id")
    private String exampleId;
    @Basic
    @Column(name = "example_url")
    private String exampleUrl;


    @ManyToMany(mappedBy = "exampleEntities")
//    @JsonIgnore
    private List<KnowledgeEntity> knowledgeEntities;

    public List<KnowledgeEntity> getKnowledgeEntities() {
        return knowledgeEntities;
    }

    public void setKnowledgeEntities(List<KnowledgeEntity> knowledgeEntities) {
        this.knowledgeEntities = knowledgeEntities;
    }

    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public String getExampleId() {
        return exampleId;
    }

    public void setExampleId(String exampleId) {
        this.exampleId = exampleId;
    }

    public String getExampleUrl() {
        return exampleUrl;
    }

    public void setExampleUrl(String exampleUrl) {
        this.exampleUrl = exampleUrl;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExampleEntity that = (ExampleEntity) o;
        return iid == that.iid && Objects.equals(exampleId, that.exampleId) && Objects.equals(exampleUrl, that.exampleUrl);
    }

    @Override
    public int hashCode() {
        return Objects.hash(iid, exampleId, exampleUrl);
    }
}
