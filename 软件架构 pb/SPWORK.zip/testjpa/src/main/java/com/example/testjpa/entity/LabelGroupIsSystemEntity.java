package com.example.testjpa.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "label_group_is_system", schema = "zuccqa", catalog = "")
public class LabelGroupIsSystemEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "iid")
    private int iid;
    @Basic
    @Column(name = "label_group_iid")
    private Integer labelGroupIid;

    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public Integer getLabelGroupIid() {
        return labelGroupIid;
    }

    public void setLabelGroupIid(Integer labelGroupIid) {
        this.labelGroupIid = labelGroupIid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LabelGroupIsSystemEntity that = (LabelGroupIsSystemEntity) o;
        return iid == that.iid && Objects.equals(labelGroupIid, that.labelGroupIid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(iid, labelGroupIid);
    }
}
