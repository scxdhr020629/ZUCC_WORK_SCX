package com.example.testjpa.service.impl;

import com.example.testjpa.entity.LabelEntity;
import com.example.testjpa.entity.LabelGroupIsSystemEntity;
import com.example.testjpa.entity.UserIsAdminEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.LabelForm;
import com.example.testjpa.repository.LabelEntityRepository;
import com.example.testjpa.repository.LabelGroupIsSystemEntityRepository;
import com.example.testjpa.service.LabelGroupIsSystemService;
import com.example.testjpa.service.LabelService;
import com.example.testjpa.service.UserIsAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class LabelServiceImpl implements LabelService {
    @Autowired
    private LabelEntityRepository labelEntityRepository;

    @Autowired
    private LabelGroupIsSystemEntityRepository labelGroupIsSystemEntityRepository;

    @Autowired
    private UserIsAdminService userIsAdminService;

    @Override
    public List<LabelForm> findAllLabel() throws EchoServiceException {
        List<LabelEntity> oldList = labelEntityRepository.findAll();
        if(oldList ==null){
            throw  new EchoServiceException("没有标签");
        }
        List<LabelForm> newList = new ArrayList<>();
        for(int i=0;i<oldList.size();i++){
            LabelForm labelForm = new LabelForm();
            labelForm.setIid(oldList.get(i).getIid());
            labelForm.setLabelId(oldList.get(i).getLabelId());
            labelForm.setLabelContent(oldList.get(i).getLabelContent());
            labelForm.setLabelGroupIid(oldList.get(i).getLabelGroupEntity().getIid());
            newList.add(labelForm);
        }
        return newList;
    }

    @Override
    public LabelForm findLabelById(Integer iid) throws EchoServiceException {
        LabelEntity labelEntity = labelEntityRepository.findById(iid).orElse(null);
        if(labelEntity==null){
            throw new EchoServiceException("找不到这样的标签 iid为"+iid);
        }
        LabelForm labelForm = new LabelForm();
        labelForm.setIid(labelEntity.getIid());
        labelForm.setLabelId(labelEntity.getLabelId());
        labelForm.setLabelContent(labelEntity.getLabelContent());
        labelForm.setLabelGroupIid(labelEntity.getLabelGroupEntity().getIid());
        return  labelForm;
    }

    @Override
    public Integer createOneLabel(LabelEntity labelEntity,Integer userIid) throws EchoServiceException {

        boolean  isSystemFlag = false;
        boolean isAdminFlag = false;
        LabelGroupIsSystemEntity labelGroupIsSystemEntity = labelGroupIsSystemEntityRepository.findLabelGroupIsSystemEntityByLabelGroupIid(labelEntity.getLabelGroupEntity().getIid());

        UserIsAdminEntity userIsAdminEntity = userIsAdminService.findUserIsAdminByUserIid(userIid);
        if(userIsAdminEntity!=null){
            isAdminFlag = true;
        }

        if(labelGroupIsSystemEntity!=null){
            isSystemFlag = true;
        }

        if(isSystemFlag ==true && isAdminFlag!=true){
            throw new EchoServiceException("内置系统标签，只能管理员来进行创建");
        }




        if(labelEntity.getIid()!=0){
            throw new EchoServiceException("我们在创建一个标签 不需要iid");
        }
        try{
            labelEntityRepository.save(labelEntity);
        }catch (Exception e){
            throw new EchoServiceException("创建一个标签的时候出错"+e.getMessage());
        }
        return 1;
    }

    @Override
    public Integer updateOneLabel(LabelEntity labelEntity,Integer userIid) throws EchoServiceException {

//        LabelForm labelForm = findLabelById(iid);
//        Integer labelGroupIid = labelForm.getLabelGroupIid();
        // 查询是否是内置标签
        boolean  isSystemFlag = false;
        boolean isAdminFlag = false;
        LabelGroupIsSystemEntity labelGroupIsSystemEntity = labelGroupIsSystemEntityRepository.findLabelGroupIsSystemEntityByLabelGroupIid(labelEntity.getLabelGroupEntity().getIid());

        UserIsAdminEntity userIsAdminEntity = userIsAdminService.findUserIsAdminByUserIid(userIid);
        if(userIsAdminEntity!=null){
            isAdminFlag = true;
        }

        if(labelGroupIsSystemEntity!=null){
            isSystemFlag = true;
        }

        if(isSystemFlag ==true && isAdminFlag!=true){
            throw new EchoServiceException("内置系统标签，只能管理员来进行更新");
        }

        if(labelEntity.getIid()==0){
            throw new EchoServiceException("我们在更新一个标签 需要iid");
        }
        try{
            labelEntityRepository.save(labelEntity);
        }catch (Exception e){
            throw new EchoServiceException("更新一个标签的时候出错"+e.getMessage());
        }
        return 1;
    }

    @Override
    public Integer deleteOneLabel(Integer iid,Integer userIid) throws EchoServiceException {

        LabelForm labelForm = findLabelById(iid);
        Integer labelGroupIid = labelForm.getLabelGroupIid();
        // 查询是否是内置标签
        boolean  isSystemFlag = false;
        boolean isAdminFlag = false;
        LabelGroupIsSystemEntity labelGroupIsSystemEntity = labelGroupIsSystemEntityRepository.findLabelGroupIsSystemEntityByLabelGroupIid(labelGroupIid);

        UserIsAdminEntity userIsAdminEntity = userIsAdminService.findUserIsAdminByUserIid(userIid);
        if(userIsAdminEntity!=null){
            isAdminFlag = true;
        }

        if(labelGroupIsSystemEntity!=null){
            isSystemFlag = true;
        }

        if(isSystemFlag ==true && isAdminFlag!=true){
            throw new EchoServiceException("内置系统标签，只能管理员来进行删除");
        }


        if(iid == 0){
            throw new EchoServiceException("删除一个标签的iid 不能为 0");
        }
        try{
            labelEntityRepository.deleteById(iid);
        }catch (Exception e){
            throw new EchoServiceException("删除一个标签的时候出错");
        }
        return 1;
    }

    @Override
    public List<LabelForm> findCourseLikedLabels() throws EchoServiceException {
        //使用LabelEntityRepository的方法，根据label_iid分组并按照计数降序排序，取前三个结果
//        List<Object[]> topThreeLabels = labelEntityRepository.groupByLabelIidAndOrderByCountDesc(PageRequest.of(0, 3));
        List<Object[]> topThreeLabels = labelEntityRepository.findCourseLikedLabels(6);
//遍历结果并打印
        List<LabelForm> labelFormList = new ArrayList<>();
        for (Object[] row : topThreeLabels) {
            //row[0]是label_iid，row[1]是计数
//            System.out.println("Label id: " + row[0] + ", Count: " + row[1]);
            Integer labelIid = (Integer) row[0];
            if(labelIid!=101&&labelIid!=102&&labelIid!=103){
                LabelForm tempLabelForm = findLabelById((Integer) row[0]);
                labelFormList.add(tempLabelForm);
            }

        }
        return labelFormList;
    }

    @Override
    public List<LabelForm> findKnowledgeLikedLabels() throws EchoServiceException {
        List<Object[]> topThreeLabels = labelEntityRepository.findKnowledgeLikedLabels(7);
//遍历结果并打印
        List<LabelForm> labelFormList = new ArrayList<>();
        for (Object[] row : topThreeLabels) {
            //row[0]是label_iid，row[1]是计数
//            System.out.println("Label id: " + row[0] + ", Count: " + row[1]);
            Integer labelIid = (Integer) row[0];
            if(labelIid!=101&&labelIid!=102&&labelIid!=103){
                LabelForm tempLabelForm = findLabelById((Integer) row[0]);
                labelFormList.add(tempLabelForm);
            }

        }
        return labelFormList;
    }
}
