package com.example.testjpa.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "user_is_admin", schema = "zuccqa", catalog = "")
public class UserIsAdminEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "iid")
    private int iid;
    @Basic
    @Column(name = "user_iid")
    private Integer userIid;

    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public Integer getUserIid() {
        return userIid;
    }

    public void setUserIid(Integer userIid) {
        this.userIid = userIid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserIsAdminEntity that = (UserIsAdminEntity) o;
        return iid == that.iid && Objects.equals(userIid, that.userIid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(iid, userIid);
    }
}
