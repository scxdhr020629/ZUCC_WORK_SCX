package com.example.testjpa.service.impl;

import com.example.testjpa.entity.UserEntity;
import com.example.testjpa.entity.UserIsAdminEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.repository.UserEntityRepository;
import com.example.testjpa.repository.UserIsAdminEntityRepository;
import com.example.testjpa.service.UserIsAdminService;
import com.example.testjpa.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserEntityRepository userEntityRepository;


    @Autowired
    private UserIsAdminService userIsAdminService;

    // 创建一个用户
    @Override
    public Integer createOneUser(UserEntity userEntity) throws EchoServiceException {

        if(userEntity.getIid()!=0){
            throw new EchoServiceException("我们在创建一个用户 不需要iid");
        }
        try{
            userEntityRepository.save(userEntity);
        }catch (Exception e){
            throw new EchoServiceException("创建一个用户时出错"+e.getMessage());
        }

        return 1;
    }

    @Override
    public Integer updateOneUser(UserEntity userEntity) throws EchoServiceException {

        if(userEntity.getIid()==0){
            throw new EchoServiceException("我们在更新一个用户 需要iid");
        }
        try{
            userEntityRepository.save(userEntity);
        }catch (Exception e){
            throw new EchoServiceException("更新一个用户时出错"+e.getMessage());
        }

        return 1;


    }

    @Override
    public Integer deleteOneUser(Integer iid) throws EchoServiceException {

        // 删除这个用户之前 ， 要查询一下这个用户是不是管理员

        if(iid == 0){
            throw new EchoServiceException("在删除用户 iid不能为 0");
        }



        UserIsAdminEntity userIsAdminEntity= userIsAdminService.findUserIsAdminByUserIid(iid);

        try{
            if(userIsAdminEntity==null){

            }
            else{
                // 删除管理员权限
                userIsAdminService.deleteOneUserIsAdmin(userIsAdminEntity.getIid());

            }
            userEntityRepository.deleteById(iid);
        }catch (Exception e){
            throw new EchoServiceException("删除一个用户的时候出错");
        }

        return 1;
    }
}
