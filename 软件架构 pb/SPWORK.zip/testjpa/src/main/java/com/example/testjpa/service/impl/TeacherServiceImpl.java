package com.example.testjpa.service.impl;

import com.example.testjpa.entity.TeacherEntity;
import com.example.testjpa.exception.EchoServiceException;
import com.example.testjpa.formbean.TeacherForm;
import com.example.testjpa.repository.TeacherEntityRepository;
import com.example.testjpa.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TeacherServiceImpl implements TeacherService {
    @Autowired
    private TeacherEntityRepository teacherEntityRepository;
    @Override
    public List<TeacherForm> findAllTeachers() throws EchoServiceException {
        List<TeacherEntity> oldList =  teacherEntityRepository.findAll();
        if(oldList ==null){
            throw  new EchoServiceException("没有老师");
        }

        List<TeacherForm> newList = new ArrayList<>();
        for(int i=0;i<oldList.size();i++){
            TeacherForm teacherForm = new TeacherForm();
            teacherForm.setIid(oldList.get(i).getIid());
            teacherForm.setTeacherId(oldList.get(i).getTeacherId());
            teacherForm.setTeacherName(oldList.get(i).getTeacherName());
            teacherForm.setTeacherPhone(oldList.get(i).getTeacherPhone());
            teacherForm.setTeacherDescription(oldList.get(i).getTeacherDescription());
            newList.add(teacherForm);
        }
        return newList;
    }

    @Override
    public TeacherForm findTeacherById(Integer iid)throws EchoServiceException{


        if(teacherEntityRepository.findById(iid).orElse(null) ==null ){

            throw new EchoServiceException("找不到教师,iid为"+iid);
        }
        TeacherEntity teacherEntity = teacherEntityRepository.findById(iid).orElse(null);
        if(teacherEntity==null){
            return null;
        }
        else{
            TeacherForm teacherForm = new TeacherForm();
            teacherForm.setIid(teacherEntity.getIid());
            teacherForm.setTeacherId(teacherEntity.getTeacherId());
            teacherForm.setTeacherName(teacherEntity.getTeacherName());
            teacherForm.setTeacherDescription(teacherEntity.getTeacherDescription());
            teacherForm.setTeacherPhone(teacherEntity.getTeacherPhone());
            return  teacherForm;
        }
    }

    @Override
    public List<TeacherForm> findTeacherByTeacherId(String teacherId) throws EchoServiceException {
        List<TeacherEntity> oldList = teacherEntityRepository.findTeacherEntitiesByTeacherId(teacherId);
        List<TeacherForm> newList = new ArrayList<>();
        for(int i=0;i<oldList.size();i++){
            TeacherForm teacherForm = new TeacherForm();
            teacherForm.setIid(oldList.get(i).getIid());
            teacherForm.setTeacherId(oldList.get(i).getTeacherId());
            teacherForm.setTeacherName(oldList.get(i).getTeacherName());
            teacherForm.setTeacherPhone(oldList.get(i).getTeacherPhone());
            teacherForm.setTeacherDescription(oldList.get(i).getTeacherDescription());
            newList.add(teacherForm);
        }
        if(newList.size() == 0){
            throw new EchoServiceException("不存在这样的教师,teacherId 为"+teacherId);
        }
        return newList;
    }
    // 更新一名教师
    @Override
    public Integer updateOneTeacher(TeacherEntity teacherEntity) throws EchoServiceException {
        if(teacherEntity.getIid()==0){
            throw  new EchoServiceException("我们在更新一名教师的信息 必须 要有 iid");
        }
        try{
            teacherEntityRepository.save(teacherEntity);
        }catch (Exception e){
            throw  new EchoServiceException("更新一名教师时出错"+e.getMessage());

        }


        return 1;

    }

    @Override
    public Integer createOneTeacher(TeacherEntity teacherEntity) throws EchoServiceException {
        if(teacherEntity.getIid()!=0){
            throw  new EchoServiceException("我们在创建一名教师 不需要iid");
        }
        try{
            teacherEntityRepository.save(teacherEntity);
        }catch (Exception e){
            throw  new EchoServiceException("创建一名教师时出错"+e.getMessage());

        }

        return 1;
    }

    @Override
    public Integer deleteOneTeacher(Integer iid) throws EchoServiceException {
        if(iid == 0){
            throw  new EchoServiceException("删除的iid 不能为 0");
        }
        try{
            teacherEntityRepository.deleteById(iid);
        }catch (Exception e){
            throw  new EchoServiceException("删除一名教师时出错"+e.getMessage());

        }

        return 1;
    }


}


