package com.example.testjpa.service;

import com.example.testjpa.entity.LabelGroupIsSystemEntity;
import com.example.testjpa.exception.EchoServiceException;

public interface LabelGroupIsSystemService {


    public LabelGroupIsSystemEntity findLabelGroupIsSystemByLabelGroupIid(Integer labelGroupIid)throws  EchoServiceException;

    public Integer createOneSystemLabel(LabelGroupIsSystemEntity labelGroupIsSystemEntity,Integer userIid) throws EchoServiceException;

    public Integer deleteOneSystemLabel(Integer iid,Integer userIid) throws  EchoServiceException;
}
