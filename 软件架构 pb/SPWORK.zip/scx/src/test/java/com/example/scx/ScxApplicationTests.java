package com.example.scx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScxApplicationTests {

    @Test
    void contextLoads() {
    }

}
