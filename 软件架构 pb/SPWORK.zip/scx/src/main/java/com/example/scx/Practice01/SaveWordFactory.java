package com.example.scx.Practice01;

public class SaveWordFactory {
    public static ISaveWord saveWordService(String type){
        switch (type){
            case "file":return new SaveWordToFile();
            case "mysql":return new SaveWordToMysql();
            default:return null;
        }
    }
}
