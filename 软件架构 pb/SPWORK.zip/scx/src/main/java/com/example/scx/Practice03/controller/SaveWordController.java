package com.example.scx.Practice03.controller;

import com.example.scx.Practice01.ISaveWord;
import com.example.scx.Practice02.SaveWordFactory;
import com.example.scx.Practice03.dispatcher.ServiceDispatcher;
import com.example.scx.Practice03.service.SaveWordService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


//@RestController
//@RequestMapping("/practice03")
public class SaveWordController {
    public static void main(String[] args){
        String[] words = new String[]{"32001019","scx"};
        SaveWordService saveWordService = (SaveWordService) ServiceDispatcher.createService("save");
        saveWordService.saveWord(words);
    }


//    @PostMapping
//    public String saveWord() {
//        String[] words = new String[]{"32001019","scx"};
//        SaveWordService saveWordService = (SaveWordService) ServiceDispatcher.createService("save");
//        saveWordService.saveWord(words);
//        return "done";
//    }
}
