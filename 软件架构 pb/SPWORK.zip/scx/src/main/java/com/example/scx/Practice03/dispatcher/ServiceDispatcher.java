package com.example.scx.Practice03.dispatcher;

import com.example.scx.Practice03.service.ISaveWord;
import com.example.scx.Practice03.service.SaveWordService;
import com.example.scx.Practice03.util.ReadFileUtil;

public class ServiceDispatcher {
    private Object bean;
    public static Object createService(String name){
        String buf = ReadFileUtil.readPropertiesByName("ioc.buf");
        char[] n = name.toCharArray();
        n[0] = Character.toUpperCase(n[0]);
        String newName = new String(n);
        String className = "com.example.scx.Practice03.service."+newName+buf;

        try {
            Class clazz = Class.forName(className);
            String path = ReadFileUtil.readPropertiesByName("ioc.pack").replace(".","\\");
            SaveWordService saveWordService = (SaveWordService) clazz.getConstructor().newInstance();
            saveWordService.setSaveWord((ISaveWord) Class.forName(ReadFileUtil.readPropertiesByName("ioc.pack")).getConstructor().newInstance());
            return saveWordService;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
