package com.example.scx.Practice02;

import com.example.scx.Practice01.ISaveWord;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/practice02")
public class Practice02Controller {
    @PostMapping
    public String saveWord(@RequestBody String[] words) {
        ISaveWord saveWord = SaveWordFactory.saveWordService();
        saveWord.saveWord(words);
        return "done";
    }
}
