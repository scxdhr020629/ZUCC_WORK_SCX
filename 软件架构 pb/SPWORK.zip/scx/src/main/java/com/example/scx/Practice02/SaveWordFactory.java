package com.example.scx.Practice02;

import com.example.scx.Practice01.ISaveWord;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class SaveWordFactory {
    public static ISaveWord saveWordService() {
        Properties properties = new Properties();
        try {
            InputStream inputStream = SaveWordFactory.class.getClassLoader().getResourceAsStream("config.properties");
            properties.load(inputStream);
        }catch (IOException e){
            e.printStackTrace();
        }
        String className = properties.getProperty("saveWordServiceClass");
        try {
            Class<?> clazz = Class.forName(className);
            return (ISaveWord) clazz.getDeclaredConstructor().newInstance();
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
