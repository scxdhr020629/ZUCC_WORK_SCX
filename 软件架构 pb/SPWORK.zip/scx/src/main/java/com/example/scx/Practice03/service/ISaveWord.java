package com.example.scx.Practice03.service;

public interface ISaveWord {
    boolean saveWord(String[] words);
}
