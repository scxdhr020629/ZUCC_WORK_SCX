package com.example.scx.Practice01;

public interface ISaveWord {
    void saveWord(String[] words);
}
