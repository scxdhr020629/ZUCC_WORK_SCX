package com.example.scx.Practice03.factory;

import com.example.scx.Practice03.service.SaveWordService;
import com.example.scx.Practice03.util.ReadFileUtil;

public class SaveWordFactory {
    public static SaveWordService createService(){
        try{
            Class clazz = Class.forName(ReadFileUtil.readPropertiesByName("classname"));
            SaveWordService saveWordService = (SaveWordService) clazz.getConstructor().newInstance();
            return saveWordService;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
