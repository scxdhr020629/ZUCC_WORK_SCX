package com.example.scx.Practice01;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.util.List;
import java.util.Map;

public class SaveWordToMysql implements  ISaveWord{

    private final JdbcTemplate jdbcTemplate;
    public SaveWordToMysql() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://localhost:3306/label05");
        dataSource.setUsername("root");
        dataSource.setPassword("123456");
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }
    @Override
    public void saveWord(String[] words) {
        String sql = "SELECT count FROM words WHERE word = ?";
        for (String word : words) {
            List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, word);
            if (rows.size() > 0) {
                int count = ((Number) rows.get(0).get("count")).intValue();
                String sqlUpdate = "UPDATE words SET count = ? WHERE word = ?";
                jdbcTemplate.update(sqlUpdate, count + 1, word);
            }
            else{
                String sqlInsert = "INSERT INTO words (word, count) VALUES (?, ?)";
                jdbcTemplate.update(sqlInsert, word, 1);
            }
        }
    }

}
