package com.example.scx.Practice03.service;

public class SaveWordToMysql implements ISaveWord {
    @Override
    public boolean saveWord(String[] words) {
        System.out.println("正在将单词存入数据库中...");
        System.out.println("单词存入数据库成功");
        return true;
    }
}
