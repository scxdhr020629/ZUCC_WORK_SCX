package cn.edu.zucc.cache.controller;

import cn.edu.zucc.cache.service.UserScoreRankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


/**
 * @author longzhonghua
 * @data 2/19/2019 8:25 PM
 */
@RestController
@RequestMapping("/music")
public class RedisController {
    @Autowired
    UserScoreRankService userScoreRankService;

    @RequestMapping( value ="/score", method = RequestMethod.POST)
    @ResponseBody
    public String score(@RequestBody Map score){
        return userScoreRankService.updateUserAlbumScore((Integer) score.get("userId"), (Integer) score.get("albumId"),(Integer) score.get("score"));
    }


    @RequestMapping( value ="/query", method = RequestMethod.POST)
    @ResponseBody
    public Double query (@RequestBody Map score){
        return userScoreRankService.getAlbumScore((Integer) score.get("albumId"));
    }

    //TODO 提供一个新的接口用于音乐专辑的排序输出;排序输出用数据库和用redis两个版本
}