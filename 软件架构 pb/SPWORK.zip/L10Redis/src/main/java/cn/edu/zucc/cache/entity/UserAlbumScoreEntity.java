package cn.edu.zucc.cache.entity;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "user_album_score")
@Data
public class UserAlbumScoreEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer scoreId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private UserEntity user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "album_id", nullable = false)
    private MusicAlbumEntity album;

    @Column(nullable = false)
    private Integer score;

    @Column(nullable = true)
    private LocalDateTime createAt;

    // getters and setters
}
