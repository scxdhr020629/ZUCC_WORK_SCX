package cn.edu.zucc.cache.entity;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "music_album")
@Data
public class MusicAlbumEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer albumId;

    @Column(nullable = false, length = 50)
    private String albumName;

    @Column(nullable = false, length = 50)
    private String artistName;

    @Column(nullable = false)
    private LocalDate releaseAt;

    @Column(nullable = false, length = 255)
    private String coverUrl;

    @Column(nullable = false, length = 50)
    private String genre;

    @Lob
    private String description;

    @Column(nullable = false)
    private Boolean isDeleted = false;
}
