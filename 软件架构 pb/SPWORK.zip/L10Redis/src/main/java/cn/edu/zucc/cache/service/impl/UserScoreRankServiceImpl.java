package cn.edu.zucc.cache.service.impl;

import cn.edu.zucc.cache.entity.MusicAlbumEntity;
import cn.edu.zucc.cache.entity.UserAlbumScoreEntity;
import cn.edu.zucc.cache.entity.UserEntity;
import cn.edu.zucc.cache.repository.MusicAlbumRepository;
import cn.edu.zucc.cache.repository.UserAlbumScoreRepository;
import cn.edu.zucc.cache.repository.UserRepository;
import cn.edu.zucc.cache.service.UserScoreRankService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserScoreRankServiceImpl implements UserScoreRankService {
    private final UserAlbumScoreRepository userAlbumScoreRepository;
    private final UserRepository userRepository;
    private final MusicAlbumRepository musicAlbumRepository;
    private final CacheRedisService cacheRedisService;

    private Boolean isUseCache = true;

    private static final Logger logger = LoggerFactory.getLogger(UserScoreRankService.class);

    public UserScoreRankServiceImpl(UserAlbumScoreRepository userAlbumScoreRepository, UserRepository userRepository, MusicAlbumRepository musicAlbumRepository, CacheRedisService cacheRedisService) {
        this.userAlbumScoreRepository = userAlbumScoreRepository;
        this.musicAlbumRepository = musicAlbumRepository;
        this.userRepository = userRepository;
        this.cacheRedisService = cacheRedisService;
    }

    public Double getAlbumScore(Integer albumId) {
        long startTime = System.currentTimeMillis();
        Double retValue = null;
        if (isUseCache) {
            retValue = this.cacheRedisService.getAlbumScore(albumId);
            System.out.println("use cache");
        } else {
            List<UserAlbumScoreEntity> scoreList = userAlbumScoreRepository.findByAlbumAlbumId(albumId);
            retValue = scoreList.stream().mapToDouble(item -> item.getScore()).average().orElse(0D);
            System.out.println("no use cache");
        }

        long endTime = System.currentTimeMillis();
        logger.info("getAlbumScore with albumId {} took {} ms", albumId, endTime - startTime);
        return retValue;
    }

    public String updateUserAlbumScore(Integer userId, Integer albumId, Integer score) {
        long startTime = System.currentTimeMillis();
        if (isUseCache) {

            this.cacheRedisService.cacheUserAlbumScore(albumId,score);
            System.out.println("use cache");
        } else {
            UserAlbumScoreEntity scoreEntity = new UserAlbumScoreEntity();
            UserEntity userEntity = userRepository.getOne(userId);
            MusicAlbumEntity musicAlbumEntity = musicAlbumRepository.getOne(albumId);
            //TODO 用户或者专辑不存在的检查
            scoreEntity.setUser(userEntity);
            scoreEntity.setAlbum(musicAlbumEntity);
            scoreEntity.setScore(score);
            userAlbumScoreRepository.save(scoreEntity);
            System.out.println("no use cache");
        }

        long endTime = System.currentTimeMillis();
        logger.info("updateUserAlbumScore with userId {} and albumId {} took {} ms", userId, albumId, endTime - startTime);
        return "done";
    }

    public Boolean getUseCache() {
        return isUseCache;
    }

    public void setUseCache(Boolean useCache) {
        isUseCache = useCache;
    }
}
