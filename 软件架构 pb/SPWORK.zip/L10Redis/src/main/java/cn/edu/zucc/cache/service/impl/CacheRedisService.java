package cn.edu.zucc.cache.service.impl;

import org.springframework.data.redis.core.BoundListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class CacheRedisService {
    private final RedisTemplate redisTemplate;
    private static final String SCORE_CACHE_PREFIX = "score_cache_";

    public CacheRedisService(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public Double getAlbumScore(Integer albumId) {

        String key = SCORE_CACHE_PREFIX + "_" + albumId;
        BoundListOperations<String, Integer> scoreOps = redisTemplate.boundListOps(key);
        Double retValue = scoreOps.range(0, -1).stream().mapToDouble(item->item).average().orElse(0D);

        return retValue;
    }

    public Boolean cacheUserAlbumScore(Integer albumId, Integer score) {
        String key = SCORE_CACHE_PREFIX + "_" + albumId;
        BoundListOperations<String, Integer> scoreOps = redisTemplate.boundListOps(key);
        scoreOps.rightPush(score);

        return true;
    }



}
