package cn.edu.zucc.cache.service;

import org.springframework.stereotype.Service;

/**
 * @author pengbin
 * @version 1.0
 * @date 2023/04/22 12:03
 */
@Service
public interface UserScoreRankService {
    //获取专辑评分
    Double getAlbumScore(Integer albumId);
    //用户给专辑打分
    String updateUserAlbumScore(Integer userId, Integer albumId, Integer score);
}
