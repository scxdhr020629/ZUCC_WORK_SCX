package cn.edu.zucc.cache.repository;

import cn.edu.zucc.cache.entity.MusicAlbumEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MusicAlbumRepository extends JpaRepository<MusicAlbumEntity, Integer> {

}
