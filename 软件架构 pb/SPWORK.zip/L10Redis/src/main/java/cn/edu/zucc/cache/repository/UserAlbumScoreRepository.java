package cn.edu.zucc.cache.repository;

import cn.edu.zucc.cache.entity.UserAlbumScoreEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserAlbumScoreRepository extends JpaRepository<UserAlbumScoreEntity, Integer> {
    List<UserAlbumScoreEntity> findByAlbumAlbumId(Integer albumId);
}
