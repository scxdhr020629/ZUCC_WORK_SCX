package ysc.label05.Practice03.service;

import java.util.List;

public interface ISaveWord {
    boolean saveWord(String[] words);
}
