package ysc.label05.Practice01;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class SaveWordToFile implements ISaveWord {
    private static final String FILE_NAME = "words.json";
    @Override
    public void saveWord(String[] words) {
        try{
            File file = new File(FILE_NAME);
            if(!file.exists()){
                file.createNewFile();
            }
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String,Integer> map = new HashMap<>();
            if(file.length()!=0){
                map = objectMapper.readValue(file, new TypeReference<Map<String, Integer>>() {
                });
            }
            for(String word:words){
                if(map.containsKey(word)){
                    int count = map.get(word);
                    map.put(word,count+1);
                }
                else {
                    map.put(word,1);
                }
            }
            objectMapper.writeValue(file,map);
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
