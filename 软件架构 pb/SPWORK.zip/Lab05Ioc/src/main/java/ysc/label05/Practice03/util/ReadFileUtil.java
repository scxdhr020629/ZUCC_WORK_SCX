package ysc.label05.Practice03.util;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ReadFileUtil {
    public static String readPropertiesByName(String name){
        File file = new File(ReadFileUtil.class.getResource("").getPath());
        Properties properties = new Properties();
        try{
            properties.load(new FileInputStream(file));
            String value = String.valueOf(properties.get(name));
            return value;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
