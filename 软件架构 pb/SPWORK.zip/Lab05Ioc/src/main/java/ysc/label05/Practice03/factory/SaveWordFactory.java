package ysc.label05.Practice03.factory;

import ysc.label05.Practice03.service.SaveWordService;
import ysc.label05.Practice03.util.ReadFileUtil;

public class SaveWordFactory {
    public static SaveWordService createService(){
        try{
            Class clazz = Class.forName(ReadFileUtil.readPropertiesByName("classname"));
            SaveWordService saveWordService = (SaveWordService) clazz.getConstructor().newInstance();
            return saveWordService;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
