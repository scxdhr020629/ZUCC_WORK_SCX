package ysc.label05.Practice01;

public interface ISaveWord {
    void saveWord(String[] words);
}
