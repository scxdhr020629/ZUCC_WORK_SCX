package ysc.label05.Practice01;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/practice01")
public class Practice01Controller {
    @PostMapping("/{type}")
    public String excutePractice01(@PathVariable String type, @RequestBody String[] words){
        ISaveWord saveWord = SaveWordFactory.saveWordService(type);
        saveWord.saveWord(words);
        return "done";
    }
}
