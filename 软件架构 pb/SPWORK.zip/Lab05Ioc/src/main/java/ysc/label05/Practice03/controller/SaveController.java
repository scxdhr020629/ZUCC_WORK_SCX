package ysc.label05.Practice03.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ysc.label05.Practice03.dispatcher.ServiceDispatcher;
import ysc.label05.Practice03.service.SaveWordService;

public class  SaveController {
    public static void main(String[] args){
        String[] words = new String[]{"32001019","scx"};
        SaveWordService saveWordService = (SaveWordService) ServiceDispatcher.createService("save");
        saveWordService.saveWord(words);
    }
}
