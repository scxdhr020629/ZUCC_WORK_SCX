package ysc.label05.Practice01;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class SaveWordFactory {
    public static ISaveWord saveWordService(String type){
        switch (type){
            case "file":return new SaveWordToFile();
            case "mysql":return new SaveWordToMysql();
            default:return null;
        }
    }
}
