package ysc.label05.Practice03.service;

public class SaveWordToFile implements ISaveWord {
    @Override
    public boolean saveWord(String[] words) {
        System.out.println("正在将单词存入json文件中...");
        System.out.println("单词存入json文件成功");
        return true;
    }
}
