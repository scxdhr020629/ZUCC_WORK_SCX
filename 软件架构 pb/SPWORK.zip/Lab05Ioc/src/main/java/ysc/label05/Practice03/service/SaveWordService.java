package ysc.label05.Practice03.service;

public class SaveWordService {
    private ISaveWord saveWord;
    public void setSaveWord(ISaveWord saveWord){
        this.saveWord = saveWord;
    }
    public void saveWord(String[] words){
        saveWord.saveWord(words);
    }
}
