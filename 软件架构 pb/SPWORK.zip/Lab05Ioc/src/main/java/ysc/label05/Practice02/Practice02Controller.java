package ysc.label05.Practice02;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ysc.label05.Practice01.ISaveWord;

@RestController
@RequestMapping("/practice02")
public class Practice02Controller {
    @PostMapping
    public String saveWord(@RequestBody String[] words) {
        ISaveWord saveWord = SaveWordFactory.saveWordService();
        saveWord.saveWord(words);
        return "done";
    }
}
