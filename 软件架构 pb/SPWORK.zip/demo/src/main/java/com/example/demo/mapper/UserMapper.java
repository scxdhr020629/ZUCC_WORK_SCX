package com.example.demo.mapper;

import com.example.demo.pojo.User;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public interface UserMapper {
    @Select("select * from usertable order by user_id")
    List<User> getUserList();
}
