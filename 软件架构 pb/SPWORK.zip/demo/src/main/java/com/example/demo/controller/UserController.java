package com.example.demo.controller;

import com.example.demo.pojo.User;
import com.example.demo.service.impl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
public class UserController {
@Autowired
    private UserServiceImpl userService;
    @RequestMapping("/getuserlist")
    public List<User> getUserList(){
        return userService.getUserList();
    }

}
