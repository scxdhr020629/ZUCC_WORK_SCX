package cn.edu.zucc.pb.staticproxy;

public interface IService {
    public void doA();
    public void doB();
}
