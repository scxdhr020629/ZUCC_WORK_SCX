package cn.edu.zucc.pb.cgproxy;

public interface IService {
    public void doA();
    public void doB();
}
