package cn.edu.zucc.pb.dynamicproxy;

public interface IService {
    public void doA();
    public void doB();
}
